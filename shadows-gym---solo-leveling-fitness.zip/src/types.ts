export type HunterRank = 'E' | 'D' | 'C' | 'B' | 'A' | 'S' | 'NATIONAL';

export interface HunterStats {
  strength: number;
  agility: number;
  endurance: number;
  shadowPower: number;
}

export interface WorkoutSet {
  setNum: number;
  weightKg: number;
  reps: number;
  completed: boolean;
}

export interface WorkoutExerciseLog {
  exerciseId: string;
  exerciseName: string;
  targetMuscles: string[];
  sets: WorkoutSet[];
}

export interface WorkoutHistoryEntry {
  id: string;
  date: string;
  durationMinutes: number;
  musclesTrained: string[];
  exercises: WorkoutExerciseLog[];
  xpEarned: number;
  levelBefore: number;
  levelAfter: number;
  rankAfter: HunterRank;
}

export interface DailyQuest {
  pushups: number;
  pushupsTarget: number;
  squats: number;
  squatsTarget: number;
  situps: number;
  situpsTarget: number;
  runKm: number;
  runKmTarget: number;
  completed: boolean;
  lastUpdated: string;
}

export interface HunterProfile {
  email?: string;
  isEmailLinked?: boolean;
  onboardingCompleted?: boolean;
  name: string;
  age: number;
  weightKg: number;
  heightCm: number;
  fitnessGoal: string;
  level: number;
  xp: number;
  rank: HunterRank;
  title: string;
  stats: HunterStats;
  workoutHistory: WorkoutHistoryEntry[];
  dailyQuest: DailyQuest;
  totalWorkouts: number;
  streakDays: number;
  lastWorkoutDate?: string;
  avatarUrl?: string;
}

export type MuscleId =
  | 'chest'
  | 'shoulders'
  | 'back'
  | 'arms'
  | 'abs'
  | 'quads'
  | 'glutes'
  | 'hamstrings'
  | 'calves'
  | 'forearms';

export interface MuscleDefinition {
  id: MuscleId;
  name: string;
  subname: string;
  category: 'upper' | 'core' | 'lower';
  view: 'front' | 'back' | 'both';
  xpMultiplier: number;
}

export interface ExerciseDefinition {
  id: string;
  name: string;
  targetMuscles: MuscleId[];
  targetMusclesLabels: string[];
  primaryMuscle: MuscleId;
  defaultSets: number;
  defaultReps: string;
  restSeconds: number;
  description: string;
  executionSteps: string[];
  tips: string[];
  animationType:
    | 'bench_press'
    | 'squat'
    | 'pullup'
    | 'shoulder_press'
    | 'bicep_curl'
    | 'crunch'
    | 'deadlift'
    | 'dips'
    | 'lunges'
    | 'calf_raise';
}
