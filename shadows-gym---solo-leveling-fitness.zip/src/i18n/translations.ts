export type Language = 'fr' | 'en' | 'ar';

export interface Translations {
  nav: {
    home: string;
    workout: string;
    programs: string;
    profile: string;
    settings: string;
    start: string;
    level: string;
    xp: string;
  };
  home: {
    heroTag: string;
    heroSubtitle: string;
    heroDesc: string;
    btnStart: string;
    btnPrograms: string;
    noPain: string;
    pillarMuscuTitle: string;
    pillarMuscuDesc: string;
    pillarCardioTitle: string;
    pillarCardioDesc: string;
    pillarCoachingTitle: string;
    pillarCoachingDesc: string;
    pillarCommunityTitle: string;
    pillarCommunityDesc: string;
    hudSystemTitle: string;
    hudStreak: string;
    hudRankProgress: string;
    hudTotalXp: string;
    hudXpNeeded: string;
    hudViewProfile: string;
    hudTrainNow: string;
    ladderTag: string;
    ladderTitle: string;
    ladderDesc: string;
    currentRankBadge: string;
  };
  stepper: {
    step1: string;
    step2: string;
    step3: string;
    step4: string;
  };
  info: {
    tag: string;
    title: string;
    desc: string;
    nameLabel: string;
    namePlaceholder: string;
    ageLabel: string;
    weightLabel: string;
    heightLabel: string;
    goalLabel: string;
    goalMass: string;
    goalCut: string;
    goalStamina: string;
    bmiLabel: string;
    btnConfirm: string;
  };
  muscles: {
    title: string;
    desc: string;
    front: string;
    back: string;
    selectedTitle: string;
    selectAll: string;
    deselectAll: string;
    clickTip: string;
    btnBack: string;
    btnNext: string;
    warningSelect: string;
    countSelected: string;
  };
  muscleNames: {
    chest: string;
    shoulders: string;
    back: string;
    arms: string;
    abs: string;
    quads: string;
    glutes: string;
    hamstrings: string;
    calves: string;
    forearms: string;
  };
  exercisesPreview: {
    title: string;
    subtitle: string;
    iaMode: string;
    kpiExercises: string;
    kpiSets: string;
    kpiXp: string;
    btnBack: string;
    btnStart: string;
    setsUnit: string;
    restUnit: string;
  };
  activeWorkout: {
    sessionDuration: string;
    setsValidated: string;
    estimatedXp: string;
    exerciseCount: string;
    formInstructions: string;
    setsJournal: string;
    objective: string;
    weightUnit: string;
    repsUnit: string;
    btnDone: string;
    btnValidate: string;
    btnSaveSession: string;
    saveSessionSub: string;
  };
  profile: {
    systemTag: string;
    title: string;
    btnStart: string;
    rankBadge: string;
    level: string;
    totalXp: string;
    nextRank: string;
    maxRank: string;
    age: string;
    weight: string;
    height: string;
    bmi: string;
    btnEdit: string;
    btnCloseEdit: string;
    saveChanges: string;
    attributesTitle: string;
    attrStrength: string;
    attrAgility: string;
    attrEndurance: string;
    attrShadow: string;
    dailyQuestTitle: string;
    questPushups: string;
    questSquats: string;
    questSitups: string;
    questRun: string;
    completedBadge: string;
    historyTitle: string;
    noHistory: string;
    exercisesDone: string;
  };
  settings: {
    title: string;
    subtitle: string;
    themeTitle: string;
    themeDesc: string;
    dark: string;
    light: string;
    langTitle: string;
    langDesc: string;
    soundTitle: string;
    soundDesc: string;
    soundEnabled: string;
    soundDisabled: string;
    resetTitle: string;
    resetDesc: string;
    btnReset: string;
    confirmReset: string;
    resetSuccess: string;
  };
  systemAlert: {
    titleRankUp: string;
    titleLevelUp: string;
    titleQuestDone: string;
    congrats: string;
    rank: string;
    level: string;
    xpGained: string;
    attrBoostTitle: string;
    btnClaim: string;
  };
  auth: {
    portalTitle: string;
    portalSubtitle: string;
    emailLabel: string;
    emailPlaceholder: string;
    btnConnect: string;
    btnSwitch: string;
    btnDisconnect: string;
    accountLinked: string;
    switchAccount: string;
    savedAccounts: string;
    onboardingTitle: string;
    onboardingSubtitle: string;
    onboardingDesc: string;
    btnAwaken: string;
    alreadyHaveAccount: string;
    needNewAccount: string;
    enterEmailAlert: string;
    activeSession: string;
  };
  pwa: {
    btnInstall: string;
    installed: string;
    modalTitle: string;
    modalSubtitle: string;
    directInstallBtn: string;
    androidGoogleTitle: string;
    androidGoogleDesc: string;
    playStoreTitle: string;
    playStoreDesc: string;
    iosTitle: string;
    iosDesc: string;
    desktopTitle: string;
    desktopDesc: string;
    offlineFeatureTitle: string;
    offlineFeatureDesc: string;
    close: string;
  };
}

export const TRANSLATIONS: Record<Language, Translations> = {
  fr: {
    nav: {
      home: 'Accueil',
      workout: 'Entraînement',
      programs: 'Programmes',
      profile: 'Profil & Rang',
      settings: 'Paramètres',
      start: 'Commencer',
      level: 'LVL',
      xp: 'XP',
    },
    home: {
      heroTag: 'PLUS FORT QUE HIER',
      heroSubtitle: 'DISCIPLINE · EFFORT · RÉSULTATS',
      heroDesc: 'Rejoins Shadows Gym et dépasse tes limites. Un corps plus fort, un mental plus dur, une meilleure version de toi.',
      btnStart: 'Commencer',
      btnPrograms: 'Nos programmes',
      noPain: 'NO PAIN\nNO GAIN',
      pillarMuscuTitle: 'MUSCULATION',
      pillarMuscuDesc: 'Bâtis ta force',
      pillarCardioTitle: 'CARDIO',
      pillarCardioDesc: 'Améliore ton endurance',
      pillarCoachingTitle: 'COACHING',
      pillarCoachingDesc: 'Atteins tes objectifs',
      pillarCommunityTitle: 'COMMUNAUTÉ',
      pillarCommunityDesc: 'Plus fort ensemble',
      hudSystemTitle: 'SYSTÈME SOLO LEVELING',
      hudStreak: 'SÉRIE',
      hudRankProgress: 'PROGRESSION',
      hudTotalXp: 'EXP cumulés',
      hudXpNeeded: 'EXP pour rang suivant',
      hudViewProfile: 'Voir Mon Profil',
      hudTrainNow: "S'Entraîner",
      ladderTag: 'ÉCHELLE DE CLASSEMENT',
      ladderTitle: 'LES RANGS DES CHASSEURS DE SHADOWS GYM',
      ladderDesc: 'Comme dans Solo Leveling, chaque entraînement vous octroie de l’EXP pour grimper les échelons et éveiller votre puissance.',
      currentRankBadge: 'VOTRE RANG ACTUEL',
    },
    stepper: {
      step1: 'Informations',
      step2: 'Muscles',
      step3: 'Exercices',
      step4: 'Programme',
    },
    info: {
      tag: 'INITIALISATION DU PROFIL DE CHASSEUR',
      title: 'VOS INFORMATIONS PHYSIQUES',
      desc: 'Renseignez votre profil pour calibrer le volume et l’intensité de votre entraînement de Monarque.',
      nameLabel: 'Nom ou Pseudo de Chasseur',
      namePlaceholder: 'Ex: Wassim, Sung Jin-Woo...',
      ageLabel: 'Âge (ans)',
      weightLabel: 'Poids (kg)',
      heightLabel: 'Taille (cm)',
      goalLabel: 'Objectif d’Entraînement',
      goalMass: 'Prise de masse & Force',
      goalCut: 'Perte de gras & Définition',
      goalStamina: 'Endurance & Agilité de Chasseur',
      bmiLabel: 'Indice Corporel Estimé (IMC) :',
      btnConfirm: 'CONFIRMER & SÉLECTIONNER LES MUSCLES',
    },
    muscles: {
      title: 'SÉLECTIONNEZ VOS GROUPES MUSCULAIRES',
      desc: 'Choisissez les muscles que vous souhaitez entraîner. Vous pourrez en sélectionner autant que vous le souhaitez.',
      front: 'DEVANT',
      back: 'DOS',
      selectedTitle: 'MUSCLES SÉLECTIONNÉS',
      selectAll: 'Tout sélectionner',
      deselectAll: 'Désélectionner tout',
      clickTip: 'Cliquez sur les zones pour sélectionner les muscles',
      btnBack: '← Retour aux Informations (1/4)',
      btnNext: 'CONTINUER VERS LES EXERCICES (3/4)',
      warningSelect: '⚠️ Sélectionnez au moins 1 muscle pour continuer',
      countSelected: 'groupes musculaires sélectionnés',
    },
    muscleNames: {
      chest: 'Poitrine',
      shoulders: 'Épaules',
      back: 'Dos',
      arms: 'Bras',
      abs: 'Abdominaux',
      quads: 'Quadriceps',
      glutes: 'Fessiers',
      hamstrings: 'Ischio-jambiers',
      calves: 'Mollets',
      forearms: 'Avant-bras',
    },
    exercisesPreview: {
      title: 'VOS EXERCICES SÉLECTIONNÉS (3/4)',
      subtitle: 'Programme sur-mesure pour vos muscles ciblés',
      iaMode: 'Mode IA Personnalisé',
      kpiExercises: 'EXERCICES',
      kpiSets: 'TOTAL SÉRIES',
      kpiXp: 'EXP À GAGNER',
      btnBack: 'Modifier les muscles',
      btnStart: 'LANCER LA SÉANCE D’ENTRAÎNEMENT (4/4)',
      setsUnit: 'séries',
      restUnit: 's',
    },
    activeWorkout: {
      sessionDuration: 'DURÉE SÉANCE',
      setsValidated: 'SÉRIES VALIDÉES',
      estimatedXp: 'EXP ESTIMÉ',
      exerciseCount: 'EXERCICE',
      formInstructions: 'CONSIGNES D’EXÉCUTION DU SYSTÈME :',
      setsJournal: 'JOURNAL DES SÉRIES',
      objective: 'Objectif :',
      weightUnit: 'kg',
      repsUnit: 'reps',
      btnDone: 'FAIT',
      btnValidate: 'VALIDER',
      btnSaveSession: 'ENREGISTRER LA SÉANCE & OBTENIR MON EXP',
      saveSessionSub: 'Enregistrez vos données dans votre profil pour gagner votre EXP et monter de rang !',
    },
    profile: {
      systemTag: 'SYSTÈME DE CHASSEUR // STATUT ACTIF',
      title: 'CARTE DE CHASSEUR OFFICIELLE',
      btnStart: 'LANCER UN ENTRAÎNEMENT',
      rankBadge: 'RANG',
      level: 'NIVEAU',
      totalXp: 'EXP TOTAL',
      nextRank: 'PROCHAIN :',
      maxRank: 'RANG MONARQUE MAXIMAL',
      age: 'ÂGE',
      weight: 'POIDS',
      height: 'TAILLE',
      bmi: 'IMC',
      btnEdit: 'Modifier mes informations physiques',
      btnCloseEdit: 'Fermer la modification',
      saveChanges: 'Sauvegarder',
      attributesTitle: 'ATTRIBUTS DU MONARQUE',
      attrStrength: 'FORCE (STRENGTH)',
      attrAgility: 'AGILITÉ (SPEED)',
      attrEndurance: 'ENDURANCE (VITALITY)',
      attrShadow: 'PUISSANCE D’OMBRE (MANA)',
      dailyQuestTitle: 'QUÊTE QUOTIDIENNE DU SYSTÈME',
      questPushups: 'Pompes',
      questSquats: 'Squats',
      questSitups: 'Abdominaux',
      questRun: 'Course à pied',
      completedBadge: 'COMPLÉTÉE !',
      historyTitle: 'HISTORIQUE DES ENTRAÎNEMENTS ENREGISTRÉS',
      noHistory: 'Aucun entraînement sauvegardé pour le moment. Lancez votre première quête !',
      exercisesDone: 'exercices complétés',
    },
    settings: {
      title: 'PARAMÈTRES DU SYSTÈME',
      subtitle: 'Personnalisez votre interface, vos préférences de langue et le thème visuel.',
      themeTitle: 'Thème de l’interface',
      themeDesc: 'Choisissez entre l’obscurité mystique des Ombres ou la clarté éveillée.',
      dark: 'Mode Sombre (Dark)',
      light: 'Mode Clair (Light)',
      langTitle: 'Langue de l’application',
      langDesc: 'Choisissez votre langue préférée (English, Français, العربية).',
      soundTitle: 'Effets Sonores & Fanfare',
      soundDesc: 'Sons d’interface, validations de séries et fanfares de montée de niveau.',
      soundEnabled: 'Sons Activés',
      soundDisabled: 'Sons Coupés',
      resetTitle: 'Réinitialisation des Données',
      resetDesc: 'Effacez votre historique et remettez votre niveau de Chasseur à zéro.',
      btnReset: 'Réinitialiser toutes les données',
      confirmReset: 'Êtes-vous sûr de vouloir réinitialiser vos données de chasseur ?',
      resetSuccess: 'Données réinitialisées avec succès.',
    },
    systemAlert: {
      titleRankUp: 'ÉVEIL DE RANG SUPÉRIEUR !',
      titleLevelUp: 'MONTÉE EN NIVEAU !',
      titleQuestDone: 'QUÊTE ACCOMPLIE !',
      congrats: 'Félicitations, Chasseur {name}. Le Système a validé votre entraînement.',
      rank: 'RANG',
      level: 'Niveau',
      xpGained: 'EXP GAGNÉ',
      attrBoostTitle: 'ATTRIBUTS RENFORCÉS PAR LE SYSTÈME :',
      btnClaim: 'RÉCUPÉRER LES RÉCOMPENSES',
    },
    auth: {
      portalTitle: 'PORTAIL CHASSEUR',
      portalSubtitle: 'CONNEXION ET LIAISON PAR E-MAIL',
      emailLabel: 'Adresse E-mail',
      emailPlaceholder: 'votre.email@exemple.com',
      btnConnect: 'SE CONNECTER / SYNCHRONISER',
      btnSwitch: 'Changer de compte',
      btnDisconnect: 'Se déconnecter',
      accountLinked: 'Compte Lié & Sauvegardé',
      switchAccount: 'Changer de Chasseur',
      savedAccounts: 'Comptes Chasseur enregistrés sur cet appareil',
      onboardingTitle: 'ÉVEIL DU CHASSEUR',
      onboardingSubtitle: 'CALIBRATION INITIALE UNIQUE',
      onboardingDesc: 'Bienvenue dans le Système Solo Leveling. Renseignez votre profil une seule fois : vos mensurations seront mémorisées et associées à votre adresse e-mail.',
      btnAwaken: 'ÉVEILLER MON PROFIL DE CHASSEUR',
      alreadyHaveAccount: 'Déjà un compte ? Se connecter par e-mail',
      needNewAccount: 'Créer un nouveau Chasseur',
      enterEmailAlert: 'Veuillez saisir une adresse e-mail valide.',
      activeSession: 'Session Active',
    },
    pwa: {
      btnInstall: "INSTALLER L'APPLICATION",
      installed: 'APPLICATION INSTALLÉE',
      modalTitle: "INSTALLER L'APPLICATION SHADOWS GYM",
      modalSubtitle: 'DISPONIBLE SUR GOOGLE CHROME, ANDROID & PLAY STORE',
      directInstallBtn: 'Installer directement (1-Clic)',
      androidGoogleTitle: 'Android & Google Chrome (Recommandé)',
      androidGoogleDesc: "Téléchargez et installez l'application directement depuis Google Chrome. Elle s'intègre comme une vraie application native sur votre écran d'accueil et votre tiroir d'applications.",
      playStoreTitle: 'Google Play Store / Compatibilité TWA',
      playStoreDesc: "L'application respecte 100% des standards Trusted Web Activity (TWA) et WebAPK de Google Play Store pour un fonctionnement ultra-rapide et sécurisé.",
      iosTitle: 'Apple iPhone / iPad (Safari)',
      iosDesc: "Appuyez sur le bouton Partager ⎋ dans la barre Safari, puis sélectionnez « Sur l'écran d'accueil » ➕.",
      desktopTitle: 'Ordinateur PC / Mac / Chrome',
      desktopDesc: "Cliquez sur l'icône d'installation dans la barre d'adresse de votre navigateur ou sur le bouton ci-dessus.",
      offlineFeatureTitle: 'Fonctionne 100% Hors-Ligne',
      offlineFeatureDesc: 'Entraînez-vous sans connexion internet : vos exercices, animations, sons et statistiques restent accessibles partout.',
      close: 'Fermer',
    },
  },
  en: {
    nav: {
      home: 'Home',
      workout: 'Workout',
      programs: 'Programs',
      profile: 'Profile & Rank',
      settings: 'Settings',
      start: 'Start Now',
      level: 'LVL',
      xp: 'XP',
    },
    home: {
      heroTag: 'STRONGER THAN YESTERDAY',
      heroSubtitle: 'DISCIPLINE · EFFORT · RESULTS',
      heroDesc: 'Join Shadows Gym and exceed your limits. A stronger body, a tougher mind, a better version of you.',
      btnStart: 'Start Now',
      btnPrograms: 'Our Programs',
      noPain: 'NO PAIN\nNO GAIN',
      pillarMuscuTitle: 'STRENGTH',
      pillarMuscuDesc: 'Build raw power',
      pillarCardioTitle: 'CARDIO',
      pillarCardioDesc: 'Boost your stamina',
      pillarCoachingTitle: 'COACHING',
      pillarCoachingDesc: 'Crush your goals',
      pillarCommunityTitle: 'COMMUNITY',
      pillarCommunityDesc: 'Stronger together',
      hudSystemTitle: 'SOLO LEVELING SYSTEM',
      hudStreak: 'STREAK',
      hudRankProgress: 'PROGRESSION',
      hudTotalXp: 'Total EXP',
      hudXpNeeded: 'EXP to next rank',
      hudViewProfile: 'View Profile',
      hudTrainNow: 'Start Training',
      ladderTag: 'RANKING LADDER',
      ladderTitle: 'SHADOWS GYM HUNTER RANKS',
      ladderDesc: 'Just like Solo Leveling, every workout grants EXP to climb ranks and awaken your monarch aura.',
      currentRankBadge: 'YOUR CURRENT RANK',
    },
    stepper: {
      step1: 'Information',
      step2: 'Muscles',
      step3: 'Exercises',
      step4: 'Program',
    },
    info: {
      tag: 'HUNTER PROFILE INITIALIZATION',
      title: 'YOUR PHYSICAL STATS',
      desc: 'Enter your metrics to calibrate workout volume and Monarch intensity.',
      nameLabel: 'Hunter Name or Codename',
      namePlaceholder: 'e.g., Wassim, Sung Jin-Woo...',
      ageLabel: 'Age (years)',
      weightLabel: 'Weight (kg)',
      heightLabel: 'Height (cm)',
      goalLabel: 'Training Goal',
      goalMass: 'Muscle Hypertrophy & Power',
      goalCut: 'Fat Loss & Definition',
      goalStamina: 'Hunter Agility & Endurance',
      bmiLabel: 'Estimated Body Mass Index (BMI):',
      btnConfirm: 'CONFIRM & SELECT TARGET MUSCLES',
    },
    muscles: {
      title: 'SELECT TARGET MUSCLE GROUPS',
      desc: 'Choose the muscles you want to target today. You can select as many as you wish.',
      front: 'FRONT',
      back: 'BACK',
      selectedTitle: 'SELECTED MUSCLES',
      selectAll: 'Select All',
      deselectAll: 'Deselect All',
      clickTip: 'Click on body zones to toggle muscle groups',
      btnBack: '← Back to Information (1/4)',
      btnNext: 'CONTINUE TO EXERCISES (3/4)',
      warningSelect: '⚠️ Please select at least 1 muscle to continue',
      countSelected: 'muscle groups selected',
    },
    muscleNames: {
      chest: 'Chest',
      shoulders: 'Shoulders',
      back: 'Back',
      arms: 'Arms',
      abs: 'Abs',
      quads: 'Quadriceps',
      glutes: 'Glutes',
      hamstrings: 'Hamstrings',
      calves: 'Calves',
      forearms: 'Forearms',
    },
    exercisesPreview: {
      title: 'GENERATED WORKOUT PLAN (3/4)',
      subtitle: 'Tailored routine for your selected target muscles',
      iaMode: 'Custom AI Mode',
      kpiExercises: 'EXERCISES',
      kpiSets: 'TOTAL SETS',
      kpiXp: 'EXP REWARD',
      btnBack: 'Change Muscles',
      btnStart: 'LAUNCH ACTIVE WORKOUT (4/4)',
      setsUnit: 'sets',
      restUnit: 's',
    },
    activeWorkout: {
      sessionDuration: 'SESSION TIME',
      setsValidated: 'COMPLETED SETS',
      estimatedXp: 'PROJECTED EXP',
      exerciseCount: 'EXERCISE',
      formInstructions: 'SYSTEM FORM EXECUTION GUIDELINES:',
      setsJournal: 'SETS LOG',
      objective: 'Goal:',
      weightUnit: 'kg',
      repsUnit: 'reps',
      btnDone: 'DONE',
      btnValidate: 'LOG SET',
      btnSaveSession: 'SAVE WORKOUT & CLAIM EXP',
      saveSessionSub: 'Log your workout to your Hunter Profile to level up and rank up!',
    },
    profile: {
      systemTag: 'HUNTER SYSTEM // STATUS ACTIVE',
      title: 'OFFICIAL HUNTER LICENSE',
      btnStart: 'LAUNCH WORKOUT',
      rankBadge: 'RANK',
      level: 'LEVEL',
      totalXp: 'TOTAL EXP',
      nextRank: 'NEXT RANK:',
      maxRank: 'PEAK MONARCH RANK',
      age: 'AGE',
      weight: 'WEIGHT',
      height: 'HEIGHT',
      bmi: 'BMI',
      btnEdit: 'Edit Physical Info',
      btnCloseEdit: 'Close Edit',
      saveChanges: 'Save Changes',
      attributesTitle: 'MONARCH ATTRIBUTES',
      attrStrength: 'STRENGTH',
      attrAgility: 'AGILITY',
      attrEndurance: 'VITALITY',
      attrShadow: 'SHADOW POWER',
      dailyQuestTitle: 'DAILY SYSTEM QUEST',
      questPushups: 'Push-ups',
      questSquats: 'Squats',
      questSitups: 'Sit-ups',
      questRun: 'Running',
      completedBadge: 'COMPLETED!',
      historyTitle: 'RECORDED WORKOUT LOGS',
      noHistory: 'No workouts saved yet. Complete your first quest!',
      exercisesDone: 'exercises logged',
    },
    settings: {
      title: 'SYSTEM SETTINGS',
      subtitle: 'Customize your visual theme, language preferences, and hunter parameters.',
      themeTitle: 'Interface Theme',
      themeDesc: 'Switch between the mystical Shadow darkness and crisp bright mode.',
      dark: 'Dark Mode (Ombres)',
      light: 'Light Mode (Éveillé)',
      langTitle: 'Application Language',
      langDesc: 'Choose your preferred language (English, Français, العربية).',
      soundTitle: 'Audio SFX & Fanfares',
      soundDesc: 'UI feedback tones, rep confirmations, and level-up arpeggios.',
      soundEnabled: 'Sound Enabled',
      soundDisabled: 'Sound Muted',
      resetTitle: 'Data Reset',
      resetDesc: 'Wipe all workout logs and reset your Hunter progression.',
      btnReset: 'Reset all Hunter data',
      confirmReset: 'Are you sure you want to reset all your progress?',
      resetSuccess: 'Hunter data successfully reset.',
    },
    systemAlert: {
      titleRankUp: 'HIGHER RANK AWAKENED!',
      titleLevelUp: 'LEVEL UP!',
      titleQuestDone: 'DAILY QUEST COMPLETED!',
      congrats: 'Congratulations Hunter {name}. The System has approved your workout.',
      rank: 'RANK',
      level: 'Level',
      xpGained: 'EXP REWARD',
      attrBoostTitle: 'SYSTEM ATTRIBUTE BONUSES:',
      btnClaim: 'CLAIM SYSTEM REWARDS',
    },
    auth: {
      portalTitle: 'HUNTER PORTAL',
      portalSubtitle: 'EMAIL LOGIN & ACCOUNT LINK',
      emailLabel: 'Email Address',
      emailPlaceholder: 'your.email@example.com',
      btnConnect: 'SIGN IN / SYNC ACCOUNT',
      btnSwitch: 'Switch Account',
      btnDisconnect: 'Sign Out',
      accountLinked: 'Account Linked & Saved',
      switchAccount: 'Switch Hunter',
      savedAccounts: 'Hunter accounts saved on this device',
      onboardingTitle: 'HUNTER AWAKENING',
      onboardingSubtitle: 'ONE-TIME INITIAL CALIBRATION',
      onboardingDesc: 'Welcome to the Solo Leveling System. Complete your hunter information once: your measurements will be permanently linked to your email.',
      btnAwaken: 'AWAKEN MY HUNTER PROFILE',
      alreadyHaveAccount: 'Already have an account? Sign in with email',
      needNewAccount: 'Create New Hunter Profile',
      enterEmailAlert: 'Please enter a valid email address.',
      activeSession: 'Active Session',
    },
    pwa: {
      btnInstall: 'INSTALL APPLICATION',
      installed: 'APP INSTALLED',
      modalTitle: 'INSTALL SHADOWS GYM APP',
      modalSubtitle: 'AVAILABLE VIA GOOGLE CHROME, ANDROID & PLAY STORE',
      directInstallBtn: 'Install Directly (1-Click)',
      androidGoogleTitle: 'Android & Google Chrome (Recommended)',
      androidGoogleDesc: 'Download and install the app directly from Google Chrome. It installs as a real native app on your home screen and app launcher.',
      playStoreTitle: 'Google Play Store / TWA Architecture',
      playStoreDesc: 'The app meets 100% of Trusted Web Activity (TWA) and WebAPK standards for the Google Play Store with ultra-fast offline caching.',
      iosTitle: 'Apple iPhone / iPad (Safari)',
      iosDesc: 'Tap the Share button ⎋ in Safari, then scroll down and select "Add to Home Screen" ➕.',
      desktopTitle: 'Desktop PC / Mac / Chrome',
      desktopDesc: 'Click the install icon in the address bar of your browser or click the button above.',
      offlineFeatureTitle: '100% Offline Capable',
      offlineFeatureDesc: 'Train anywhere without internet: all exercises, animations, sounds, and stats stay saved on your device.',
      close: 'Close',
    },
  },
  ar: {
    nav: {
      home: 'الرئيسية',
      workout: 'التمارين',
      programs: 'البرامج',
      profile: 'الملف والرتبة',
      settings: 'الإعدادات',
      start: 'ابدأ الآن',
      level: 'المستوى',
      xp: 'خبرة',
    },
    home: {
      heroTag: 'أقوى من البارحة',
      heroSubtitle: 'انضباط · جهد · نتائج',
      heroDesc: 'انضم إلى شادوز جيم وتجاوز حدودك. جسد أقوى، عزيمة صلبة، ونسخة أفضل من نفسك.',
      btnStart: 'ابدأ الآن',
      btnPrograms: 'برامجنا',
      noPain: 'لا ألم\nلا مكسب',
      pillarMuscuTitle: 'كمال الأجسام',
      pillarMuscuDesc: 'ابنِ قوتك الخالصة',
      pillarCardioTitle: 'كارديو',
      pillarCardioDesc: 'طوّر قدرة تحملك',
      pillarCoachingTitle: 'تدريب مخصص',
      pillarCoachingDesc: 'حقق أهدافك الرياضية',
      pillarCommunityTitle: 'المجتمع',
      pillarCommunityDesc: 'معاً نصبح أقوى',
      hudSystemTitle: 'نظام سولو ليفلينج',
      hudStreak: 'سلسلة الأيام',
      hudRankProgress: 'التقدم نحو الرتبة',
      hudTotalXp: 'مجموع نقاط الخبرة',
      hudXpNeeded: 'نقاط مطلوبة للترقية',
      hudViewProfile: 'عرض ملف الصياد',
      hudTrainNow: 'ابدأ التمرين',
      ladderTag: 'سلم الرتب الرسمي',
      ladderTitle: 'رتب الصيادين في شادوز جيم',
      ladderDesc: 'كما في أنمي سولو ليفلينج، كل تمرين تنجزه يمنحك نقاط خبرة لترقية رتبتك وتطوير هالتك القتالية.',
      currentRankBadge: 'رتبتك الحالية',
    },
    stepper: {
      step1: 'البيانات',
      step2: 'العضلات',
      step3: 'التمارين',
      step4: 'البرنامج',
    },
    info: {
      tag: 'تهيئة ملف الصياد',
      title: 'بياناتك الجسدية',
      desc: 'أدخل معلوماتك لتحديد الحجم التدريبي وشدة التمارين المناسبة لك.',
      nameLabel: 'اسم الصياد أو اللقب',
      namePlaceholder: 'مثال: وسيم، سونغ جين وو...',
      ageLabel: 'العمر (بالسنوات)',
      weightLabel: 'الوزن (كغ)',
      heightLabel: 'الطول (سم)',
      goalLabel: 'هدف التمرين',
      goalMass: 'زيادة الكتلة والقوة',
      goalCut: 'تنشيف وحرق الدهون',
      goalStamina: 'لياقة وسرعة الصياد',
      bmiLabel: 'مؤشر كتلة الجسم (IMC):',
      btnConfirm: 'تأكيد واختيار العضلات المستهدفة',
    },
    muscles: {
      title: 'اختر العضلات المستهدفة',
      desc: 'حدد العضلات التي ترغب بتمرينها اليوم. يمكنك اختيار أي عدد تريده.',
      front: 'الأمام',
      back: 'الظهر',
      selectedTitle: 'العضلات المختارة',
      selectAll: 'تحديد الكل',
      deselectAll: 'إلغاء التحديد',
      clickTip: 'انقر على مناطق الجسم لاختيار العضلات المستهدفة',
      btnBack: '← العودة للبيانات (1/4)',
      btnNext: 'المتابعة لقائمة التمارين (3/4)',
      warningSelect: '⚠️ الرجاء اختيار عضلة واحدة على الأقل للمتابعة',
      countSelected: 'عضلات مستهدفة مختارة',
    },
    muscleNames: {
      chest: 'الصدر',
      shoulders: 'الأكتاف',
      back: 'الظهر',
      arms: 'الذراعين',
      abs: 'البطن',
      quads: 'الفخذ الأمامي',
      glutes: 'الأرداف',
      hamstrings: 'الفخذ الخلفي',
      calves: 'السمانة (البطات)',
      forearms: 'الساعدين',
    },
    exercisesPreview: {
      title: 'برنامج التمارين المخصص (3/4)',
      subtitle: 'تمارين مختارة بدقة للعضلات التي قمت بتحديدها',
      iaMode: 'وضع الذكاء الاصطناعي',
      kpiExercises: 'عدد التمارين',
      kpiSets: 'مجموع الجولات',
      kpiXp: 'الخبرة المكتسبة',
      btnBack: 'تعديل العضلات',
      btnStart: 'بدء جلسة التمرين الحية (4/4)',
      setsUnit: 'جولات',
      restUnit: 'ث',
    },
    activeWorkout: {
      sessionDuration: 'مدة الجلسة',
      setsValidated: 'الجولات المكتملة',
      estimatedXp: 'الخبرة المتوقعة',
      exerciseCount: 'التمرين',
      formInstructions: 'تعليمات النظام لأداء الحركة بطريقة صحيحة:',
      setsJournal: 'سجل الجولات',
      objective: 'الهدف:',
      weightUnit: 'كغ',
      repsUnit: 'تكرار',
      btnDone: 'تم',
      btnValidate: 'تأكيد',
      btnSaveSession: 'حفظ التمرين واستلام نقاط الخبرة',
      saveSessionSub: 'احفظ بياناتك في ملف الصياد لترقية مستواك ورتبتك في النظام!',
    },
    profile: {
      systemTag: 'نظام الصياد // الحالة: نشط',
      title: 'بطاقة الصياد الرسمية',
      btnStart: 'بدء تمرين جديد',
      rankBadge: 'الرتبة',
      level: 'المستوى',
      totalXp: 'مجموع الخبرة',
      nextRank: 'الرتبة القادمة:',
      maxRank: 'قمة رتبة ملك الظلال',
      age: 'العمر',
      weight: 'الوزن',
      height: 'الطول',
      bmi: 'مؤشر الكتلة',
      btnEdit: 'تعديل البيانات الجسدية',
      btnCloseEdit: 'إغلاق التعديل',
      saveChanges: 'حفظ التعديلات',
      attributesTitle: 'صفات الملك الخارقة',
      attrStrength: 'القوة الجسدية',
      attrAgility: 'السرعة والرشاقة',
      attrEndurance: 'الحيوية والتحمل',
      attrShadow: 'طاقة الظلال (المانا)',
      dailyQuestTitle: 'المهمة اليومية للنظام',
      questPushups: 'تمرين الضغط',
      questSquats: 'تمرين القرفصاء',
      questSitups: 'تمرين المعدة',
      questRun: 'الجري',
      completedBadge: 'مكتملة بنجاح!',
      historyTitle: 'سجل التمارين المكتملة',
      noHistory: 'لا توجد تمارين مسجلة حتى الآن. أنجز مهمتك الأولى!',
      exercisesDone: 'تمارين منجزة',
    },
    settings: {
      title: 'إعدادات النظام',
      subtitle: 'خصص المظهر، اللغات المفضلة، والمؤثرات الصوتية.',
      themeTitle: 'مظهر الواجهة (Theme)',
      themeDesc: 'اختر بين هيبة الظلال الداكنة (Dark) أو الوضوح الفاتح (Light).',
      dark: 'الوضع الداكن (Dark Mode)',
      light: 'الوضع الفاتح (Light Mode)',
      langTitle: 'لغة التطبيق (Language)',
      langDesc: 'اختر لغتك المفضلة (English, Français, العربية).',
      soundTitle: 'المؤثرات الصوتية والاحتفالات',
      soundDesc: 'أصوات أزرار النظام، تنبيهات الجولات، واحتفالية ترقية الرتبة.',
      soundEnabled: 'الأصوات مفعلة',
      soundDisabled: 'الأصوات مكتومة',
      resetTitle: 'إعادة ضبط البيانات',
      resetDesc: 'مسح سجل التمارين وإعادة تعيين نقاط الخبرة والمستوى إلى الصفر.',
      btnReset: 'إعادة تعيين جميع بيانات الصياد',
      confirmReset: 'هل أنت متأكد من رغبتك في إعادة تعيين كل تقدمك؟',
      resetSuccess: 'تمت إعادة ضبط البيانات بنجاح.',
    },
    systemAlert: {
      titleRankUp: 'صحوة الرتبة العليا!',
      titleLevelUp: 'ارتقاء المستوى (LEVEL UP)!',
      titleQuestDone: 'اكتملت المهمة بنجاح!',
      congrats: 'تهانينا أيها الصياد {name}. قام النظام باعتماد تدريبك.',
      rank: 'الرتبة',
      level: 'المستوى',
      xpGained: 'الخبرة المكتسبة',
      attrBoostTitle: 'مكافآت الصفات من النظام:',
      btnClaim: 'استلام مكافآت النظام',
    },
    auth: {
      portalTitle: 'بوابة الصياد',
      portalSubtitle: 'تسجيل الدخول وربط الحساب بالبريد الإلكتروني',
      emailLabel: 'البريد الإلكتروني',
      emailPlaceholder: 'your.email@example.com',
      btnConnect: 'تسجيل الدخول / مزامنة الحساب',
      btnSwitch: 'تبديل الحساب',
      btnDisconnect: 'تسجيل الخروج',
      accountLinked: 'الحساب مربوط ومحفوظ',
      switchAccount: 'تبديل الصياد',
      savedAccounts: 'حسابات الصيادين المحفوظة على هذا الجهاز',
      onboardingTitle: 'صحوة الصياد الأولى',
      onboardingSubtitle: 'ضبط البيانات الشخصية لمرة واحدة فقط',
      onboardingDesc: 'مرحبًا بك في نظام سولو ليفلينج. املأ بياناتك مرة واحدة فقط عند البداية، وسيتم حفظ اسمك ووزنك ومستواك وربطها تلقائيًا ببريدك.',
      btnAwaken: 'تفعيل حسابي وبدء الصحوة',
      alreadyHaveAccount: 'لديك حساب بالفعل؟ سجّل دخولك بالبريد',
      needNewAccount: 'إنشاء حساب صياد جديد',
      enterEmailAlert: 'يرجى إدخال بريد إلكتروني صحيح.',
      activeSession: 'الجلسة النشطة',
    },
    pwa: {
      btnInstall: 'تثبيت التطبيق',
      installed: 'تم تثبيت التطبيق',
      modalTitle: 'تنزيل وتثبيت تطبيق شادوز جيم',
      modalSubtitle: 'متاح للتنزيل المباشر عبر جوجل كروم ومتجر بلاي',
      directInstallBtn: 'تثبيت مباشر بنقرة واحدة',
      androidGoogleTitle: 'أندرويد وجوجل كروم (موصى به)',
      androidGoogleDesc: 'قم بتنزيل وتثبيت التطبيق مباشرة من متصفح جوجل كروم ليظهر كتطبيق مثبت على شاشتك الرئيسية وقائمة التطبيقات.',
      playStoreTitle: 'متجر جوجل بلاي وتوافقية TWA',
      playStoreDesc: 'التطبيق مصمم وفق أحدث معايير النشاط الموثوق TWA و WebAPK الخاصة بمتجر Google Play مع تخزين كامل بلا إنترنت.',
      iosTitle: 'أجهزة آبل آيفون وآيباد (سفاري)',
      iosDesc: 'اضغط على زر المشاركة ⎋ في متصفح سفاري ثم اختر "إضافة إلى الصفحة الرئيسية" ➕.',
      desktopTitle: 'أجهزة الكمبيوتر والحاسوب (كروم وإيدج)',
      desktopDesc: 'اضغط على زر التثبيت في شريط العنوان بالمتصفح أو اضغط الزر أعلاه.',
      offlineFeatureTitle: 'يعمل بالكامل بدون إنترنت',
      offlineFeatureDesc: 'تدرّب في أي وقت دون اتصال بالشبكة: جميع التمارين، التوقيت، الحركات وسجلك محفوظة محليًا.',
      close: 'إغلاق',
    },
  },
};
