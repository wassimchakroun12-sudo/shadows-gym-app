import { HunterProfile, HunterRank, HunterStats } from '../types';

export interface RankInfo {
  rank: HunterRank;
  title: string;
  minXp: number;
  maxXp: number;
  badgeColor: string;
  borderColor: string;
  glowColor: string;
  auraDescription: string;
}

export const RANKS_CONFIG: Record<HunterRank, RankInfo> = {
  E: {
    rank: 'E',
    title: 'Chasseur Éveillé (Novice)',
    minXp: 0,
    maxXp: 600,
    badgeColor: 'text-zinc-400 bg-zinc-900/80 border-zinc-700',
    borderColor: 'border-zinc-600',
    glowColor: 'rgba(161, 161, 170, 0.4)',
    auraDescription: 'Aura naissante et discrète. Le potentiel d’un futur Monarque.',
  },
  D: {
    rank: 'D',
    title: 'Chasseur Rang D (Guerrier)',
    minXp: 601,
    maxXp: 1800,
    badgeColor: 'text-blue-400 bg-blue-950/60 border-blue-600',
    borderColor: 'border-blue-500',
    glowColor: 'rgba(59, 130, 246, 0.5)',
    auraDescription: 'Aura bleutée constante. La discipline commence à porter ses fruits.',
  },
  C: {
    rank: 'C',
    title: 'Chasseur Rang C (Vanguard)',
    minXp: 1801,
    maxXp: 4000,
    badgeColor: 'text-cyan-400 bg-cyan-950/60 border-cyan-500',
    borderColor: 'border-cyan-400',
    glowColor: 'rgba(6, 182, 212, 0.6)',
    auraDescription: 'Aura cyan électrique. Capable de terrasser des donjons intermédiaires.',
  },
  B: {
    rank: 'B',
    title: 'Chasseur Rang B (Élite des Ombres)',
    minXp: 4001,
    maxXp: 8500,
    badgeColor: 'text-purple-400 bg-purple-950/70 border-purple-500',
    borderColor: 'border-purple-500',
    glowColor: 'rgba(168, 85, 247, 0.7)',
    auraDescription: 'Aura violette vibrante. Une force redoutable reconnue par l’Association.',
  },
  A: {
    rank: 'A',
    title: 'Chasseur Rang A (Commandant)',
    minXp: 8501,
    maxXp: 18000,
    badgeColor: 'text-fuchsia-400 bg-fuchsia-950/70 border-fuchsia-500',
    borderColor: 'border-fuchsia-500',
    glowColor: 'rgba(217, 70, 239, 0.8)',
    auraDescription: 'Flammes d’ombre pourpres denses. Seuls les boss de donjons rouges peuvent rivaliser.',
  },
  S: {
    rank: 'S',
    title: 'Chasseur Rang S (Sommet de l’Humanité)',
    minXp: 18001,
    maxXp: 35000,
    badgeColor: 'text-amber-400 bg-amber-950/70 border-amber-500',
    borderColor: 'border-amber-400',
    glowColor: 'rgba(245, 158, 11, 0.85)',
    auraDescription: 'Présence écrasante dorée et ténébreuse. Un titan sur le champ de bataille.',
  },
  NATIONAL: {
    rank: 'NATIONAL',
    title: 'Monarque des Ombres (Niveau National)',
    minXp: 35001,
    maxXp: 100000,
    badgeColor: 'text-purple-300 bg-purple-900/90 border-purple-400',
    borderColor: 'border-purple-300',
    glowColor: 'rgba(192, 132, 252, 0.95)',
    auraDescription: 'Souverain absolu des ombres. Les morts se relèvent à votre commandement : "DEBOUT !"',
  },
};

export const RANK_ORDER: HunterRank[] = ['E', 'D', 'C', 'B', 'A', 'S', 'NATIONAL'];

export function calculateRankFromXp(xp: number): HunterRank {
  if (xp >= 35001) return 'NATIONAL';
  if (xp >= 18001) return 'S';
  if (xp >= 8501) return 'A';
  if (xp >= 4001) return 'B';
  if (xp >= 1801) return 'C';
  if (xp >= 601) return 'D';
  return 'E';
}

export function calculateLevelFromXp(xp: number): number {
  // Level curve: 1 + Math.floor(Math.sqrt(xp / 25))
  return Math.max(1, Math.floor(Math.sqrt(xp / 18)) + 1);
}

export function getXpProgressForCurrentRank(xp: number, currentRank: HunterRank): {
  currentInTier: number;
  tierTotal: number;
  percentage: number;
  nextRank: HunterRank | null;
} {
  const config = RANKS_CONFIG[currentRank];
  const rankIndex = RANK_ORDER.indexOf(currentRank);
  const nextRank = rankIndex < RANK_ORDER.length - 1 ? RANK_ORDER[rankIndex + 1] : null;

  if (currentRank === 'NATIONAL') {
    return {
      currentInTier: Math.min(xp - config.minXp, 65000),
      tierTotal: 65000,
      percentage: Math.min(100, Math.round(((xp - config.minXp) / 65000) * 100)),
      nextRank: null,
    };
  }

  const tierTotal = config.maxXp - config.minXp;
  const currentInTier = Math.max(0, xp - config.minXp);
  const percentage = Math.min(100, Math.max(0, Math.round((currentInTier / tierTotal) * 100)));

  return {
    currentInTier,
    tierTotal,
    percentage,
    nextRank,
  };
}

export const INITIAL_HUNTER_PROFILE: HunterProfile = {
  email: 'wassimchakroun12@gmail.com',
  isEmailLinked: true,
  onboardingCompleted: true,
  name: 'Wassim',
  age: 23,
  weightKg: 78,
  heightCm: 180,
  fitnessGoal: 'Hypertrophie & Puissance Monarque',
  level: 1,
  xp: 150,
  rank: 'E',
  title: 'Chasseur Éveillé (Novice)',
  stats: {
    strength: 14,
    agility: 12,
    endurance: 15,
    shadowPower: 10,
  },
  workoutHistory: [],
  dailyQuest: {
    pushups: 45,
    pushupsTarget: 100,
    squats: 60,
    squatsTarget: 100,
    situps: 40,
    situpsTarget: 100,
    runKm: 4.5,
    runKmTarget: 10,
    completed: false,
    lastUpdated: new Date().toISOString().split('T')[0],
  },
  totalWorkouts: 0,
  streakDays: 1,
};

const STORAGE_KEY_V1 = 'shadows_gym_hunter_profile_v1';
const STORAGE_CURRENT_EMAIL_KEY = 'shadows_gym_active_email_v2';
const STORAGE_ACCOUNTS_MAP_KEY = 'shadows_gym_accounts_map_v2';

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

export function getCurrentEmail(): string | null {
  try {
    return localStorage.getItem(STORAGE_CURRENT_EMAIL_KEY);
  } catch {
    return null;
  }
}

export function setCurrentEmail(email: string | null): void {
  try {
    if (email) {
      localStorage.setItem(STORAGE_CURRENT_EMAIL_KEY, normalizeEmail(email));
    } else {
      localStorage.removeItem(STORAGE_CURRENT_EMAIL_KEY);
    }
  } catch {}
}

export function getAccountsMap(): Record<string, HunterProfile> {
  try {
    const raw = localStorage.getItem(STORAGE_ACCOUNTS_MAP_KEY);
    if (!raw) return {};
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

export function setAccountsMap(accounts: Record<string, HunterProfile>): void {
  try {
    localStorage.setItem(STORAGE_ACCOUNTS_MAP_KEY, JSON.stringify(accounts));
  } catch (err) {
    console.error('Failed to save accounts map', err);
  }
}

export function getSavedAccounts(): Array<{
  email: string;
  name: string;
  rank: HunterRank;
  level: number;
  xp: number;
}> {
  const accounts = getAccountsMap();
  return Object.values(accounts).map((acc) => ({
    email: acc.email || 'inconnu',
    name: acc.name || 'Chasseur',
    rank: acc.rank,
    level: acc.level,
    xp: acc.xp,
  }));
}

export function loadHunterProfile(targetEmail?: string): HunterProfile {
  try {
    const accounts = getAccountsMap();
    const activeEmail = targetEmail 
      ? normalizeEmail(targetEmail) 
      : getCurrentEmail() || 'wassimchakroun12@gmail.com';

    // 1. Check if profile exists for this email
    if (accounts[activeEmail]) {
      const p = { ...accounts[activeEmail] };
      p.rank = calculateRankFromXp(p.xp);
      p.level = calculateLevelFromXp(p.xp);
      p.title = RANKS_CONFIG[p.rank].title;
      return p;
    }

    // 2. Check legacy v1 profile
    const legacyRaw = localStorage.getItem(STORAGE_KEY_V1);
    if (legacyRaw) {
      const legacyProfile = JSON.parse(legacyRaw) as HunterProfile;
      legacyProfile.email = legacyProfile.email || activeEmail;
      legacyProfile.isEmailLinked = true;
      legacyProfile.onboardingCompleted = true;
      legacyProfile.rank = calculateRankFromXp(legacyProfile.xp);
      legacyProfile.level = calculateLevelFromXp(legacyProfile.xp);
      legacyProfile.title = RANKS_CONFIG[legacyProfile.rank].title;

      // Migrate to accounts map
      accounts[activeEmail] = legacyProfile;
      setAccountsMap(accounts);
      setCurrentEmail(activeEmail);
      return legacyProfile;
    }

    // 3. New initial profile for this email
    const newProfile: HunterProfile = {
      ...INITIAL_HUNTER_PROFILE,
      email: activeEmail,
      isEmailLinked: true,
      onboardingCompleted: true,
    };
    accounts[activeEmail] = newProfile;
    setAccountsMap(accounts);
    setCurrentEmail(activeEmail);
    return newProfile;
  } catch {
    return INITIAL_HUNTER_PROFILE;
  }
}

export function saveHunterProfile(profile: HunterProfile): void {
  try {
    const emailKey = profile.email ? normalizeEmail(profile.email) : (getCurrentEmail() || 'wassimchakroun12@gmail.com');
    const updated = {
      ...profile,
      email: emailKey,
      isEmailLinked: !!profile.email,
    };

    const accounts = getAccountsMap();
    accounts[emailKey] = updated;
    setAccountsMap(accounts);
    setCurrentEmail(emailKey);

    // Keep legacy key updated as backup
    localStorage.setItem(STORAGE_KEY_V1, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save hunter profile', err);
  }
}

export function switchEmailAccount(newEmail: string): HunterProfile {
  const normEmail = normalizeEmail(newEmail);
  const accounts = getAccountsMap();

  if (accounts[normEmail]) {
    setCurrentEmail(normEmail);
    return loadHunterProfile(normEmail);
  }

  // Brand new hunter profile for this email
  const newAccount: HunterProfile = {
    ...INITIAL_HUNTER_PROFILE,
    email: normEmail,
    name: normEmail.split('@')[0],
    isEmailLinked: true,
    onboardingCompleted: false, // will ask for name & age only for new emails!
    xp: 0,
    level: 1,
    rank: 'E',
    workoutHistory: [],
    totalWorkouts: 0,
  };

  accounts[normEmail] = newAccount;
  setAccountsMap(accounts);
  setCurrentEmail(normEmail);
  return newAccount;
}

export function logoutAccount(): HunterProfile {
  setCurrentEmail(null);
  // Guest anonymous profile
  return {
    ...INITIAL_HUNTER_PROFILE,
    email: undefined,
    isEmailLinked: false,
    onboardingCompleted: false,
  };
}

// Sound Synthesis with Web Audio API (zero external sound file reliance, reliable)
class SoundManager {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  private getContext(): AudioContext | null {
    if (this.isMuted) return null;
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  public playClick() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.05);

      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.05);
    } catch {
      // Audio playback might be restricted before interaction
    }
  }

  public playTimerTick() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(880, ctx.currentTime);

      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.04);
    } catch {}
  }

  public playTimerComplete() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const notes = [587.33, 739.99, 880, 1174.66]; // D5, F#5, A5, D6 sci-fi chime
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.08);

        gain.gain.setValueAtTime(0.12, ctx.currentTime + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.08 + 0.35);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + i * 0.08);
        osc.stop(ctx.currentTime + i * 0.08 + 0.35);
      });
    } catch {}
  }

  public playLevelUp() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      // Solo Leveling System Alert Fanfare
      const frequencies = [440, 554.37, 659.25, 880, 1108.73, 1318.51, 1760];
      frequencies.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.09);

        // Lowpass filter for warm cinematic synth
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(2200, ctx.currentTime);

        gain.gain.setValueAtTime(0.15, ctx.currentTime + idx * 0.09);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.09 + 0.5);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.09);
        osc.stop(ctx.currentTime + idx * 0.09 + 0.5);
      });
    } catch {}
  }
}

export const sounds = new SoundManager();
