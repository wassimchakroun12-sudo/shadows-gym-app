/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { HunterProfile, HunterRank, MuscleId, WorkoutHistoryEntry, HunterStats } from './types';
import {
  loadHunterProfile,
  saveHunterProfile,
  calculateRankFromXp,
  calculateLevelFromXp,
  RANKS_CONFIG,
  sounds,
} from './utils/hunterSystem';
import { Navbar } from './components/Navbar';
import { HomeView } from './components/HomeView';
import { InfoStep } from './components/InfoStep';
import { MuscleSelectionStep } from './components/MuscleSelectionStep';
import { ExercisesPreviewStep } from './components/ExercisesPreviewStep';
import { ActiveWorkoutSession } from './components/ActiveWorkoutSession';
import { HunterProfileView } from './components/HunterProfileView';
import { ProgramsView } from './components/ProgramsView';
import { SettingsView } from './components/SettingsView';
import { SystemAlertModal } from './components/SystemAlertModal';
import { EmailAuthModal } from './components/EmailAuthModal';
import { OnboardingScreen } from './components/OnboardingScreen';
import { InstallAppModal } from './components/InstallAppModal';
import { usePWAInstall } from './hooks/usePWAInstall';
import { Language, TRANSLATIONS } from './i18n/translations';

export type WorkoutStep = 'info' | 'muscles' | 'exercises' | 'session';

export default function App() {
  const [profile, setProfile] = useState<HunterProfile>(() => loadHunterProfile());
  const [currentTab, setCurrentTab] = useState<'home' | 'workout' | 'profile' | 'programs' | 'settings'>('home');
  // Default to 'muscles' so user is never blocked by info form every workout
  const [workoutStep, setWorkoutStep] = useState<WorkoutStep>('muscles');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  // Progressive Web App install prompt & detection
  const { isInstallable, isInstalled, isIOS, isAndroid, promptInstall } = usePWAInstall();

  // Theme & Language state with persistence
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try {
      return (localStorage.getItem('shadows_theme') as 'dark' | 'light') || 'dark';
    } catch {
      return 'dark';
    }
  });

  const [language, setLanguage] = useState<Language>(() => {
    try {
      return (localStorage.getItem('shadows_lang') as Language) || 'fr';
    } catch {
      return 'fr';
    }
  });

  const t = TRANSLATIONS[language];

  // Apply Theme class to document element
  useEffect(() => {
    try {
      localStorage.setItem('shadows_theme', theme);
    } catch {}

    if (theme === 'light') {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
      document.documentElement.classList.add('dark');
    }
  }, [theme]);

  // Apply RTL direction and language attributes for Arabic
  useEffect(() => {
    try {
      localStorage.setItem('shadows_lang', language);
    } catch {}

    document.documentElement.setAttribute('dir', language === 'ar' ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', language);
  }, [language]);

  // Selected target muscles (matching typical chest, shoulders, arms, abs, quads)
  const [selectedMuscles, setSelectedMuscles] = useState<MuscleId[]>([
    'chest',
    'shoulders',
    'arms',
    'abs',
    'quads',
  ]);

  // System alert modal state
  const [systemAlert, setSystemAlert] = useState<{
    isOpen: boolean;
    xpGained: number;
    levelBefore: number;
    levelAfter: number;
    rankBefore: HunterRank;
    rankAfter: HunterRank;
    statGains: HunterStats;
  }>({
    isOpen: false,
    xpGained: 0,
    levelBefore: 1,
    levelAfter: 1,
    rankBefore: 'E',
    rankAfter: 'E',
    statGains: { strength: 0, agility: 0, endurance: 0, shadowPower: 0 },
  });

  // Whenever the tab or workout step changes, scroll smoothly to the very top so each page is independent
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentTab, workoutStep]);

  // Save profile to localStorage on change
  const handleUpdateProfile = (newProfile: HunterProfile) => {
    setProfile(newProfile);
    saveHunterProfile(newProfile);
  };

  // Optional calibration from info step
  const handleInfoConfirmed = (data: {
    name: string;
    age: number;
    weightKg: number;
    heightCm: number;
    fitnessGoal: string;
  }) => {
    const updated: HunterProfile = {
      ...profile,
      name: data.name,
      age: data.age,
      weightKg: data.weightKg,
      heightCm: data.heightCm,
      fitnessGoal: data.fitnessGoal,
    };
    handleUpdateProfile(updated);
    setWorkoutStep('muscles');
  };

  // Step 2: Muscles confirmed -> proceed to exercises preview
  const handleProceedToExercises = () => {
    setWorkoutStep('exercises');
  };

  // Step 3: Launch active workout session
  const handleStartSession = () => {
    setWorkoutStep('session');
  };

  // Step 4: Workout completed & saved
  const handleFinishWorkout = (summary: {
    historyEntry: WorkoutHistoryEntry;
    xpEarned: number;
    levelBefore: number;
    levelAfter: number;
    rankBefore: HunterRank;
    rankAfter: HunterRank;
  }) => {
    const newTotalXp = profile.xp + summary.xpEarned;
    const newLevel = calculateLevelFromXp(newTotalXp);
    const newRank = calculateRankFromXp(newTotalXp);

    // Calculate stat gains
    const statGains: HunterStats = {
      strength: 2 + Math.floor(summary.xpEarned / 200),
      agility: 1 + Math.floor(summary.xpEarned / 300),
      endurance: 2 + Math.floor(summary.xpEarned / 250),
      shadowPower: 3 + Math.floor(summary.xpEarned / 150),
    };

    const updatedProfile: HunterProfile = {
      ...profile,
      xp: newTotalXp,
      level: newLevel,
      rank: newRank,
      title: RANKS_CONFIG[newRank].title,
      stats: {
        strength: profile.stats.strength + statGains.strength,
        agility: profile.stats.agility + statGains.agility,
        endurance: profile.stats.endurance + statGains.endurance,
        shadowPower: profile.stats.shadowPower + statGains.shadowPower,
      },
      workoutHistory: [summary.historyEntry, ...profile.workoutHistory],
      totalWorkouts: profile.totalWorkouts + 1,
      lastWorkoutDate: new Date().toISOString(),
    };

    handleUpdateProfile(updatedProfile);

    // Show Solo Leveling alert modal
    setSystemAlert({
      isOpen: true,
      xpGained: summary.xpEarned,
      levelBefore: summary.levelBefore,
      levelAfter: newLevel,
      rankBefore: summary.rankBefore,
      rankAfter: newRank,
      statGains,
    });
  };

  // Launching workout directly: goes straight to muscles selection
  const handleStartTrainingFlow = () => {
    setCurrentTab('workout');
    setWorkoutStep('muscles');
  };

  const handleSelectProgramMuscles = (muscles: MuscleId[]) => {
    setSelectedMuscles(muscles);
    setCurrentTab('workout');
    setWorkoutStep('exercises');
  };

  const handleCloseAlertModal = () => {
    setSystemAlert((prev) => ({ ...prev, isOpen: false }));
    setCurrentTab('profile');
  };

  // If first time opening the web or new email without completed onboarding, show OnboardingScreen
  if (profile.onboardingCompleted === false) {
    return (
      <>
        <OnboardingScreen
          initialProfile={profile}
          onComplete={(completed) => {
            handleUpdateProfile(completed);
            setCurrentTab('home');
          }}
          onOpenLogin={() => setIsAuthModalOpen(true)}
          t={t}
        />
        <EmailAuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          currentProfile={profile}
          onProfileChange={handleUpdateProfile}
          t={t}
        />
      </>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-200 ${
      theme === 'dark'
        ? 'bg-[#07050d] text-slate-100'
        : 'bg-[#f8f6fc] text-slate-900'
    } flex flex-col font-sans selection:bg-purple-600 selection:text-white relative`}>
      {/* Dynamic Purple Energy Background Gradients */}
      <div 
        className="fixed inset-0 pointer-events-none z-0 opacity-35"
        style={{
          background: theme === 'dark'
            ? 'radial-gradient(circle at 15% 25%, rgba(126, 34, 206, 0.15) 0%, transparent 45%), radial-gradient(circle at 85% 75%, rgba(88, 28, 135, 0.15) 0%, transparent 45%)'
            : 'radial-gradient(circle at 15% 25%, rgba(168, 85, 247, 0.1) 0%, transparent 45%), radial-gradient(circle at 85% 75%, rgba(192, 132, 252, 0.1) 0%, transparent 45%)'
        }}
      />

      {/* Top Navigation with Email Portal & Toggles */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          if (tab === 'workout') {
            setWorkoutStep('muscles');
          }
        }}
        profile={profile}
        t={t}
        theme={theme}
        onThemeToggle={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        language={language}
        onLanguageChange={setLanguage}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        isInstalled={isInstalled}
        isInstallable={isInstallable}
      />

      {/* Main Tab Content - Each page rendered strictly on its own */}
      <main className="flex-1 w-full relative z-10">
        {currentTab === 'home' && (
          <HomeView
            profile={profile}
            t={t}
            onStartTraining={handleStartTrainingFlow}
            onViewPrograms={() => setCurrentTab('programs')}
            onViewProfile={() => setCurrentTab('profile')}
            onOpenInstallModal={() => setIsInstallModalOpen(true)}
          />
        )}

        {currentTab === 'workout' && (
          <div className="py-4">
            {/* Optional calibration page if user clicked back to info */}
            {workoutStep === 'info' && (
              <InfoStep
                initialProfile={profile}
                onConfirm={handleInfoConfirmed}
              />
            )}

            {/* Direct Step 1/3: Interactive Muscle Selection */}
            {workoutStep === 'muscles' && (
              <MuscleSelectionStep
                selectedMuscles={selectedMuscles}
                onSelectedMusclesChange={setSelectedMuscles}
                onProceedToExercises={handleProceedToExercises}
                onBackToInfo={() => setWorkoutStep('info')}
              />
            )}

            {/* Direct Step 2/3: Generated Exercises Preview */}
            {workoutStep === 'exercises' && (
              <ExercisesPreviewStep
                selectedMuscles={selectedMuscles}
                onBackToMuscles={() => setWorkoutStep('muscles')}
                onStartSession={handleStartSession}
              />
            )}

            {/* Direct Step 3/3: Active Workout Session with Animations */}
            {workoutStep === 'session' && (
              <ActiveWorkoutSession
                selectedMuscles={selectedMuscles}
                profile={profile}
                onFinishWorkout={handleFinishWorkout}
                onBackToExercises={() => setWorkoutStep('exercises')}
              />
            )}
          </div>
        )}

        {currentTab === 'programs' && (
          <ProgramsView onSelectProgramMuscles={handleSelectProgramMuscles} />
        )}

        {currentTab === 'profile' && (
          <HunterProfileView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            onStartWorkout={handleStartTrainingFlow}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onOpenInstallModal={() => setIsInstallModalOpen(true)}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsView
            theme={theme}
            onThemeChange={setTheme}
            language={language}
            onLanguageChange={setLanguage}
            t={t}
            profile={profile}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onOpenInstallModal={() => setIsInstallModalOpen(true)}
            onResetProfile={() => {
              handleUpdateProfile({
                ...profile,
                xp: 150,
                level: 1,
                rank: 'E',
                workoutHistory: [],
                totalWorkouts: 0,
              });
            }}
          />
        )}
      </main>

      {/* Solo Leveling System Alert / Level Up Celebration Modal */}
      <SystemAlertModal
        isOpen={systemAlert.isOpen}
        onClose={handleCloseAlertModal}
        hunterName={profile.name}
        xpGained={systemAlert.xpGained}
        levelBefore={systemAlert.levelBefore}
        levelAfter={systemAlert.levelAfter}
        rankBefore={systemAlert.rankBefore}
        rankAfter={systemAlert.rankAfter}
        statGains={systemAlert.statGains}
      />

      {/* Hunter Email Auth & Account Switching Portal Modal */}
      <EmailAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentProfile={profile}
        onProfileChange={handleUpdateProfile}
        t={t}
      />

      {/* PWA / Google Chrome & Play Store Installation Modal */}
      <InstallAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        isIOS={isIOS}
        isAndroid={isAndroid}
        onPromptInstall={promptInstall}
        t={t}
      />
    </div>
  );
}
