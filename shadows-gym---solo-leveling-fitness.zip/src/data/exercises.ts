import { MuscleDefinition, ExerciseDefinition, MuscleId } from '../types';

export const MUSCLE_GROUPS: MuscleDefinition[] = [
  {
    id: 'chest',
    name: 'Poitrine',
    subname: 'Pectoraux majeurs & mineurs',
    category: 'upper',
    view: 'front',
    xpMultiplier: 1.2,
  },
  {
    id: 'shoulders',
    name: 'Épaules',
    subname: 'Deltoïdes (antérieur, latéral, postérieur)',
    category: 'upper',
    view: 'both',
    xpMultiplier: 1.1,
  },
  {
    id: 'back',
    name: 'Dos',
    subname: 'Grands dorsaux, trapèzes & rhomboïdes',
    category: 'upper',
    view: 'back',
    xpMultiplier: 1.3,
  },
  {
    id: 'arms',
    name: 'Bras',
    subname: 'Biceps branchiaux & triceps',
    category: 'upper',
    view: 'both',
    xpMultiplier: 1.1,
  },
  {
    id: 'abs',
    name: 'Abdominaux',
    subname: 'Grand droit & obliques',
    category: 'core',
    view: 'front',
    xpMultiplier: 1.0,
  },
  {
    id: 'quads',
    name: 'Quadriceps',
    subname: 'Droit fémoral & vastes',
    category: 'lower',
    view: 'front',
    xpMultiplier: 1.3,
  },
  {
    id: 'glutes',
    name: 'Fessiers',
    subname: 'Grand & moyen fessiers',
    category: 'lower',
    view: 'back',
    xpMultiplier: 1.2,
  },
  {
    id: 'hamstrings',
    name: 'Ischio-jambiers',
    subname: 'Biceps fémoral & semi-tendineux',
    category: 'lower',
    view: 'back',
    xpMultiplier: 1.2,
  },
  {
    id: 'calves',
    name: 'Mollets',
    subname: 'Gastrocnémiens & soléaire',
    category: 'lower',
    view: 'both',
    xpMultiplier: 1.0,
  },
  {
    id: 'forearms',
    name: 'Avant-bras',
    subname: 'Fléchisseurs & extenseurs du poignet',
    category: 'upper',
    view: 'both',
    xpMultiplier: 1.0,
  },
];

export const EXERCISES_DATABASE: ExerciseDefinition[] = [
  // CHEST
  {
    id: 'bench-press',
    name: 'Développé couché',
    targetMuscles: ['chest', 'shoulders', 'arms'],
    targetMusclesLabels: ['Poitrine', 'Épaules', 'Triceps'],
    primaryMuscle: 'chest',
    defaultSets: 4,
    defaultReps: '8-12',
    restSeconds: 90,
    description: 'Exercice roi pour la masse pectorale et la puissance du haut du corps.',
    executionSteps: [
      'Allongez-vous sur le banc, pieds ancrés au sol, omoplates rétractées.',
      'Saisissez la barre avec une prise légèrement plus large que les épaules.',
      'Descendez la barre de façon contrôlée jusqu’au milieu du torse.',
      'Poussez avec puissance en expirant sans décoller le dos du banc.'
    ],
    tips: ['Gardez les coudes à 45° pour préserver les rotateurs d’épaule', 'Contractez les pectoraux en haut du mouvement'],
    animationType: 'bench_press'
  },
  {
    id: 'incline-dumbbell-press',
    name: 'Développé incliné haltères',
    targetMuscles: ['chest', 'shoulders'],
    targetMusclesLabels: ['Haut de poitrine', 'Épaules'],
    primaryMuscle: 'chest',
    defaultSets: 4,
    defaultReps: '10-12',
    restSeconds: 75,
    description: 'Cible spécifiquement le faisceau claviculaire des pectoraux pour une silhouette sculptée.',
    executionSteps: [
      'Réglez le banc à 30 degrés.',
      'Amenez les haltères au niveau des épaules avec contrôle.',
      'Développez verticalement vers le haut en convergeant légèrement.',
      'Redescendez en étirant bien le haut des pectoraux.'
    ],
    tips: ['Évitez d’incliner le banc à plus de 45° pour ne pas trop recruter l’avant des épaules', 'Gardez une cambrure lombaire naturelle'],
    animationType: 'bench_press'
  },

  // BACK
  {
    id: 'pull-ups',
    name: 'Tractions prise pronation',
    targetMuscles: ['back', 'arms', 'shoulders'],
    targetMusclesLabels: ['Dos', 'Biceps', 'Épaules'],
    primaryMuscle: 'back',
    defaultSets: 4,
    defaultReps: '8-12',
    restSeconds: 90,
    description: 'L’exercice ultime au poids de corps pour construire un dos en V de Chasseur.',
    executionSteps: [
      'Accrochez-vous à la barre, mains écartées au-delà de la largeur des épaules.',
      'Initiez la traction en tirant vos coudes vers le bas et l’arrière.',
      'Montez jusqu’à ce que votre menton dépasse la barre.',
      'Contrôlez la descente jusqu’à l’extension complète des bras.'
    ],
    tips: ['Ne balancez pas le bas du corps', 'Serrez les omoplates au sommet'],
    animationType: 'pullup'
  },
  {
    id: 'barbell-row',
    name: 'Rowing barre buste penché',
    targetMuscles: ['back', 'arms', 'forearms'],
    targetMusclesLabels: ['Épaisseur du dos', 'Biceps', 'Avant-bras'],
    primaryMuscle: 'back',
    defaultSets: 4,
    defaultReps: '8-10',
    restSeconds: 90,
    description: 'Développe l’épaisseur et la densité musculaire du grand dorsal et des trapèzes.',
    executionSteps: [
      'Penchez le buste à 45°, genoux légèrement fléchis, dos rigoureusement plat.',
      'Tirez la barre vers le nombril en guidant avec les coudes.',
      'Contractez fortement les muscles du dos pendant 1 seconde.',
      'Redescendez en contrôlant la trajectoire.'
    ],
    tips: ['Gardez les abdominaux sous tension constante pour sécuriser les lombaires', 'Ne tirez pas avec les bras mais avec le dos'],
    animationType: 'deadlift'
  },

  // SHOULDERS
  {
    id: 'overhead-press',
    name: 'Développé militaire épaules',
    targetMuscles: ['shoulders', 'arms', 'abs'],
    targetMusclesLabels: ['Épaules', 'Triceps', 'Gainage'],
    primaryMuscle: 'shoulders',
    defaultSets: 4,
    defaultReps: '8-12',
    restSeconds: 90,
    description: 'Développe la largeur des deltoïdes et la force de poussée verticale.',
    executionSteps: [
      'Debout ou assis, barre reposant au niveau des clavicules.',
      'Verrouillez le tronc et les fessiers.',
      'Poussez la charge au-dessus de la tête dans une trajectoire rectiligne.',
      'Verrouillez bras tendus sans cambrer excessivement le dos.'
    ],
    tips: ['Faites passer la tête légèrement sous la barre une fois qu’elle a franchi le front', 'Gardez les abdos serrés'],
    animationType: 'shoulder_press'
  },
  {
    id: 'lateral-raises',
    name: 'Élévations latérales',
    targetMuscles: ['shoulders'],
    targetMusclesLabels: ['Deltoïde latéral', 'Épaules'],
    primaryMuscle: 'shoulders',
    defaultSets: 4,
    defaultReps: '12-15',
    restSeconds: 60,
    description: 'Isolation pure du faisceau moyen pour une carrure d’anime élargie.',
    executionSteps: [
      'Debout, un haltère dans chaque main le long des cuisses.',
      'Levez les bras latéralement jusqu’à la hauteur des épaules, coudes très légèrement fléchis.',
      'Contrôlez la descente sans vous aider de l’élan.'
    ],
    tips: ['Imaginez que vous versez de l’eau d’une carafe en haut du geste', 'Évitez de hausser les trapèzes'],
    animationType: 'shoulder_press'
  },

  // LEGS / QUADS / GLUTES / HAMSTRINGS
  {
    id: 'barbell-squat',
    name: 'Squat complet à la barre',
    targetMuscles: ['quads', 'glutes', 'hamstrings'],
    targetMusclesLabels: ['Quadriceps', 'Fessiers', 'Ischios'],
    primaryMuscle: 'quads',
    defaultSets: 4,
    defaultReps: '8-12',
    restSeconds: 120,
    description: 'La base absolue de la puissance athlétique des membres inférieurs.',
    executionSteps: [
      'Barre posée sur les trapèzes, pieds écartés largeur d’épaules, pointes légèrement ouvertes.',
      'Initiez le mouvement en poussant les hanches vers l’arrière et en fléchissant les genoux.',
      'Descendez jusqu’à ce que vos cuisses soient au moins parallèles au sol.',
      'Repoussez le sol par les talons pour remonter avec dynamisme.'
    ],
    tips: ['Gardez la poitrine haute et le regard droit devant', 'Alignez vos genoux avec la direction des orteils'],
    animationType: 'squat'
  },
  {
    id: 'romanian-deadlift',
    name: 'Soulevé de terre roumain',
    targetMuscles: ['hamstrings', 'glutes', 'back'],
    targetMusclesLabels: ['Ischio-jambiers', 'Fessiers', 'Chaîne postérieure'],
    primaryMuscle: 'hamstrings',
    defaultSets: 4,
    defaultReps: '10-12',
    restSeconds: 90,
    description: 'Élongation et renforcement puissant de l’arrière des cuisses et des fessiers.',
    executionSteps: [
      'Debout, barre tenue à la largeur des épaules.',
      'Fléchissez légèrement les genoux puis envoyez les hanches loin en arrière.',
      'Laissez glisser la barre le long des cuisses jusqu’au milieu des tibias en sentant l’étirement.',
      'Contractez les fessiers pour ramener le bassin en position neutre.'
    ],
    tips: ['Le dos doit rester rigoureusement rectiligne', 'Le mouvement vient du bassin, pas du dos'],
    animationType: 'deadlift'
  },
  {
    id: 'walking-lunges',
    name: 'Fentes marchées haltères',
    targetMuscles: ['quads', 'glutes', 'calves'],
    targetMusclesLabels: ['Quadriceps', 'Fessiers', 'Stabilité'],
    primaryMuscle: 'glutes',
    defaultSets: 3,
    defaultReps: '12 par jambe',
    restSeconds: 75,
    description: 'Renforcement unilatéral pour un galbe fessier parfait et un équilibre à toute épreuve.',
    executionSteps: [
      'Faites un grand pas en avant et descendez le genou arrière à quelques centimètres du sol.',
      'Poussez sur le talon avant pour enchaîner le pas suivant.',
      'Maintenez le torse fier et vertical pendant toute la série.'
    ],
    tips: ['Ne laissez pas le genou avant dépasser excessivement les orteils', 'Gardez le bassin droit'],
    animationType: 'lunges'
  },

  // ARMS
  {
    id: 'barbell-curl',
    name: 'Curl biceps à la barre EZ',
    targetMuscles: ['arms', 'forearms'],
    targetMusclesLabels: ['Biceps', 'Avant-bras'],
    primaryMuscle: 'arms',
    defaultSets: 4,
    defaultReps: '10-12',
    restSeconds: 60,
    description: 'Développe le pic du biceps et la force de préhension.',
    executionSteps: [
      'Debout, barre en main en prise supination, coudes collés aux côtes.',
      'Enroulez la barre vers le haut en contractant volontairement les biceps.',
      'Marquez un temps d’arrêt au pic de contraction.',
      'Redescendez lentement sans balancer le dos.'
    ],
    tips: ['Gardez les coudes immobiles', 'Ne balancez pas le tronc'],
    animationType: 'bicep_curl'
  },
  {
    id: 'triceps-dips',
    name: 'Dips aux barres parallèles',
    targetMuscles: ['arms', 'chest', 'shoulders'],
    targetMusclesLabels: ['Triceps', 'Bas de poitrine', 'Épaules'],
    primaryMuscle: 'arms',
    defaultSets: 4,
    defaultReps: '10-15',
    restSeconds: 75,
    description: 'Constructeur massif pour les triceps et la puissance globale de répulsion.',
    executionSteps: [
      'En suspension sur les barres parallèles, bras tendus sans verrouillage excessif.',
      'Descendez en fléchissant les coudes jusqu’à former un angle de 90°.',
      'Poussez fermement pour revenir en position haute.'
    ],
    tips: ['Restez le buste droit pour focaliser sur les triceps', 'Contrôlez impérativement la descente'],
    animationType: 'dips'
  },

  // ABS
  {
    id: 'hanging-leg-raise',
    name: 'Relevé de jambes à la barre',
    targetMuscles: ['abs'],
    targetMusclesLabels: ['Bas des abdos', 'Fléchisseurs'],
    primaryMuscle: 'abs',
    defaultSets: 4,
    defaultReps: '12-15',
    restSeconds: 60,
    description: 'Sculpte les tablettes de chocolat et renforce le centre du corps.',
    executionSteps: [
      'Suspendu à la barre fixe, corps immobile.',
      'Montez les genoux ou jambes tendues en enroulant le bassin vers le thorax.',
      'Marquez une seconde de contraction intense.',
      'Redescendez sans effet de balancier.'
    ],
    tips: ['Enroulez le bassin vers le haut pour cibler les abdominaux et non seulement les cuisses', 'Contrôlez la descente'],
    animationType: 'crunch'
  },

  // CALVES
  {
    id: 'standing-calf-raise',
    name: 'Mollets debout à la machine',
    targetMuscles: ['calves'],
    targetMusclesLabels: ['Mollets (Gastrocnémiens)'],
    primaryMuscle: 'calves',
    defaultSets: 4,
    defaultReps: '15-20',
    restSeconds: 45,
    description: 'Donne du volume et de l’explosivité aux mollets.',
    executionSteps: [
      'Pieds sur la cale, talons dans le vide.',
      'Descendez le plus bas possible pour étirer les fibres musculaires.',
      'Montez sur la pointe des pieds à amplitude maximale et maintenez la contraction.'
    ],
    tips: ['Ne rebondissez pas au point bas', 'Amplitude complète obligatoire'],
    animationType: 'calf_raise'
  },

  // FOREARMS
  {
    id: 'wrist-curls',
    name: 'Curl poignets barre',
    targetMuscles: ['forearms'],
    targetMusclesLabels: ['Avant-bras', 'Grip de Chasseur'],
    primaryMuscle: 'forearms',
    defaultSets: 3,
    defaultReps: '15-20',
    restSeconds: 45,
    description: 'Renforce la poigne de fer pour soulever des charges colossales.',
    executionSteps: [
      'Avant-bras posés sur les cuisses ou un banc plat, poignets dans le vide.',
      'Laissez dérouler la barre sur le bout des doigts puis enroulez les poignets vers le haut.',
      'Contractez au sommet.'
    ],
    tips: ['Gardez les avant-bras bien plaqués', 'Mouvement strict sans à-coups'],
    animationType: 'bicep_curl'
  }
];

export function getExercisesForMuscles(selectedMuscleIds: MuscleId[]): ExerciseDefinition[] {
  if (selectedMuscleIds.length === 0) {
    return EXERCISES_DATABASE.slice(0, 4);
  }

  // Filter exercises that touch at least one of the selected muscles
  const matches = EXERCISES_DATABASE.filter(ex => 
    ex.targetMuscles.some(m => selectedMuscleIds.includes(m))
  );

  // Sort: exercises whose primary muscle is in the selection first
  matches.sort((a, b) => {
    const aPrimary = selectedMuscleIds.includes(a.primaryMuscle) ? 1 : 0;
    const bPrimary = selectedMuscleIds.includes(b.primaryMuscle) ? 1 : 0;
    return bPrimary - aPrimary;
  });

  return matches.length > 0 ? matches : EXERCISES_DATABASE.slice(0, 4);
}
