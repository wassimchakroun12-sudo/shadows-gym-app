import React, { useState } from 'react';
import { HunterProfile } from '../types';
import { sounds, saveHunterProfile, normalizeEmail, switchEmailAccount } from '../utils/hunterSystem';
import { Translations } from '../i18n/translations';
import { User, Mail, Shield, ArrowRight, Activity, Target, Sparkles, KeyRound } from 'lucide-react';

interface OnboardingScreenProps {
  initialProfile: HunterProfile;
  onComplete: (completedProfile: HunterProfile) => void;
  onOpenLogin: () => void;
  t: Translations;
}

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({
  initialProfile,
  onComplete,
  onOpenLogin,
  t,
}) => {
  const [email, setEmail] = useState(initialProfile.email || 'wassimchakroun12@gmail.com');
  const [name, setName] = useState(initialProfile.name || 'Wassim');
  const [age, setAge] = useState<number | string>(initialProfile.age || 23);
  const [weight, setWeight] = useState<number | string>(initialProfile.weightKg || 78);
  const [height, setHeight] = useState<number | string>(initialProfile.heightCm || 180);
  const [fitnessGoal, setFitnessGoal] = useState<string>(
    initialProfile.fitnessGoal || 'Hypertrophie & Puissance Monarque'
  );
  const [emailError, setEmailError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = normalizeEmail(email);
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setEmailError(t.auth.enterEmailAlert);
      return;
    }

    sounds.playLevelUp();

    const finalizedProfile: HunterProfile = {
      ...initialProfile,
      email: cleanEmail,
      isEmailLinked: true,
      onboardingCompleted: true,
      name: name.trim() || 'Wassim',
      age: Number(age) || 23,
      weightKg: Number(weight) || 78,
      heightCm: Number(height) || 180,
      fitnessGoal,
    };

    saveHunterProfile(finalizedProfile);
    onComplete(finalizedProfile);
  };

  const calculatedBmi = Number(height) > 0
    ? (Number(weight) / Math.pow(Number(height) / 100, 2)).toFixed(1)
    : '24.1';

  return (
    <div className="min-h-screen bg-[#07050f] text-slate-100 flex flex-col items-center justify-center p-4 sm:p-6 relative overflow-hidden">
      {/* Background neon glows */}
      <div 
        className="fixed inset-0 pointer-events-none z-0 opacity-40"
        style={{
          background: 'radial-gradient(circle at 50% 20%, rgba(147, 51, 234, 0.25) 0%, transparent 60%), radial-gradient(circle at 80% 80%, rgba(88, 28, 135, 0.2) 0%, transparent 50%)'
        }}
      />

      <div className="w-full max-w-2xl relative z-10 py-8">
        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center mb-3">
            <img
              src="/src/assets/images/shadows_isolated_logo_1791833127584.jpg"
              alt="Logo Shadows Gym"
              className="h-16 w-16 sm:h-20 sm:w-20 object-contain mix-blend-screen drop-shadow-[0_0_18px_rgba(168,85,247,0.9)] animate-pulse"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/90 border border-purple-600/70 text-purple-300 font-mono text-xs uppercase tracking-wider mb-2 shadow-[0_0_12px_rgba(147,51,234,0.4)]">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            {t.auth.onboardingTitle}
          </div>
          <h1 className="text-2xl sm:text-4xl font-black font-mono tracking-tight text-white drop-shadow-[0_0_10px_rgba(192,132,252,0.6)]">
            {t.auth.onboardingSubtitle}
          </h1>
          <p className="text-xs sm:text-sm text-purple-300/80 mt-2 max-w-lg mx-auto">
            {t.auth.onboardingDesc}
          </p>
        </div>

        {/* Main Onboarding Card */}
        <div className="bg-[#0b081c]/95 border border-purple-700/60 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-[0_0_50px_rgba(147,51,234,0.25)]">
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* 1. Email field */}
            <div>
              <label className="block text-xs font-mono text-purple-300 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-purple-400" />
                  {t.auth.emailLabel} *
                </span>
                <span className="text-[10px] text-purple-400/70 font-normal">
                  (Liaison permanente des progrès)
                </span>
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setEmailError('');
                }}
                placeholder="wassimchakroun12@gmail.com"
                className="w-full bg-[#130d2d] border border-purple-700/70 focus:border-purple-400 focus:shadow-[0_0_15px_rgba(168,85,247,0.5)] rounded-xl px-4 py-3 text-white placeholder-purple-400/40 text-sm font-mono outline-none transition-all"
              />
              {emailError && (
                <p className="text-xs text-red-400 mt-1 font-mono">{emailError}</p>
              )}
            </div>

            {/* 2. Nom de Chasseur */}
            <div>
              <label className="block text-xs font-mono text-purple-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-purple-400" />
                {t.info.nameLabel} *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Wassim, Sung Jin-Woo..."
                className="w-full bg-[#130d2d] border border-purple-700/70 focus:border-purple-400 focus:shadow-[0_0_15px_rgba(168,85,247,0.5)] rounded-xl px-4 py-3 text-white placeholder-purple-400/40 text-sm font-mono outline-none transition-all"
              />
            </div>

            {/* 3. Âge / Poids / Taille */}
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-purple-300 uppercase tracking-wider mb-1.5">
                  {t.info.ageLabel}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="12"
                    max="100"
                    required
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="w-full bg-[#130d2d] border border-purple-700/70 focus:border-purple-400 rounded-xl px-3 py-2.5 text-white text-sm font-mono outline-none"
                  />
                  <span className="absolute right-2.5 top-2.5 text-xs text-purple-400/60 font-mono">ans</span>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-purple-300 uppercase tracking-wider mb-1.5">
                  {t.info.weightLabel}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="30"
                    max="250"
                    required
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    className="w-full bg-[#130d2d] border border-purple-700/70 focus:border-purple-400 rounded-xl px-3 py-2.5 text-white text-sm font-mono outline-none"
                  />
                  <span className="absolute right-2.5 top-2.5 text-xs text-purple-400/60 font-mono">kg</span>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-purple-300 uppercase tracking-wider mb-1.5">
                  {t.info.heightLabel}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="100"
                    max="250"
                    required
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    className="w-full bg-[#130d2d] border border-purple-700/70 focus:border-purple-400 rounded-xl px-3 py-2.5 text-white text-sm font-mono outline-none"
                  />
                  <span className="absolute right-2.5 top-2.5 text-xs text-purple-400/60 font-mono">cm</span>
                </div>
              </div>
            </div>

            {/* 4. Objectif */}
            <div>
              <label className="block text-xs font-mono text-purple-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-purple-400" />
                {t.info.goalLabel}
              </label>
              <select
                value={fitnessGoal}
                onChange={(e) => setFitnessGoal(e.target.value)}
                className="w-full bg-[#130d2d] border border-purple-700/70 focus:border-purple-400 rounded-xl px-4 py-3 text-white text-sm font-mono outline-none cursor-pointer"
              >
                <option value="Hypertrophie & Puissance Monarque">
                  Hypertrophie & Puissance Monarque (Gain de masse & force)
                </option>
                <option value="Perte de gras & Définition des Ombres">
                  Perte de gras & Définition athlétique
                </option>
                <option value="Force Pure & Puissance de Rang S">
                  Force pure & Puissance explosive
                </option>
                <option value="Condition physique & Endurance de Chasseur">
                  Endurance & Mobilité générale
                </option>
              </select>
            </div>

            {/* IMC & Calibration badge */}
            <div className="p-3.5 rounded-xl bg-purple-950/40 border border-purple-800/40 flex items-center justify-between text-xs font-mono">
              <span className="text-purple-300 flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-cyan-400" />
                {t.info.bmiLabel} : <strong className="text-white">{calculatedBmi}</strong>
              </span>
              <span className="text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-2 py-0.5 rounded text-[10px]">
                CALIBRATION AUTOMATIQUE
              </span>
            </div>

            {/* Submit button */}
            <button
              type="submit"
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-mono font-black text-sm uppercase tracking-wider flex items-center justify-center gap-3 shadow-[0_0_25px_rgba(168,85,247,0.5)] hover:shadow-[0_0_40px_rgba(168,85,247,0.8)] transition-all active:scale-[0.99]"
            >
              <Shield className="w-4 h-4 text-cyan-300" />
              {t.auth.btnAwaken}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Already have account switch */}
          <div className="mt-6 pt-5 border-t border-purple-900/40 text-center">
            <button
              type="button"
              onClick={() => {
                sounds.playClick();
                onOpenLogin();
              }}
              className="inline-flex items-center gap-2 text-xs font-mono text-purple-300 hover:text-white transition-colors underline-offset-4 hover:underline"
            >
              <KeyRound className="w-3.5 h-3.5 text-purple-400" />
              {t.auth.alreadyHaveAccount}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
