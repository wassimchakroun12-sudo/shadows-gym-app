import React from 'react';
import { HunterProfile } from '../types';
import { RANKS_CONFIG, sounds } from '../utils/hunterSystem';
import { Language, Translations } from '../i18n/translations';
import {
  Volume2,
  VolumeX,
  User,
  Dumbbell,
  Shield,
  Menu,
  X,
  Settings as SettingsIcon,
  Moon,
  Sun,
  Globe,
  Mail,
  Download,
  Check,
} from 'lucide-react';

interface NavbarProps {
  currentTab: 'home' | 'workout' | 'profile' | 'programs' | 'settings';
  onSelectTab: (tab: 'home' | 'workout' | 'profile' | 'programs' | 'settings') => void;
  profile: HunterProfile;
  t: Translations;
  theme: 'dark' | 'light';
  onThemeToggle: () => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenAuthModal: () => void;
  onOpenInstallModal: () => void;
  isInstalled?: boolean;
  isInstallable?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  profile,
  t,
  theme,
  onThemeToggle,
  language,
  onLanguageChange,
  onOpenAuthModal,
  onOpenInstallModal,
  isInstalled,
  isInstallable,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [isMuted, setIsMuted] = React.useState(sounds.getMuted());

  const handleToggleSound = () => {
    const nextMute = sounds.toggleMute();
    setIsMuted(nextMute);
  };

  const rankInfo = RANKS_CONFIG[profile.rank];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#07050f]/90 dark:bg-[#07050f]/90 backdrop-blur-md border-b border-purple-950/60 shadow-[0_4px_25px_rgba(0,0,0,0.5)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between gap-3">
        {/* Left Side: Brand Logo (clean without square box) */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('home');
            }}
            className="flex items-center gap-2.5 group text-left"
          >
            {/* Shadows Gym Official Hunter Emblem - No square border */}
            <img
              src="/src/assets/images/shadows_isolated_logo_1791833127584.jpg"
              alt="Logo Shadows Gym"
              className="h-11 sm:h-12 w-11 sm:w-12 object-contain mix-blend-screen shrink-0 group-hover:scale-105 transition-transform drop-shadow-[0_0_10px_rgba(168,85,247,0.8)]"
              referrerPolicy="no-referrer"
            />
            <div>
              <span className="text-lg sm:text-xl font-black font-mono tracking-wider text-white group-hover:text-purple-300 transition-colors drop-shadow-[0_0_8px_rgba(192,132,252,0.8)]">
                SHADOWS GYM
              </span>
              <div className="text-[9px] font-mono tracking-widest text-purple-400 uppercase leading-none hidden sm:block">
                SOLO LEVELING FITNESS
              </div>
            </div>
          </button>
        </div>

        {/* Center: Desktop Navigation Links translated */}
        <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold tracking-wider uppercase font-mono">
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('home');
            }}
            className={`transition-colors relative py-1 ${
              currentTab === 'home'
                ? 'text-white after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-purple-500 after:shadow-[0_0_8px_#c084fc]'
                : 'text-purple-300/70 hover:text-white'
            }`}
          >
            {t.nav.home}
          </button>

          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('workout');
            }}
            className={`transition-colors relative py-1 flex items-center gap-1.5 ${
              currentTab === 'workout'
                ? 'text-white after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-purple-500 after:shadow-[0_0_8px_#c084fc]'
                : 'text-purple-300/70 hover:text-white'
            }`}
          >
            <Dumbbell className="w-3.5 h-3.5 text-purple-400" />
            {t.nav.workout}
          </button>

          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('programs');
            }}
            className={`transition-colors relative py-1 ${
              currentTab === 'programs'
                ? 'text-white after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-purple-500 after:shadow-[0_0_8px_#c084fc]'
                : 'text-purple-300/70 hover:text-white'
            }`}
          >
            {t.nav.programs}
          </button>

          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('profile');
            }}
            className={`transition-colors relative py-1 flex items-center gap-1.5 ${
              currentTab === 'profile'
                ? 'text-white after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-purple-500 after:shadow-[0_0_8px_#c084fc]'
                : 'text-purple-300/70 hover:text-white'
            }`}
          >
            <User className="w-3.5 h-3.5 text-cyan-400" />
            {t.nav.profile}
          </button>

          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('settings');
            }}
            className={`transition-colors relative py-1 flex items-center gap-1.5 ${
              currentTab === 'settings'
                ? 'text-white after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-purple-500 after:shadow-[0_0_8px_#c084fc]'
                : 'text-purple-300/70 hover:text-white'
            }`}
          >
            <SettingsIcon className="w-3.5 h-3.5 text-purple-400" />
            {t.nav.settings}
          </button>
        </nav>

        {/* Right Side: Quick Toggles (Theme, Language, Sound, Hunter status) */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Theme Quick Toggle (Dark / Light) */}
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onThemeToggle();
            }}
            className="p-2 sm:p-2.5 rounded-xl bg-[#120d28] border border-purple-800/40 text-purple-300 hover:text-white hover:bg-purple-900/40 transition-all"
            title={theme === 'dark' ? 'Passer en Mode Clair' : 'Passer en Mode Sombre'}
          >
            {theme === 'dark' ? (
              <Moon className="w-4 h-4 text-purple-300" />
            ) : (
              <Sun className="w-4 h-4 text-amber-300" />
            )}
          </button>

          {/* Language Quick Dropdown */}
          <div className="relative flex items-center bg-[#120d28] border border-purple-800/40 rounded-xl px-1.5 py-1">
            {(['fr', 'en', 'ar'] as Language[]).map((lng) => (
              <button
                key={lng}
                type="button"
                onClick={() => {
                  sounds.playClick();
                  onLanguageChange(lng);
                }}
                className={`text-[10px] font-mono uppercase px-2 py-1 rounded-lg transition-all font-bold ${
                  language === lng
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-purple-300/60 hover:text-white'
                }`}
              >
                {lng}
              </button>
            ))}
          </div>

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={handleToggleSound}
            className="p-2 sm:p-2.5 rounded-xl bg-[#120d28] border border-purple-800/40 text-purple-300 hover:text-white hover:bg-purple-900/40 transition-all hidden sm:flex"
            title={isMuted ? 'Activer les sons' : 'Couper le son'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>

          {/* PWA / App Install Button (Google & Play Store) */}
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onOpenInstallModal();
            }}
            className={`flex items-center gap-1.5 py-1.5 px-2.5 sm:px-3 rounded-xl font-mono text-xs font-bold transition-all shadow-md group ${
              isInstalled
                ? 'bg-[#0f0a24] border border-green-700/60 text-green-300 hover:border-green-500'
                : 'bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 text-white border border-purple-400/70 shadow-[0_0_15px_rgba(168,85,247,0.5)] active:scale-95'
            }`}
            title="Télécharger / Installer l'application sur Android, Google Chrome ou PC"
          >
            {isInstalled ? (
              <>
                <Check className="w-3.5 h-3.5 text-green-400" />
                <span className="hidden md:inline">{t.pwa.installed}</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5 text-purple-200 animate-bounce" />
                <span className="hidden sm:inline">{t.pwa.btnInstall}</span>
                <span className="sm:hidden">App</span>
              </>
            )}
          </button>

          {/* Email Account Portal Pill */}
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onOpenAuthModal();
            }}
            className="flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl bg-[#120d28] border border-purple-800/60 hover:border-purple-400 text-purple-300 hover:text-white transition-all text-xs font-mono shadow-sm group"
            title={profile.email ? `Compte lié: ${profile.email}` : 'Lier un compte e-mail'}
          >
            <Mail className="w-3.5 h-3.5 text-purple-400 group-hover:text-cyan-300 transition-colors" />
            <span className="hidden xl:inline max-w-[130px] truncate text-[11px] font-medium">
              {profile.email || 'Lier e-mail'}
            </span>
            <span className={`w-2 h-2 rounded-full ${profile.email ? 'bg-emerald-400 shadow-[0_0_6px_#34d399]' : 'bg-purple-500'}`} />
          </button>

          {/* Hunter Status Pill in Navbar */}
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('profile');
            }}
            className="flex items-center gap-2 py-1.5 px-2.5 sm:px-3 rounded-xl bg-purple-950/70 border border-purple-600/50 hover:border-purple-400 transition-all shadow-[0_0_12px_rgba(168,85,247,0.3)] group"
          >
            <div className="w-6 h-6 rounded-lg bg-purple-600 flex items-center justify-center text-white font-mono font-black text-xs shadow-sm">
              {profile.rank}
            </div>
            <div className="text-left hidden md:block">
              <div className="text-[10px] font-mono text-purple-300 font-bold leading-none">
                {t.nav.level} {profile.level}
              </div>
              <div className="text-[9px] font-mono text-cyan-300 leading-none mt-0.5">
                {profile.xp.toLocaleString()} {t.nav.xp}
              </div>
            </div>
          </button>

          {/* Mobile Menu Hamburger */}
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl bg-[#120d28] border border-purple-800/40 text-purple-300 hover:text-white"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#0d0922] border-b border-purple-900/60 px-4 py-4 space-y-2.5 font-mono text-xs uppercase tracking-wider">
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('home');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left py-2 px-3 rounded-lg ${
              currentTab === 'home' ? 'bg-purple-900/60 text-white font-bold' : 'text-purple-300'
            }`}
          >
            {t.nav.home}
          </button>
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('workout');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left py-2 px-3 rounded-lg ${
              currentTab === 'workout' ? 'bg-purple-900/60 text-white font-bold' : 'text-purple-300'
            }`}
          >
            {t.nav.workout}
          </button>
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('programs');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left py-2 px-3 rounded-lg ${
              currentTab === 'programs' ? 'bg-purple-900/60 text-white font-bold' : 'text-purple-300'
            }`}
          >
            {t.nav.programs}
          </button>
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('profile');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left py-2 px-3 rounded-lg ${
              currentTab === 'profile' ? 'bg-purple-900/60 text-white font-bold' : 'text-purple-300'
            }`}
          >
            {t.nav.profile} ({t.nav.level} {profile.level})
          </button>
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onOpenAuthModal();
              setIsMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 px-3 rounded-lg flex items-center justify-between bg-purple-950/40 border border-purple-800/40 text-purple-300 hover:text-white"
          >
            <span className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-purple-400" />
              <span>{profile.email ? profile.email : 'Compte E-mail'}</span>
            </span>
            <span className={`w-2 h-2 rounded-full ${profile.email ? 'bg-emerald-400' : 'bg-purple-500'}`} />
          </button>
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onOpenInstallModal();
              setIsMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-lg flex items-center justify-between bg-gradient-to-r from-purple-900/60 to-indigo-950/60 border border-purple-500/50 text-white font-bold"
          >
            <span className="flex items-center gap-2">
              <Download className="w-4 h-4 text-purple-300" />
              <span>{isInstalled ? t.pwa.installed : t.pwa.btnInstall}</span>
            </span>
            <span className="text-[10px] text-purple-300 bg-purple-950 px-2 py-0.5 rounded border border-purple-700/60">
              Google & Store
            </span>
          </button>
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onSelectTab('settings');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left py-2 px-3 rounded-lg flex items-center justify-between ${
              currentTab === 'settings' ? 'bg-purple-900/60 text-white font-bold' : 'text-purple-300'
            }`}
          >
            <span>{t.nav.settings}</span>
            <span className="text-[10px] text-cyan-300">{theme.toUpperCase()} / {language.toUpperCase()}</span>
          </button>
        </div>
      )}
    </header>
  );
};
