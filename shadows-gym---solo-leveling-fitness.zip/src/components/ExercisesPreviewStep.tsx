import React from 'react';
import { MuscleId, ExerciseDefinition } from '../types';
import { getExercisesForMuscles } from '../data/exercises';
import { sounds } from '../utils/hunterSystem';
import {
  Dumbbell,
  Clock,
  Repeat,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Zap,
  Target,
  Flame,
} from 'lucide-react';

interface ExercisesPreviewStepProps {
  selectedMuscles: MuscleId[];
  onBackToMuscles: () => void;
  onStartSession: () => void;
}

export const ExercisesPreviewStep: React.FC<ExercisesPreviewStepProps> = ({
  selectedMuscles,
  onBackToMuscles,
  onStartSession,
}) => {
  const exercises = getExercisesForMuscles(selectedMuscles);

  const totalSets = exercises.reduce((acc, ex) => acc + ex.defaultSets, 0);
  const estimatedMinutes = Math.round(totalSets * 2.5);
  const estimatedXp = 150 + totalSets * 25 + exercises.length * 50 + selectedMuscles.length * 15;

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-6 space-y-6 animate-in fade-in duration-300">
      {/* 4-Step Stepper Navigation */}
      <div className="w-full">
        <div className="grid grid-cols-4 gap-2 bg-[#0d0920] p-2 rounded-2xl border border-purple-900/50 shadow-inner">
          <button
            type="button"
            onClick={onBackToMuscles}
            className="flex items-center gap-2 p-2 rounded-xl text-purple-300/80 hover:bg-purple-950/40 text-left transition-colors"
          >
            <span className="w-5 h-5 rounded-full bg-purple-900 text-purple-300 flex items-center justify-center text-xs font-mono">
              ✓
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] text-purple-400 font-mono">1/4</div>
              <div className="text-xs font-bold text-slate-300 leading-tight">Informations</div>
            </div>
          </button>

          <button
            type="button"
            onClick={onBackToMuscles}
            className="flex items-center gap-2 p-2 rounded-xl text-purple-300/80 hover:bg-purple-950/40 text-left transition-colors"
          >
            <span className="w-5 h-5 rounded-full bg-purple-900 text-purple-300 flex items-center justify-center text-xs font-mono">
              ✓
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] text-purple-400 font-mono">2/4</div>
              <div className="text-xs font-bold text-slate-300 leading-tight">Muscles</div>
            </div>
          </button>

          <div className="flex items-center gap-2 p-2 rounded-xl bg-purple-600/30 border border-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.4)]">
            <span className="w-5 h-5 rounded-full bg-purple-500 text-white flex items-center justify-center text-xs font-mono font-bold">
              3
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] text-purple-300 font-mono">3/4</div>
              <div className="text-xs font-bold text-white leading-tight">Exercices</div>
            </div>
          </div>

          <div className="flex items-center gap-2 p-2 rounded-xl text-purple-300/60">
            <span className="w-5 h-5 rounded-full bg-purple-950/80 text-purple-400 flex items-center justify-center text-xs font-mono">
              4
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] font-mono">4/4</div>
              <div className="text-xs font-medium leading-tight">Programme</div>
            </div>
          </div>
        </div>
      </div>

      {/* Title Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#0c081e]/90 border border-purple-900/50 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-purple-950 border border-purple-600/60 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(168,85,247,0.4)]">
            <Dumbbell className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white font-mono tracking-tight uppercase">
              VOS EXERCICES SÉLECTIONNÉS (3/4)
            </h1>
            <p className="text-xs sm:text-sm text-purple-300/80 mt-0.5">
              Programme sur-mesure pour : {selectedMuscles.join(', ').toUpperCase()}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/80 border border-purple-600/50 text-purple-300 text-xs font-mono shadow-[0_0_10px_rgba(168,85,247,0.3)]">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Mode IA Personnalisé</span>
          </div>
        </div>
      </div>

      {/* KPI Overview Strip */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-[#0f0a24]/80 border border-purple-800/40 rounded-xl p-3 text-center">
          <div className="text-[11px] font-mono text-purple-300/70">EXERCICES</div>
          <div className="text-lg font-bold text-white font-mono">{exercises.length} mouvements</div>
        </div>
        <div className="bg-[#0f0a24]/80 border border-purple-800/40 rounded-xl p-3 text-center">
          <div className="text-[11px] font-mono text-purple-300/70">TOTAL SÉRIES</div>
          <div className="text-lg font-bold text-white font-mono">{totalSets} séries ({estimatedMinutes} min)</div>
        </div>
        <div className="bg-[#0f0a24]/80 border border-purple-800/40 rounded-xl p-3 text-center">
          <div className="text-[11px] font-mono text-purple-300/70">EXP À GAGNER</div>
          <div className="text-lg font-bold text-cyan-300 font-mono">+{estimatedXp} XP</div>
        </div>
      </div>

      {/* Exercise Cards Grid */}
      <div className="space-y-3">
        {exercises.map((ex, idx) => (
          <div
            key={ex.id}
            className="bg-[#0a0717]/95 border border-purple-900/40 hover:border-purple-500/70 rounded-2xl p-4 sm:p-5 backdrop-blur-md transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 group"
          >
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/60 flex items-center justify-center font-mono font-black text-purple-300 text-sm shrink-0">
                0{idx + 1}
              </div>

              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800/50 uppercase">
                    {ex.primaryMuscle}
                  </span>
                  <span className="text-xs text-purple-300/70 font-mono">
                    {ex.targetMusclesLabels.join(' · ')}
                  </span>
                </div>

                <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-purple-300 transition-colors font-mono">
                  {ex.name}
                </h3>
                <p className="text-xs text-slate-300/80 mt-1 max-w-xl">
                  {ex.description}
                </p>
              </div>
            </div>

            <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-purple-900/30">
              <div className="text-right">
                <div className="text-sm font-black text-white font-mono">
                  {ex.defaultSets} séries × {ex.defaultReps}
                </div>
                <div className="text-xs text-purple-300/70 font-mono flex items-center gap-1 justify-end mt-0.5">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  {ex.restSeconds}s de repos
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Action Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-purple-900/40">
        <button
          type="button"
          onClick={() => {
            sounds.playClick();
            onBackToMuscles();
          }}
          className="w-full sm:w-auto py-3 px-5 rounded-xl bg-purple-950/60 hover:bg-purple-900/60 border border-purple-800/60 text-purple-300 hover:text-white font-mono text-xs font-bold uppercase flex items-center justify-center gap-2 transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          Modifier les muscles
        </button>

        <button
          type="button"
          onClick={() => {
            sounds.playClick();
            onStartSession();
          }}
          className="w-full sm:w-auto py-4 px-8 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-mono font-black text-sm uppercase tracking-wider shadow-[0_0_25px_rgba(168,85,247,0.7)] flex items-center justify-center gap-2 transition-all active:scale-98"
        >
          <span>LANCER LA SÉANCE D'ENTRAÎNEMENT (4/4)</span>
          <ArrowRight className="w-4 h-4 text-purple-200" />
        </button>
      </div>
    </div>
  );
};
