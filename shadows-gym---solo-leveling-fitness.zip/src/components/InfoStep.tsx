import React, { useState } from 'react';
import { HunterProfile } from '../types';
import { sounds } from '../utils/hunterSystem';
import { Shield, User, ArrowRight, Activity, Target } from 'lucide-react';

interface InfoStepProps {
  initialProfile: HunterProfile;
  onConfirm: (data: { name: string; age: number; weightKg: number; heightCm: number; fitnessGoal: string }) => void;
}

export const InfoStep: React.FC<InfoStepProps> = ({ initialProfile, onConfirm }) => {
  const [name, setName] = useState(initialProfile.name || '');
  const [age, setAge] = useState<number | string>(initialProfile.age || 22);
  const [weight, setWeight] = useState<number | string>(initialProfile.weightKg || 75);
  const [height, setHeight] = useState<number | string>(initialProfile.heightCm || 178);
  const [fitnessGoal, setFitnessGoal] = useState<string>(initialProfile.fitnessGoal || 'Prise de masse & Force');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sounds.playClick();
    onConfirm({
      name: name.trim() || 'Chasseur Inconnu',
      age: Number(age) || 22,
      weightKg: Number(weight) || 75,
      heightCm: Number(height) || 178,
      fitnessGoal,
    });
  };

  const calculatedBmi = Number(height) > 0
    ? (Number(weight) / Math.pow(Number(height) / 100, 2)).toFixed(1)
    : '22.0';

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-8">
      {/* 4-Step Stepper Navigation */}
      <div className="w-full mb-8">
        <div className="grid grid-cols-4 gap-2 bg-[#0d0920] p-2 rounded-2xl border border-purple-900/50 shadow-inner">
          <div className="flex items-center gap-2 p-2 rounded-xl bg-purple-600/30 border border-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.3)]">
            <span className="w-5 h-5 rounded-full bg-purple-500 text-white flex items-center justify-center text-xs font-mono font-bold">1</span>
            <div className="hidden sm:block">
              <div className="text-[10px] text-purple-300 font-mono">1/4</div>
              <div className="text-xs font-bold text-white leading-tight">Informations</div>
            </div>
          </div>

          <div className="flex items-center gap-2 p-2 rounded-xl text-purple-300/60">
            <span className="w-5 h-5 rounded-full bg-purple-950/80 text-purple-400 flex items-center justify-center text-xs font-mono">2</span>
            <div className="hidden sm:block">
              <div className="text-[10px] font-mono">2/4</div>
              <div className="text-xs font-medium leading-tight">Muscles</div>
            </div>
          </div>

          <div className="flex items-center gap-2 p-2 rounded-xl text-purple-300/60">
            <span className="w-5 h-5 rounded-full bg-purple-950/80 text-purple-400 flex items-center justify-center text-xs font-mono">3</span>
            <div className="hidden sm:block">
              <div className="text-[10px] font-mono">3/4</div>
              <div className="text-xs font-medium leading-tight">Exercices</div>
            </div>
          </div>

          <div className="flex items-center gap-2 p-2 rounded-xl text-purple-300/60">
            <span className="w-5 h-5 rounded-full bg-purple-950/80 text-purple-400 flex items-center justify-center text-xs font-mono">4</span>
            <div className="hidden sm:block">
              <div className="text-[10px] font-mono">4/4</div>
              <div className="text-xs font-medium leading-tight">Programme</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Info Card */}
      <div className="bg-[#0b081c]/90 border border-purple-800/50 rounded-2xl p-6 sm:p-8 backdrop-blur-md shadow-[0_0_35px_rgba(147,51,234,0.2)]">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-purple-950/80 border border-purple-700/50 text-purple-300 font-mono text-xs uppercase tracking-wider mb-2">
            <User className="w-3.5 h-3.5 text-purple-400" />
            INITIALISATION DU PROFIL DE CHASSEUR
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight">
            VOS INFORMATIONS PHYSIQUES
          </h2>
          <p className="text-xs sm:text-sm text-purple-300/70 mt-1 max-w-md mx-auto">
            Renseignez votre profil pour calibrer le volume et l’intensité de votre entraînement de Monarque.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Nom */}
          <div>
            <label className="block text-xs font-mono text-purple-300 uppercase tracking-wider mb-1.5">
              Nom ou Pseudo de Chasseur
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Wassim, Sung Jin-Woo..."
              className="w-full bg-[#120d28] border border-purple-700/60 focus:border-purple-400 focus:shadow-[0_0_12px_rgba(168,85,247,0.4)] rounded-xl px-4 py-3 text-white placeholder-purple-400/40 text-sm font-mono outline-none transition-all"
            />
          </div>

          {/* Age, Poids, Taille */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-mono text-purple-300 uppercase tracking-wider mb-1.5">
                Âge (ans)
              </label>
              <input
                type="number"
                required
                min={12}
                max={99}
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="22"
                className="w-full bg-[#120d28] border border-purple-700/60 focus:border-purple-400 focus:shadow-[0_0_12px_rgba(168,85,247,0.4)] rounded-xl px-4 py-3 text-white placeholder-purple-400/40 text-sm font-mono outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-purple-300 uppercase tracking-wider mb-1.5">
                Poids (kg)
              </label>
              <input
                type="number"
                required
                min={35}
                max={250}
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder="75"
                className="w-full bg-[#120d28] border border-purple-700/60 focus:border-purple-400 focus:shadow-[0_0_12px_rgba(168,85,247,0.4)] rounded-xl px-4 py-3 text-white placeholder-purple-400/40 text-sm font-mono outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-purple-300 uppercase tracking-wider mb-1.5">
                Taille (cm)
              </label>
              <input
                type="number"
                required
                min={120}
                max={240}
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                placeholder="178"
                className="w-full bg-[#120d28] border border-purple-700/60 focus:border-purple-400 focus:shadow-[0_0_12px_rgba(168,85,247,0.4)] rounded-xl px-4 py-3 text-white placeholder-purple-400/40 text-sm font-mono outline-none transition-all"
              />
            </div>
          </div>

          {/* Goal selection */}
          <div>
            <label className="block text-xs font-mono text-purple-300 uppercase tracking-wider mb-1.5">
              Objectif d’Entraînement
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {[
                'Prise de masse & Force',
                'Perte de gras & Définition',
                'Endurance & Agilité de Chasseur',
              ].map((goal) => (
                <button
                  key={goal}
                  type="button"
                  onClick={() => {
                    sounds.playClick();
                    setFitnessGoal(goal);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all font-mono text-xs ${
                    fitnessGoal === goal
                      ? 'bg-purple-900/60 border-purple-400 text-white shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                      : 'bg-[#120d28]/70 border-purple-900/40 text-purple-300/70 hover:border-purple-700 hover:text-white'
                  }`}
                >
                  <div className="font-bold">{goal}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Stats Diagnostic */}
          <div className="bg-[#120d2a] border border-purple-800/40 rounded-xl p-3 flex items-center justify-between text-xs font-mono">
            <span className="text-purple-300 flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-cyan-400" />
              Indice Corporel Estimé (IMC) :
            </span>
            <span className="text-cyan-300 font-bold text-sm">
              {calculatedBmi} (Optimal)
            </span>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black font-mono text-sm uppercase tracking-wider shadow-[0_0_25px_rgba(168,85,247,0.6)] flex items-center justify-center gap-2 transition-all active:scale-98"
            >
              CONFIRMER & SÉLECTIONNER LES MUSCLES
              <ArrowRight className="w-4 h-4 text-purple-200" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
