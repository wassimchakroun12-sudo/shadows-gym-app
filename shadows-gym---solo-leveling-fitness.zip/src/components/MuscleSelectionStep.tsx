import React, { useState } from 'react';
import { MuscleId, ExerciseDefinition } from '../types';
import { MUSCLE_GROUPS, getExercisesForMuscles } from '../data/exercises';
import { AnatomyFigure } from './AnatomyFigure';
import { sounds } from '../utils/hunterSystem';
import {
  Target,
  Check,
  Dumbbell,
  Clock,
  Repeat,
  Sparkles,
  ArrowRight,
  ChevronRight,
  Activity,
  Layers,
} from 'lucide-react';

interface MuscleSelectionStepProps {
  selectedMuscles: MuscleId[];
  onSelectedMusclesChange: (muscles: MuscleId[]) => void;
  onProceedToExercises: () => void;
  onBackToInfo: () => void;
}

export const MuscleSelectionStep: React.FC<MuscleSelectionStepProps> = ({
  selectedMuscles,
  onSelectedMusclesChange,
  onProceedToExercises,
  onBackToInfo,
}) => {
  const [view, setView] = useState<'front' | 'back'>('front');
  const [hoveredMuscle, setHoveredMuscle] = useState<MuscleId | null>(null);
  const [activeTabMode, setActiveTabMode] = useState<'ia' | 'custom'>('ia');

  const toggleMuscle = (id: MuscleId) => {
    sounds.playClick();
    if (selectedMuscles.includes(id)) {
      onSelectedMusclesChange(selectedMuscles.filter((m) => m !== id));
    } else {
      onSelectedMusclesChange([...selectedMuscles, id]);
    }
  };

  const handleSelectAll = () => {
    sounds.playClick();
    if (selectedMuscles.length === MUSCLE_GROUPS.length) {
      onSelectedMusclesChange([]);
    } else {
      onSelectedMusclesChange(MUSCLE_GROUPS.map((m) => m.id));
    }
  };

  const currentProgramExercises = getExercisesForMuscles(selectedMuscles);

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-6 space-y-6">
      {/* 4-Step Stepper Navigation */}
      <div className="w-full">
        <div className="grid grid-cols-4 gap-2 bg-[#0d0920] p-2 rounded-2xl border border-purple-900/50 shadow-inner">
          <div className="flex items-center gap-2 p-2 rounded-xl text-purple-300/80">
            <span className="w-5 h-5 rounded-full bg-purple-900 text-purple-300 flex items-center justify-center text-xs font-mono">
              ✓
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] text-purple-400 font-mono">1/4</div>
              <div className="text-xs font-bold text-slate-300 leading-tight">Informations</div>
            </div>
          </div>

          <div className="flex items-center gap-2 p-2 rounded-xl bg-purple-600/30 border border-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.4)]">
            <span className="w-5 h-5 rounded-full bg-purple-500 text-white flex items-center justify-center text-xs font-mono font-bold">
              2
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] text-purple-300 font-mono">2/4</div>
              <div className="text-xs font-bold text-white leading-tight">Muscles</div>
            </div>
          </div>

          <div className="flex items-center gap-2 p-2 rounded-xl text-purple-300/60">
            <span className="w-5 h-5 rounded-full bg-purple-950/80 text-purple-400 flex items-center justify-center text-xs font-mono">
              3
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] font-mono">3/4</div>
              <div className="text-xs font-medium leading-tight">Exercices</div>
            </div>
          </div>

          <div className="flex items-center gap-2 p-2 rounded-xl text-purple-300/60">
            <span className="w-5 h-5 rounded-full bg-purple-950/80 text-purple-400 flex items-center justify-center text-xs font-mono">
              4
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] font-mono">4/4</div>
              <div className="text-xs font-medium leading-tight">Programme</div>
            </div>
          </div>
        </div>
      </div>

      {/* Title Section matching Image 2 */}
      <div className="flex items-start gap-4 p-4 rounded-2xl bg-[#0c081e]/80 border border-purple-900/40 backdrop-blur-md">
        <div className="w-12 h-12 rounded-xl bg-purple-950 border border-purple-600/60 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(168,85,247,0.4)]">
          <Target className="w-6 h-6 text-purple-400" />
        </div>
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-mono tracking-tight uppercase">
            SÉLECTIONNEZ VOS GROUPES MUSCULAIRES
          </h1>
          <p className="text-xs sm:text-sm text-purple-300/80 mt-1">
            Choisissez les muscles que vous souhaitez entraîner. Vous pourrez en sélectionner autant que vous le souhaitez.
          </p>
        </div>
      </div>

      {/* Main Dual Grid: Anatomical Figure on Left, Muscle List on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left Column: Anatomical Figure */}
        <div className="lg:col-span-6 flex flex-col">
          <AnatomyFigure
            view={view}
            onViewChange={setView}
            selectedMuscles={selectedMuscles}
            onToggleMuscle={toggleMuscle}
            hoveredMuscle={hoveredMuscle}
            setHoveredMuscle={setHoveredMuscle}
          />
        </div>

        {/* Right Column: Muscles List Matching Image 2 */}
        <div className="lg:col-span-6 flex flex-col bg-[#0a0717]/90 border border-purple-900/40 rounded-2xl p-4 sm:p-6 backdrop-blur-md shadow-[0_0_25px_rgba(112,26,179,0.15)] justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-3">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" />
                <span className="text-sm font-black text-white font-mono uppercase tracking-wider">
                  MUSCLES SÉLECTIONNÉS
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={handleSelectAll}
                  className="text-[11px] font-mono text-purple-300 hover:text-white transition-colors"
                >
                  {selectedMuscles.length === MUSCLE_GROUPS.length ? 'Désélectionner tout' : 'Tout sélectionner'}
                </button>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-purple-950/80 border border-purple-700/60 text-purple-300">
                  {selectedMuscles.length}/{MUSCLE_GROUPS.length}
                </span>
              </div>
            </div>

            {/* List of 10 muscles */}
            <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1">
              {MUSCLE_GROUPS.map((muscle) => {
                const active = selectedMuscles.includes(muscle.id);
                return (
                  <div
                    key={muscle.id}
                    onClick={() => toggleMuscle(muscle.id)}
                    onMouseEnter={() => setHoveredMuscle(muscle.id)}
                    onMouseLeave={() => setHoveredMuscle(null)}
                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all duration-200 select-none ${
                      active
                        ? 'bg-purple-950/60 border-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.3)]'
                        : 'bg-[#120d28]/40 border-purple-900/30 hover:border-purple-700/60 hover:bg-purple-950/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {/* Icon container */}
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                          active
                            ? 'bg-purple-700 text-white shadow-[0_0_8px_#c084fc]'
                            : 'bg-purple-950/70 text-purple-400'
                        }`}
                      >
                        <Activity className="w-4 h-4" />
                      </div>
                      <div>
                        <div className={`text-sm font-bold font-mono ${active ? 'text-white' : 'text-slate-300'}`}>
                          {muscle.name}
                        </div>
                        <div className="text-[11px] text-purple-300/60 font-mono">
                          {muscle.subname}
                        </div>
                      </div>
                    </div>

                    {/* Checkbox button */}
                    <div
                      className={`w-6 h-6 rounded-lg flex items-center justify-center border transition-all ${
                        active
                          ? 'bg-purple-600 border-purple-400 text-white shadow-[0_0_8px_#c084fc]'
                          : 'border-purple-800/60 bg-transparent text-transparent'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-purple-900/30 flex items-center justify-between text-xs font-mono text-purple-300/70">
            <span>Sélectionnez au moins 1 muscle pour générer vos exercices</span>
            <span className="text-cyan-400 font-bold">
              {selectedMuscles.length > 0 ? `${currentProgramExercises.length} exercices prêts` : 'En attente'}
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Action Bar for Muscle Selection */}
      <div className="bg-[#0a0717]/95 border border-purple-900/50 rounded-2xl p-4 sm:p-5 backdrop-blur-md shadow-[0_0_30px_rgba(112,26,179,0.2)] flex flex-col sm:flex-row items-center justify-between gap-4">
        <button
          type="button"
          onClick={() => {
            sounds.playClick();
            onBackToInfo();
          }}
          className="w-full sm:w-auto py-3 px-5 rounded-xl bg-purple-950/60 hover:bg-purple-900/60 border border-purple-800/60 text-purple-300 hover:text-white font-mono text-xs font-bold uppercase transition-all"
        >
          ← Retour aux Informations (1/4)
        </button>

        <div className="text-xs font-mono text-purple-300 text-center sm:text-left">
          {selectedMuscles.length === 0 ? (
            <span className="text-amber-400">⚠️ Sélectionnez au moins 1 muscle pour continuer</span>
          ) : (
            <span>
              <span className="text-white font-bold">{selectedMuscles.length}</span> groupes musculaires sélectionnés
            </span>
          )}
        </div>

        <button
          type="button"
          disabled={selectedMuscles.length === 0}
          onClick={() => {
            sounds.playClick();
            onProceedToExercises();
          }}
          className="w-full sm:w-auto py-3.5 px-8 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-black font-mono text-xs uppercase tracking-wider shadow-[0_0_25px_rgba(168,85,247,0.6)] flex items-center justify-center gap-2 transition-all active:scale-98"
        >
          <span>CONTINUER VERS LES EXERCICES (3/4)</span>
          <ArrowRight className="w-4 h-4 text-purple-200" />
        </button>
      </div>
    </div>
  );
};
