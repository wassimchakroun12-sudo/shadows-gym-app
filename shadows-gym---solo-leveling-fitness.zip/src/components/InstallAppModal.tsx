import React, { useState } from 'react';
import {
  Download,
  CheckCircle2,
  X,
  Smartphone,
  Globe,
  Monitor,
  WifiOff,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { sounds } from '../utils/hunterSystem';
import { Translations } from '../i18n/translations';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable: boolean;
  isInstalled: boolean;
  isIOS: boolean;
  isAndroid: boolean;
  onPromptInstall: () => Promise<'accepted' | 'dismissed' | 'unsupported'>;
  t: Translations;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({
  isOpen,
  onClose,
  isInstallable,
  isInstalled,
  isIOS,
  isAndroid,
  onPromptInstall,
  t,
}) => {
  const [activePlatform, setActivePlatform] = useState<'android' | 'playstore' | 'ios' | 'desktop'>(
    isIOS ? 'ios' : isAndroid ? 'android' : 'android'
  );
  const [installStatus, setInstallStatus] = useState<'idle' | 'success' | 'dismissed'>('idle');

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    sounds.playClick();
    const result = await onPromptInstall();
    if (result === 'accepted') {
      sounds.playLevelUp();
      setInstallStatus('success');
    } else if (result === 'dismissed') {
      setInstallStatus('dismissed');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#0a0717] border border-purple-600/50 rounded-2xl sm:rounded-3xl shadow-[0_0_50px_rgba(168,85,247,0.35)] overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Header Banner with Logo and Glowing Aura */}
        <div className="relative p-5 sm:p-6 pb-4 bg-gradient-to-b from-purple-950/70 via-purple-900/30 to-transparent border-b border-purple-900/40">
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white rounded-xl hover:bg-white/10 transition-colors"
            aria-label={t.pwa.close}
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3.5">
            <div className="relative">
              <img
                src="/src/assets/images/shadows_isolated_logo_1791833127584.jpg"
                alt="Shadows Gym"
                className="w-14 h-14 sm:w-16 sm:h-16 object-contain mix-blend-screen drop-shadow-[0_0_15px_rgba(168,85,247,0.85)]"
              />
              <div className="absolute -bottom-1 -right-1 bg-green-500 rounded-full p-0.5 border-2 border-[#0a0717]">
                <ShieldCheck className="w-3.5 h-3.5 text-white" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] sm:text-xs font-mono uppercase tracking-widest text-purple-400 font-bold bg-purple-950/80 px-2 py-0.5 rounded border border-purple-700/50">
                  APPLICATION OFFICIELLE
                </span>
                {isInstalled && (
                  <span className="text-[10px] font-mono tracking-wider text-green-400 bg-green-950/70 px-2 py-0.5 rounded border border-green-700/60 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    {t.pwa.installed}
                  </span>
                )}
              </div>
              <h2 className="text-xl sm:text-2xl font-black font-mono tracking-wider text-white mt-1 drop-shadow-[0_0_10px_rgba(168,85,247,0.8)]">
                {t.pwa.modalTitle}
              </h2>
              <p className="text-xs text-purple-300 font-mono tracking-wide">
                {t.pwa.modalSubtitle}
              </p>
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto custom-scrollbar">
          {/* Main Action Callout Banner */}
          <div className="bg-gradient-to-r from-purple-950/80 via-[#180f33] to-purple-950/80 border border-purple-500/40 rounded-2xl p-4 sm:p-5 text-center relative overflow-hidden shadow-lg">
            <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/10 rounded-full blur-2xl pointer-events-none" />

            {isInstalled ? (
              <div className="space-y-2">
                <div className="w-12 h-12 rounded-full bg-green-600/20 border border-green-500/50 mx-auto flex items-center justify-center text-green-400">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-green-300 font-mono">
                  {t.pwa.installed}
                </h3>
                <p className="text-xs text-gray-300 max-w-md mx-auto">
                  Shadows Gym est déjà installée sur cet appareil en mode autonome. Vous bénéficiez de l'expérience plein écran et du support hors-ligne.
                </p>
              </div>
            ) : isInstallable ? (
              <div className="space-y-3">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-mono font-semibold">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
                  Installation instantanée prête
                </div>
                <h3 className="text-base sm:text-lg font-bold text-white font-mono">
                  Ajoutez Shadows Gym à vos applications en 1 seconde
                </h3>
                <p className="text-xs text-purple-200/80 max-w-md mx-auto">
                  Aucun passage obligatoire par un store volumineux : Google Chrome l'installe directement sur votre téléphone ou PC.
                </p>

                <button
                  type="button"
                  onClick={handleInstallClick}
                  className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-mono font-bold text-sm tracking-wider uppercase rounded-xl shadow-[0_0_25px_rgba(168,85,247,0.6)] flex items-center justify-center gap-2.5 mx-auto transition-transform active:scale-95 cursor-pointer"
                >
                  <Download className="w-5 h-5 animate-bounce" />
                  {t.pwa.directInstallBtn}
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-mono font-semibold">
                  <Download className="w-3.5 h-3.5 text-purple-400" />
                  Guide d'installation rapide
                </div>
                <h3 className="text-base sm:text-lg font-bold text-white font-mono">
                  Comment télécharger et installer l'App :
                </h3>
                <p className="text-xs text-purple-200/80 max-w-md mx-auto">
                  Choisissez votre système ci-dessous pour voir la méthode directe sur Google Chrome, Play Store ou iPhone.
                </p>
              </div>
            )}

            {installStatus === 'success' && (
              <div className="mt-3 text-xs text-green-400 font-mono flex items-center justify-center gap-1">
                <CheckCircle2 className="w-4 h-4" />
                L'application a été ajoutée avec succès à votre appareil !
              </div>
            )}
          </div>

          {/* Platform Tabs Selector */}
          <div>
            <div className="text-xs font-mono uppercase text-gray-400 font-bold mb-2 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-purple-400" />
              Sélectionnez votre système :
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  setActivePlatform('android');
                }}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                  activePlatform === 'android'
                    ? 'bg-purple-900/40 border-purple-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]'
                    : 'bg-[#120d24] border-purple-900/40 text-gray-400 hover:text-white hover:border-purple-700/60'
                }`}
              >
                <Smartphone className="w-5 h-5 text-green-400 mb-1" />
                <span className="text-xs font-mono font-bold">Google & Android</span>
                <span className="text-[10px] text-gray-400">Direct Chrome</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  setActivePlatform('playstore');
                }}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                  activePlatform === 'playstore'
                    ? 'bg-purple-900/40 border-purple-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]'
                    : 'bg-[#120d24] border-purple-900/40 text-gray-400 hover:text-white hover:border-purple-700/60'
                }`}
              >
                <Globe className="w-5 h-5 text-blue-400 mb-1" />
                <span className="text-xs font-mono font-bold">Play Store (TWA)</span>
                <span className="text-[10px] text-gray-400">WebAPK & Store</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  setActivePlatform('ios');
                }}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                  activePlatform === 'ios'
                    ? 'bg-purple-900/40 border-purple-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]'
                    : 'bg-[#120d24] border-purple-900/40 text-gray-400 hover:text-white hover:border-purple-700/60'
                }`}
              >
                <Smartphone className="w-5 h-5 text-gray-200 mb-1" />
                <span className="text-xs font-mono font-bold">iPhone / iPad</span>
                <span className="text-[10px] text-gray-400">Safari iOS</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  setActivePlatform('desktop');
                }}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                  activePlatform === 'desktop'
                    ? 'bg-purple-900/40 border-purple-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]'
                    : 'bg-[#120d24] border-purple-900/40 text-gray-400 hover:text-white hover:border-purple-700/60'
                }`}
              >
                <Monitor className="w-5 h-5 text-indigo-400 mb-1" />
                <span className="text-xs font-mono font-bold">Ordinateur PC</span>
                <span className="text-[10px] text-gray-400">Chrome / Edge</span>
              </button>
            </div>
          </div>

          {/* Active Platform Guide Card */}
          <div className="bg-[#120c29] border border-purple-800/40 rounded-2xl p-4 sm:p-5">
            {activePlatform === 'android' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-green-400 font-mono font-bold text-sm">
                  <Smartphone className="w-4 h-4" />
                  {t.pwa.androidGoogleTitle}
                </div>
                <p className="text-xs text-gray-300 leading-relaxed">
                  {t.pwa.androidGoogleDesc}
                </p>

                <div className="bg-[#0b0718] border border-purple-900/50 rounded-xl p-3 space-y-2 text-xs font-mono text-gray-300">
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">1</span>
                    <span>Ouvrez le lien du site dans <strong>Google Chrome</strong> sur votre téléphone.</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">2</span>
                    <span>Appuyez sur le menu ⋮ (trois points) en haut à droite de Chrome.</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">3</span>
                    <span>Sélectionnez <strong>« Installer l'application »</strong> ou <strong>« Ajouter à l'écran d'accueil »</strong>.</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">4</span>
                    <span>Validez : l'icône Shadows Gym apparaîtra directement sur votre écran comme une application Android classique !</span>
                  </div>
                </div>
              </div>
            )}

            {activePlatform === 'playstore' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-blue-400 font-mono font-bold text-sm">
                  <Globe className="w-4 h-4" />
                  {t.pwa.playStoreTitle}
                </div>
                <p className="text-xs text-gray-300 leading-relaxed">
                  {t.pwa.playStoreDesc}
                </p>

                <div className="bg-[#0b0718] border border-purple-900/50 rounded-xl p-3 space-y-2.5 text-xs font-mono text-gray-300">
                  <div className="flex items-start gap-2 text-purple-300">
                    <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                    <span><strong>Architecture TWA (Trusted Web Activity)</strong> : Prête pour publication Google Play Store via Bubblewrap ou Digital Asset Links.</span>
                  </div>
                  <div className="flex items-start gap-2 text-purple-300">
                    <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                    <span><strong>Avantage immédiat</strong> : Vous n'avez pas besoin d'attendre la validation du store pour l'utiliser. La version WebAPK s'installe directement via le bouton d'installation Google ci-dessus.</span>
                  </div>
                  <div className="flex items-start gap-2 text-purple-300">
                    <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                    <span><strong>Mises à jour automatiques</strong> : Dès qu'une nouveauté est publiée, l'application se met à jour sans nécessiter de téléchargement manuel lourd.</span>
                  </div>
                </div>
              </div>
            )}

            {activePlatform === 'ios' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-gray-200 font-mono font-bold text-sm">
                  <Smartphone className="w-4 h-4" />
                  {t.pwa.iosTitle}
                </div>
                <p className="text-xs text-gray-300 leading-relaxed">
                  {t.pwa.iosDesc}
                </p>

                <div className="bg-[#0b0718] border border-purple-900/50 rounded-xl p-3 space-y-2 text-xs font-mono text-gray-300">
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">1</span>
                    <span>Ouvrez le site dans le navigateur <strong>Safari</strong> sur votre iPhone/iPad.</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">2</span>
                    <span>Appuyez sur l'icône de partage <strong>⎋ (Partager)</strong> au bas de l'écran.</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">3</span>
                    <span>Faites défiler vers le bas et touchez <strong>« Sur l'écran d'accueil »</strong> ➕.</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">4</span>
                    <span>Touchez <strong>« Ajouter »</strong> en haut à droite. L'application est installée !</span>
                  </div>
                </div>
              </div>
            )}

            {activePlatform === 'desktop' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-indigo-400 font-mono font-bold text-sm">
                  <Monitor className="w-4 h-4" />
                  {t.pwa.desktopTitle}
                </div>
                <p className="text-xs text-gray-300 leading-relaxed">
                  {t.pwa.desktopDesc}
                </p>

                <div className="bg-[#0b0718] border border-purple-900/50 rounded-xl p-3 space-y-2 text-xs font-mono text-gray-300">
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">1</span>
                    <span>Dans <strong>Google Chrome</strong> ou <strong>Microsoft Edge</strong> sur votre ordinateur.</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">2</span>
                    <span>Regardez à droite de la barre d'adresse pour trouver l'icône d'installation <strong>⊕ (Installer Shadows Gym)</strong>.</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-purple-700 text-white flex items-center justify-center text-[11px] shrink-0 font-bold">3</span>
                    <span>Ou cliquez directement sur le bouton <strong>« Installer directement »</strong> en haut de cette fenêtre.</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Features Highlights: Offline, Storage, Notifications */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="bg-[#100a26] border border-purple-900/40 rounded-xl p-3.5 flex items-start gap-3">
              <div className="p-2 rounded-lg bg-purple-950/80 text-purple-400 border border-purple-800/40 shrink-0">
                <WifiOff className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold font-mono text-white">
                  {t.pwa.offlineFeatureTitle}
                </h4>
                <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">
                  {t.pwa.offlineFeatureDesc}
                </p>
              </div>
            </div>

            <div className="bg-[#100a26] border border-purple-900/40 rounded-xl p-3.5 flex items-start gap-3">
              <div className="p-2 rounded-lg bg-purple-950/80 text-green-400 border border-purple-800/40 shrink-0">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold font-mono text-white">
                  Sauvegarde & Profil Lié
                </h4>
                <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">
                  Votre nom, âge, niveau, rang et adresse e-mail restent synchronisés même après fermeture de l'application.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Close Button */}
        <div className="p-4 bg-[#090615] border-t border-purple-900/40 flex items-center justify-end">
          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-purple-950/80 hover:bg-purple-900 text-purple-300 font-mono text-xs font-bold tracking-wider uppercase border border-purple-700/50 transition-colors"
          >
            {t.pwa.close}
          </button>
        </div>
      </div>
    </div>
  );
};
