import React from 'react';
import { HunterRank, HunterStats } from '../types';
import { RANKS_CONFIG } from '../utils/hunterSystem';
import { Zap, Trophy, Shield, Flame, CheckCircle, ArrowRight } from 'lucide-react';

interface SystemAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  hunterName: string;
  xpGained: number;
  levelBefore: number;
  levelAfter: number;
  rankBefore: HunterRank;
  rankAfter: HunterRank;
  statGains: HunterStats;
}

export const SystemAlertModal: React.FC<SystemAlertModalProps> = ({
  isOpen,
  onClose,
  hunterName,
  xpGained,
  levelBefore,
  levelAfter,
  rankBefore,
  rankAfter,
  statGains,
}) => {
  if (!isOpen) return null;

  const isLevelUp = levelAfter > levelBefore;
  const isRankUp = rankAfter !== rankBefore;
  const currentRankInfo = RANKS_CONFIG[rankAfter];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
      {/* Outer Glow & Particle Border */}
      <div 
        className="w-full max-w-lg bg-[#0c081e] border-2 border-purple-500 rounded-2xl p-6 sm:p-8 relative shadow-[0_0_50px_rgba(168,85,247,0.4)] overflow-hidden"
        style={{
          boxShadow: '0 0 60px rgba(147, 51, 234, 0.4), inset 0 0 30px rgba(147, 51, 234, 0.15)',
        }}
      >
        {/* Hologram Grid Backdrop */}
        <div 
          className="absolute inset-0 opacity-20 pointer-events-none"
          style={{
            backgroundImage: 'linear-gradient(to right, rgba(168, 85, 247, 0.15) 1px, transparent 1px), linear-gradient(to bottom, rgba(168, 85, 247, 0.15) 1px, transparent 1px)',
            backgroundSize: '24px 24px',
          }}
        />

        {/* Ambient Corner Accents */}
        <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-cyan-400" />
        <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-cyan-400" />
        <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-cyan-400" />
        <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-cyan-400" />

        {/* System Alert Header */}
        <div className="flex flex-col items-center text-center relative z-10 mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-purple-950/80 border border-purple-500/60 text-purple-300 font-mono text-xs tracking-widest uppercase mb-3 shadow-[0_0_10px_rgba(168,85,247,0.4)]">
            <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            [ NOTIFICATION DU SYSTÈME ]
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-mono tracking-wide drop-shadow-[0_0_10px_rgba(192,132,252,0.8)]">
            {isRankUp ? 'ÉVEIL DE RANG SUPÉRIEUR !' : isLevelUp ? 'MONTÉE EN NIVEAU !' : 'QUÊTE ACCOMPLIE !'}
          </h2>

          <p className="text-sm text-purple-200/80 mt-1">
            Félicitations, Chasseur <span className="text-purple-300 font-bold">{hunterName}</span>. Le Système a validé votre entraînement.
          </p>
        </div>

        {/* Rank & Level Status Banner */}
        <div className="bg-purple-950/50 border border-purple-700/50 rounded-xl p-4 mb-6 relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-700 to-indigo-900 border border-purple-400 flex flex-col items-center justify-center shadow-[0_0_15px_rgba(168,85,247,0.5)]">
              <span className="text-[10px] font-mono text-purple-300">RANG</span>
              <span className="text-2xl font-black text-white font-mono leading-none">
                {rankAfter}
              </span>
            </div>
            <div>
              <div className="text-xs font-mono text-purple-300">{currentRankInfo.title}</div>
              <div className="text-lg font-bold text-white font-mono">
                Niveau {levelAfter} {isLevelUp && <span className="text-xs text-emerald-400 font-mono font-normal">(+{levelAfter - levelBefore} Niveaux)</span>}
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="text-xs font-mono text-purple-300">EXP GAGNÉ</div>
            <div className="text-xl font-extrabold text-cyan-300 font-mono drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]">
              +{xpGained} XP
            </div>
          </div>
        </div>

        {/* Attribute Boosts Preview */}
        <div className="mb-6 relative z-10">
          <div className="text-xs font-mono text-purple-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-purple-400" />
            ATTRIBUTS RENFORCÉS PAR LE SYSTÈME :
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="bg-[#140e2b] border border-purple-800/40 rounded-lg p-2.5 text-center">
              <div className="text-[11px] text-purple-300/80">FORCE</div>
              <div className="text-base font-bold text-white font-mono">+{statGains.strength}</div>
            </div>
            <div className="bg-[#140e2b] border border-purple-800/40 rounded-lg p-2.5 text-center">
              <div className="text-[11px] text-purple-300/80">AGILITÉ</div>
              <div className="text-base font-bold text-white font-mono">+{statGains.agility}</div>
            </div>
            <div className="bg-[#140e2b] border border-purple-800/40 rounded-lg p-2.5 text-center">
              <div className="text-[11px] text-purple-300/80">ENDURANCE</div>
              <div className="text-base font-bold text-white font-mono">+{statGains.endurance}</div>
            </div>
            <div className="bg-[#140e2b] border border-purple-800/40 rounded-lg p-2.5 text-center">
              <div className="text-[11px] text-purple-300/80">OMBRES</div>
              <div className="text-base font-bold text-white font-mono">+{statGains.shadowPower}</div>
            </div>
          </div>
        </div>

        {/* Claim / Confirm Button */}
        <button
          type="button"
          onClick={onClose}
          className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm tracking-wider uppercase font-mono shadow-[0_0_25px_rgba(168,85,247,0.6)] flex items-center justify-center gap-2 transition-all active:scale-98 relative z-10"
        >
          <CheckCircle className="w-5 h-5 text-white" />
          RÉCUPÉRER LES RÉCOMPENSES
        </button>
      </div>
    </div>
  );
};
