import React, { useState, useEffect } from 'react';
import { ExerciseDefinition } from '../types';
import { Activity, Flame, Shield, Play, Pause } from 'lucide-react';

interface ExerciseAnimationProps {
  exercise: ExerciseDefinition;
}

export const ExerciseAnimation: React.FC<ExerciseAnimationProps> = ({ exercise }) => {
  const [repCount, setRepCount] = useState(1);
  const [phase, setPhase] = useState<'concentric' | 'eccentric'>('concentric');
  const type = exercise.animationType;

  // Rep cycle counter simulating sport fitness app loop (2.6s cycle)
  useEffect(() => {
    const repInterval = setInterval(() => {
      setRepCount((prev) => (prev % 5) + 1);
    }, 2600);

    const phaseInterval = setInterval(() => {
      setPhase((prev) => (prev === 'concentric' ? 'eccentric' : 'concentric'));
    }, 1300);

    return () => {
      clearInterval(repInterval);
      clearInterval(phaseInterval);
    };
  }, []);

  return (
    <div className="relative w-full h-64 sm:h-72 bg-[#080512] rounded-2xl border-2 border-purple-800/60 overflow-hidden flex flex-col items-center justify-between p-3 select-none shadow-[0_0_35px_rgba(147,51,234,0.25)]">
      {/* Sport App Studio Floor & Overhead Spotlight */}
      <div 
        className="absolute inset-0 opacity-25 pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(circle at 50% 30%, rgba(168, 85, 247, 0.4) 0%, transparent 70%), linear-gradient(to right, rgba(168, 85, 247, 0.1) 1px, transparent 1px), linear-gradient(to bottom, rgba(168, 85, 247, 0.1) 1px, transparent 1px)',
          backgroundSize: '100% 100%, 20px 20px, 20px 20px'
        }}
      />

      {/* Gym Floor Ground Plane */}
      <div className="absolute bottom-0 inset-x-0 h-16 bg-gradient-to-t from-purple-950/60 via-purple-950/20 to-transparent pointer-events-none" />

      {/* Top HUD Strip: Sport App Live Animation Status */}
      <div className="w-full flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
          </span>
          <span className="text-[11px] font-mono font-bold tracking-wider text-cyan-300 uppercase">
            FITNESS APP GIF // LOOP EN COURS
          </span>
        </div>

        {/* Live Rep Counter Tag */}
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full bg-purple-950/90 border border-purple-500/80 text-white font-mono text-xs font-bold shadow-[0_0_10px_rgba(168,85,247,0.5)]">
            RÉPÉTITION #{repCount}
          </span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/60 border border-purple-800 text-purple-300 uppercase">
            {phase === 'concentric' ? 'POUSSÉE / EFFORT' : 'DESCENTE CONTRÔLÉE'}
          </span>
        </div>
      </div>

      {/* Main Kinetic Fitness Animation Canvas */}
      <div className="w-full flex-1 flex items-center justify-center relative my-1">
        {/* Spot Light Glow underneath the lifter */}
        <div className="absolute w-48 h-20 bg-purple-600/15 rounded-full blur-xl pointer-events-none" />

        {/* 1. BENCH PRESS */}
        {type === 'bench_press' && (
          <svg viewBox="0 0 260 200" className="w-full h-full max-h-56 drop-shadow-[0_0_20px_rgba(168,85,247,0.4)]">
            {/* Gym Floor line */}
            <line x1="20" y1="180" x2="240" y2="180" stroke="#3b0764" strokeWidth="2" strokeDasharray="4 4" />

            {/* Incline / Flat Workout Bench with steel frame */}
            <rect x="35" y="130" width="180" height="12" rx="3" fill="#1e1338" stroke="#7e22ce" strokeWidth="2" />
            <path d="M55,142 L55,180 M195,142 L195,180" stroke="#6b21a8" strokeWidth="4" strokeLinecap="round" />
            <rect x="45" y="176" width="20" height="4" fill="#a855f7" rx="1" />
            <rect x="185" y="176" width="20" height="4" fill="#a855f7" rx="1" />

            {/* Athlete lying on bench */}
            {/* Head & Neck */}
            <circle cx="68" cy="122" r="11" fill="#2e1065" stroke="#c084fc" strokeWidth="1.5" />
            {/* Torso with active Chest Muscle Striations glowing */}
            <rect x="80" y="118" width="85" height="18" rx="5" fill="#3b0764" stroke="#a855f7" strokeWidth="2" />
            {/* Glowing active Pectoralis major zone */}
            <path d="M90,120 Q120,116 150,120 Q120,128 90,120 Z" fill="#ec4899" opacity="0.9" filter="drop-shadow(0 0 8px #f43f5e)" />
            {/* Bent Athlete Legs on floor */}
            <polyline points="165,127 185,145 190,180" fill="none" stroke="#7c3aed" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />

            {/* Kinetic Barbell & Muscle Pushing Loop */}
            <g>
              <style>{`
                @keyframes benchKineticRep {
                  0% { transform: translateY(0px); }
                  45% { transform: translateY(42px); }
                  55% { transform: translateY(42px); }
                  100% { transform: translateY(0px); }
                }
                .bench-lifter-bar {
                  animation: benchKineticRep 2.6s cubic-bezier(0.4, 0, 0.2, 1) infinite;
                }
              `}</style>

              <g className="bench-lifter-bar">
                {/* Barbell Bar (Solid steel with chrome glow) */}
                <line x1="25" y1="70" x2="225" y2="70" stroke="#f3e8ff" strokeWidth="4" filter="drop-shadow(0 0 6px #c084fc)" />
                {/* Olympic Weight Plates Left */}
                <rect x="32" y="46" width="8" height="48" rx="2" fill="#7e22ce" stroke="#e9d5ff" strokeWidth="1.5" />
                <rect x="42" y="52" width="6" height="36" rx="2" fill="#9333ea" stroke="#d8b4fe" strokeWidth="1" />
                {/* Olympic Weight Plates Right */}
                <rect x="210" y="46" width="8" height="48" rx="2" fill="#7e22ce" stroke="#e9d5ff" strokeWidth="1.5" />
                <rect x="202" y="52" width="6" height="36" rx="2" fill="#9333ea" stroke="#d8b4fe" strokeWidth="1" />

                {/* Gripping Hands */}
                <circle cx="95" cy="70" r="5" fill="#f5d0fe" stroke="#a855f7" strokeWidth="1" />
                <circle cx="155" cy="70" r="5" fill="#f5d0fe" stroke="#a855f7" strokeWidth="1" />

                {/* Biomechanical Force Direction Arrow */}
                <path d="M125,50 L125,35 M120,40 L125,33 L130,40" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              </g>
            </g>
          </svg>
        )}

        {/* 2. SQUATS */}
        {type === 'squat' && (
          <svg viewBox="0 0 260 200" className="w-full h-full max-h-56 drop-shadow-[0_0_20px_rgba(168,85,247,0.4)]">
            <style>{`
              @keyframes squatKineticRep {
                0% { transform: translateY(0px); }
                45% { transform: translateY(40px); }
                55% { transform: translateY(40px); }
                100% { transform: translateY(0px); }
              }
              .squat-lifter-group {
                animation: squatKineticRep 2.6s cubic-bezier(0.4, 0, 0.2, 1) infinite;
                transform-origin: center bottom;
              }
            `}</style>
            {/* Gym Floor */}
            <line x1="20" y1="185" x2="240" y2="185" stroke="#3b0764" strokeWidth="2" strokeDasharray="4 4" />
            <ellipse cx="130" cy="185" rx="35" ry="4" fill="#581c87" opacity="0.6" />

            <g className="squat-lifter-group">
              {/* Head with Focus Face */}
              <circle cx="130" cy="45" r="13" fill="#2e1065" stroke="#c084fc" strokeWidth="2" />
              {/* Eyes Glowing Violet */}
              <circle cx="127" cy="44" r="2" fill="#e9d5ff" />
              <circle cx="133" cy="44" r="2" fill="#e9d5ff" />

              {/* Olympic Barbell on Trapezius */}
              <line x1="45" y1="62" x2="215" y2="62" stroke="#f3e8ff" strokeWidth="4" filter="drop-shadow(0 0 6px #c084fc)" />
              <rect x="52" y="44" width="9" height="36" rx="2" fill="#7e22ce" stroke="#f3e8ff" strokeWidth="1.5" />
              <rect x="199" y="44" width="9" height="36" rx="2" fill="#7e22ce" stroke="#f3e8ff" strokeWidth="1.5" />

              {/* Torso & Core */}
              <line x1="130" y1="58" x2="130" y2="108" stroke="#4c1d95" strokeWidth="12" strokeLinecap="round" />

              {/* Glowing Quads & Glutes (Active target fibers) */}
              <polyline points="130,108 112,145 110,185" fill="none" stroke="#a855f7" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" />
              <polyline points="130,108 148,145 150,185" fill="none" stroke="#a855f7" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" />

              {/* Glowing Quadriceps Accent line */}
              <line x1="126" y1="115" x2="114" y2="142" stroke="#ec4899" strokeWidth="4" strokeLinecap="round" filter="drop-shadow(0 0 6px #f43f5e)" />
              <line x1="134" y1="115" x2="146" y2="142" stroke="#ec4899" strokeWidth="4" strokeLinecap="round" filter="drop-shadow(0 0 6px #f43f5e)" />

              {/* Arms holding bar */}
              <polyline points="110,75 102,62 108,62" fill="none" stroke="#c084fc" strokeWidth="4" strokeLinecap="round" />
              <polyline points="150,75 158,62 152,62" fill="none" stroke="#c084fc" strokeWidth="4" strokeLinecap="round" />
            </g>
          </svg>
        )}

        {/* 3. PULL-UPS */}
        {type === 'pullup' && (
          <svg viewBox="0 0 260 200" className="w-full h-full max-h-56 drop-shadow-[0_0_20px_rgba(168,85,247,0.4)]">
            <style>{`
              @keyframes pullupKineticRep {
                0% { transform: translateY(0px); }
                45% { transform: translateY(-38px); }
                55% { transform: translateY(-38px); }
                100% { transform: translateY(0px); }
              }
              .pullup-athlete-group {
                animation: pullupKineticRep 2.6s cubic-bezier(0.4, 0, 0.2, 1) infinite;
                transform-origin: center top;
              }
            `}</style>
            {/* Rig & Barbell Frame */}
            <line x1="30" y1="35" x2="230" y2="35" stroke="#f3e8ff" strokeWidth="5" filter="drop-shadow(0 0 8px #c084fc)" />
            <line x1="45" y1="20" x2="45" y2="50" stroke="#7e22ce" strokeWidth="4" />
            <line x1="215" y1="20" x2="215" y2="50" stroke="#7e22ce" strokeWidth="4" />

            <g className="pullup-athlete-group">
              {/* Hands locked on bar */}
              <circle cx="100" cy="35" r="5" fill="#f5d0fe" />
              <circle cx="160" cy="35" r="5" fill="#f5d0fe" />
              {/* Arms pulling up */}
              <polyline points="100,35 92,72 115,82" fill="none" stroke="#a855f7" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
              <polyline points="160,35 168,72 145,82" fill="none" stroke="#a855f7" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />

              {/* Head */}
              <circle cx="130" cy="62" r="12" fill="#2e1065" stroke="#c084fc" strokeWidth="2" />

              {/* V-Taper Back with Glowing Latissimus Dorsi */}
              <polygon points="112,82 148,82 138,135 122,135" fill="#3b0764" stroke="#a855f7" strokeWidth="2" />
              {/* Glowing Lats muscle wings */}
              <path d="M113,85 C102,100 110,125 124,130" fill="none" stroke="#ec4899" strokeWidth="5" strokeLinecap="round" filter="drop-shadow(0 0 8px #f43f5e)" />
              <path d="M147,85 C158,100 150,125 136,130" fill="none" stroke="#ec4899" strokeWidth="5" strokeLinecap="round" filter="drop-shadow(0 0 8px #f43f5e)" />

              {/* Hanging Legs with slight knee flex */}
              <polyline points="126,135 123,172 120,185" fill="none" stroke="#6b21a8" strokeWidth="5" strokeLinecap="round" />
              <polyline points="134,135 137,172 140,185" fill="none" stroke="#6b21a8" strokeWidth="5" strokeLinecap="round" />
            </g>
          </svg>
        )}

        {/* 4. SHOULDER PRESS / DUMBBELLS */}
        {type === 'shoulder_press' && (
          <svg viewBox="0 0 260 200" className="w-full h-full max-h-56 drop-shadow-[0_0_20px_rgba(168,85,247,0.4)]">
            <style>{`
              @keyframes shoulderPressKinetic {
                0% { transform: translateY(0px); }
                45% { transform: translateY(-40px); }
                55% { transform: translateY(-40px); }
                100% { transform: translateY(0px); }
              }
              .press-weight-group {
                animation: shoulderPressKinetic 2.6s cubic-bezier(0.4, 0, 0.2, 1) infinite;
                transform-origin: center;
              }
            `}</style>
            {/* Lifter Base */}
            <circle cx="130" cy="80" r="13" fill="#2e1065" stroke="#c084fc" strokeWidth="2" />
            <line x1="130" y1="93" x2="130" y2="140" stroke="#3b0764" strokeWidth="14" strokeLinecap="round" />
            <line x1="124" y1="140" x2="118" y2="185" stroke="#6b21a8" strokeWidth="7" strokeLinecap="round" />
            <line x1="136" y1="140" x2="142" y2="185" stroke="#6b21a8" strokeWidth="7" strokeLinecap="round" />

            {/* Glowing Deltoids on shoulders */}
            <circle cx="112" cy="98" r="8" fill="#ec4899" filter="drop-shadow(0 0 8px #f43f5e)" />
            <circle cx="148" cy="98" r="8" fill="#ec4899" filter="drop-shadow(0 0 8px #f43f5e)" />

            {/* Kinetic Barbell Pushing Overhead */}
            <g className="press-weight-group">
              <line x1="55" y1="88" x2="205" y2="88" stroke="#f3e8ff" strokeWidth="4" filter="drop-shadow(0 0 6px #c084fc)" />
              <rect x="62" y="72" width="8" height="32" rx="2" fill="#7e22ce" stroke="#f3e8ff" strokeWidth="1.5" />
              <rect x="190" y="72" width="8" height="32" rx="2" fill="#7e22ce" stroke="#f3e8ff" strokeWidth="1.5" />
              {/* Hands */}
              <circle cx="105" cy="88" r="5" fill="#f5d0fe" />
              <circle cx="155" cy="88" r="5" fill="#f5d0fe" />
            </g>
          </svg>
        )}

        {/* 5. BICEP CURL & OTHER MOVEMENTS */}
        {!['bench_press', 'squat', 'pullup', 'shoulder_press'].includes(type) && (
          <svg viewBox="0 0 260 200" className="w-full h-full max-h-56 drop-shadow-[0_0_20px_rgba(168,85,247,0.4)]">
            <style>{`
              @keyframes curlDynamicMotion {
                0% { transform: rotate(0deg); }
                45% { transform: rotate(-88deg); }
                55% { transform: rotate(-88deg); }
                100% { transform: rotate(0deg); }
              }
              .curl-forearm-dynamic {
                animation: curlDynamicMotion 2.4s cubic-bezier(0.4, 0, 0.2, 1) infinite;
                transform-origin: 112px 115px;
              }
            `}</style>
            {/* Lifter Body */}
            <circle cx="130" cy="55" r="13" fill="#2e1065" stroke="#c084fc" strokeWidth="2" />
            <line x1="130" y1="68" x2="130" y2="125" stroke="#3b0764" strokeWidth="13" strokeLinecap="round" />
            <line x1="124" y1="125" x2="118" y2="180" stroke="#6b21a8" strokeWidth="7" strokeLinecap="round" />
            <line x1="136" y1="125" x2="142" y2="180" stroke="#6b21a8" strokeWidth="7" strokeLinecap="round" />

            {/* Glowing Bicep Peak Muscle Fiber */}
            <ellipse cx="114" cy="98" rx="7" ry="11" fill="#ec4899" filter="drop-shadow(0 0 8px #f43f5e)" />

            {/* Upper arm static */}
            <line x1="122" y1="80" x2="112" y2="115" stroke="#7e22ce" strokeWidth="6" strokeLinecap="round" />

            {/* Forearm & Dumbbell rotating */}
            <g className="curl-forearm-dynamic">
              <line x1="112" y1="115" x2="112" y2="155" stroke="#c084fc" strokeWidth="5" strokeLinecap="round" />
              {/* Dumbbell Plate Top & Bottom */}
              <rect x="100" y="150" width="24" height="12" rx="3" fill="#9333ea" stroke="#f3e8ff" strokeWidth="1.5" filter="drop-shadow(0 0 6px #c084fc)" />
            </g>
          </svg>
        )}
      </div>

      {/* Bottom Sport App Biomechanics Bar */}
      <div className="w-full flex items-center justify-between text-xs text-purple-200/90 border-t border-purple-800/40 pt-2 px-2 bg-purple-950/40 rounded-xl">
        <div className="flex items-center gap-1.5 font-mono text-[11px]">
          <Flame className="w-3.5 h-3.5 text-pink-400" />
          <span className="text-pink-300 font-bold">Ciblage :</span>
          <span>{exercise.primaryMuscle.toUpperCase()}</span>
        </div>

        <div className="flex items-center gap-1 font-mono text-[11px] text-cyan-300">
          <Activity className="w-3.5 h-3.5" />
          <span>Tempo : 3s négatif · 1s contraction</span>
        </div>
      </div>
    </div>
  );
};
