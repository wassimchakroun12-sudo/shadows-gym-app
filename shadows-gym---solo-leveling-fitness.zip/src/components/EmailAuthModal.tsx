import React, { useState } from 'react';
import { HunterProfile } from '../types';
import {
  getSavedAccounts,
  switchEmailAccount,
  logoutAccount,
  sounds,
  RANKS_CONFIG,
  normalizeEmail,
} from '../utils/hunterSystem';
import { Translations } from '../i18n/translations';
import { Mail, CheckCircle2, X, User, Shield, ArrowRight, LogOut, Sparkles, KeyRound } from 'lucide-react';

interface EmailAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: HunterProfile;
  onProfileChange: (newProfile: HunterProfile) => void;
  t: Translations;
}

export const EmailAuthModal: React.FC<EmailAuthModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  onProfileChange,
  t,
}) => {
  const [emailInput, setEmailInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const savedAccounts = getSavedAccounts();

  const handleConnect = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = normalizeEmail(emailInput);
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setErrorMsg(t.auth.enterEmailAlert);
      return;
    }
    setErrorMsg('');
    sounds.playLevelUp();
    const loaded = switchEmailAccount(cleanEmail);
    onProfileChange(loaded);
    setEmailInput('');
    onClose();
  };

  const handleSwitchToExisting = (email: string) => {
    sounds.playClick();
    const loaded = switchEmailAccount(email);
    onProfileChange(loaded);
    onClose();
  };

  const handleLogout = () => {
    sounds.playClick();
    const guest = logoutAccount();
    onProfileChange(guest);
    onClose();
  };

  const currentRankInfo = currentProfile.rank ? RANKS_CONFIG[currentProfile.rank] : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-[#0b081c] border border-purple-600/50 rounded-2xl p-6 sm:p-7 shadow-[0_0_50px_rgba(168,85,247,0.35)] relative text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          type="button"
          onClick={() => {
            sounds.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 p-2 text-purple-300/60 hover:text-white rounded-lg hover:bg-purple-900/40 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-700/60 text-purple-300 font-mono text-xs mb-2">
            <Mail className="w-3.5 h-3.5 text-purple-400" />
            {t.auth.portalTitle}
          </div>
          <h2 className="text-xl sm:text-2xl font-black font-mono tracking-tight text-white">
            {t.auth.portalSubtitle}
          </h2>
          <p className="text-xs text-purple-300/70 mt-1">
            Liez vos données, votre rang et vos niveaux à votre adresse e-mail.
          </p>
        </div>

        {/* Current Active Account Card */}
        <div className="mb-6 p-4 rounded-xl bg-[#120d2c] border border-purple-800/60 shadow-inner">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              {t.auth.activeSession}
            </span>
            {currentProfile.email && (
              <span className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-700/50 px-2 py-0.5 rounded-full">
                <CheckCircle2 className="w-2.5 h-2.5" />
                {t.auth.accountLinked}
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-purple-950/90 border border-purple-600/60 flex items-center justify-center text-purple-300 shrink-0 font-bold font-mono text-sm">
              {currentProfile.rank || 'E'}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-white truncate flex items-center gap-2">
                {currentProfile.name}
                <span className="text-xs text-purple-400 font-mono font-normal">
                  (Niv. {currentProfile.level})
                </span>
              </div>
              <div className="text-xs font-mono text-purple-300/80 truncate">
                {currentProfile.email || 'Mode invité non lié'}
              </div>
            </div>
            {currentProfile.email && (
              <button
                type="button"
                onClick={handleLogout}
                className="text-xs font-mono text-red-400/80 hover:text-red-300 px-2.5 py-1.5 rounded-lg hover:bg-red-950/40 border border-red-900/40 transition-colors flex items-center gap-1"
                title={t.auth.btnDisconnect}
              >
                <LogOut className="w-3 h-3" />
                <span className="hidden sm:inline">{t.auth.btnDisconnect}</span>
              </button>
            )}
          </div>
        </div>

        {/* Form: Connect with Email */}
        <form onSubmit={handleConnect} className="space-y-4 mb-6">
          <div>
            <label className="block text-xs font-mono text-purple-300 uppercase tracking-wider mb-1.5">
              {t.auth.emailLabel}
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={emailInput}
                onChange={(e) => {
                  setEmailInput(e.target.value);
                  setErrorMsg('');
                }}
                placeholder="wassimchakroun12@gmail.com"
                className="w-full bg-[#150f33] border border-purple-700/60 focus:border-purple-400 focus:shadow-[0_0_12px_rgba(168,85,247,0.4)] rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-purple-400/40 text-sm font-mono outline-none transition-all"
              />
              <Mail className="w-4 h-4 text-purple-400 absolute left-3.5 top-3" />
            </div>
            {errorMsg && (
              <p className="text-xs text-red-400 mt-1 font-mono">{errorMsg}</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(147,51,234,0.4)] hover:shadow-[0_0_30px_rgba(168,85,247,0.6)] transition-all active:scale-[0.99]"
          >
            <KeyRound className="w-4 h-4" />
            {t.auth.btnConnect}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Saved Accounts on this device */}
        {savedAccounts.length > 0 && (
          <div>
            <div className="text-[11px] font-mono uppercase tracking-wider text-purple-400/80 mb-2">
              {t.auth.savedAccounts}
            </div>
            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
              {savedAccounts.map((acc) => {
                const isCurrent = Boolean(currentProfile.email && normalizeEmail(currentProfile.email) === normalizeEmail(acc.email));
                return (
                  <button
                    key={acc.email}
                    type="button"
                    onClick={() => handleSwitchToExisting(acc.email)}
                    disabled={isCurrent}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl border text-left transition-all ${
                      isCurrent
                        ? 'bg-purple-950/60 border-purple-500/80 text-white'
                        : 'bg-[#100c26]/60 border-purple-900/40 text-purple-200 hover:bg-[#18113b] hover:border-purple-600/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="w-6 h-6 rounded bg-purple-900/80 border border-purple-600 text-[10px] font-mono font-bold flex items-center justify-center text-purple-300 shrink-0">
                        {acc.rank}
                      </span>
                      <div className="min-w-0">
                        <div className="text-xs font-bold truncate text-white">
                          {acc.name}
                        </div>
                        <div className="text-[10px] font-mono text-purple-400/70 truncate">
                          {acc.email}
                        </div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-[10px] font-mono text-purple-300">
                        Niv. {acc.level}
                      </div>
                      <div className="text-[9px] font-mono text-purple-400/60">
                        {acc.xp} XP
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
