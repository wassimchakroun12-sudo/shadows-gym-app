import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Plus, Bell, Volume2 } from 'lucide-react';
import { sounds } from '../utils/hunterSystem';

interface WorkoutTimerProps {
  initialSeconds?: number;
  onComplete?: () => void;
  autoStart?: boolean;
}

export const WorkoutTimer: React.FC<WorkoutTimerProps> = ({
  initialSeconds = 90,
  onComplete,
  autoStart = false,
}) => {
  const [totalSeconds, setTotalSeconds] = useState<number>(initialSeconds);
  const [timeLeft, setTimeLeft] = useState<number>(initialSeconds);
  const [isRunning, setIsRunning] = useState<boolean>(autoStart);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    setTimeLeft(initialSeconds);
    setTotalSeconds(initialSeconds);
    if (autoStart) {
      setIsRunning(true);
    }
  }, [initialSeconds, autoStart]);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setIsRunning(false);
            sounds.playTimerComplete();
            if (onComplete) onComplete();
            return 0;
          }
          if (prev <= 4) {
            sounds.playTimerTick();
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, timeLeft, onComplete]);

  const toggleTimer = () => {
    sounds.playClick();
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    sounds.playClick();
    setIsRunning(false);
    setTimeLeft(totalSeconds);
  };

  const addSeconds = (secs: number) => {
    sounds.playClick();
    setTimeLeft((prev) => prev + secs);
    setTotalSeconds((prev) => Math.max(prev, timeLeft + secs));
  };

  const setPreset = (secs: number) => {
    sounds.playClick();
    setIsRunning(false);
    setTotalSeconds(secs);
    setTimeLeft(secs);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  const progressPercent = totalSeconds > 0 ? (timeLeft / totalSeconds) * 100 : 0;
  const strokeDashoffset = 283 - (283 * progressPercent) / 100;

  return (
    <div className="bg-[#0e0a22]/90 border border-purple-800/40 rounded-2xl p-4 flex flex-col items-center relative overflow-hidden backdrop-blur-md shadow-[0_0_20px_rgba(147,51,234,0.15)]">
      {/* Top Header */}
      <div className="w-full flex items-center justify-between mb-2">
        <span className="text-xs font-semibold text-purple-300 uppercase tracking-wider flex items-center gap-1.5 font-mono">
          <Bell className="w-3.5 h-3.5 text-purple-400" />
          CHRONO DE RÉCUPÉRATION
        </span>
        <div className="flex items-center gap-1">
          {[45, 60, 90, 120].map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={() => setPreset(preset)}
              className={`text-[11px] px-2 py-0.5 rounded font-mono transition-all ${
                totalSeconds === preset
                  ? 'bg-purple-600 text-white shadow-[0_0_8px_rgba(168,85,247,0.5)]'
                  : 'bg-purple-950/60 text-purple-300/70 hover:text-white'
              }`}
            >
              {preset}s
            </button>
          ))}
        </div>
      </div>

      {/* Circular Progress & Digits */}
      <div className="relative w-36 h-36 flex items-center justify-center my-2">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="45"
            className="stroke-purple-950/80"
            strokeWidth="6"
            fill="transparent"
          />
          <circle
            cx="50"
            cy="50"
            r="45"
            className="stroke-purple-500 transition-all duration-500"
            strokeWidth="6"
            fill="transparent"
            strokeDasharray="283"
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            style={{
              filter: isRunning ? 'drop-shadow(0 0 6px #c084fc)' : undefined,
            }}
          />
        </svg>

        <div className="absolute flex flex-col items-center justify-center">
          <span className="text-3xl font-extrabold font-mono tracking-tight text-white drop-shadow-[0_0_8px_rgba(192,132,252,0.8)]">
            {formattedTime}
          </span>
          <span className="text-[10px] text-purple-300 uppercase tracking-widest font-mono">
            {isRunning ? 'REPOS EN COURS' : timeLeft === 0 ? 'PRÊT POUR LA SÉRIE !' : 'EN PAUSE'}
          </span>
        </div>
      </div>

      {/* Control Action Buttons */}
      <div className="flex items-center gap-2 mt-2 w-full justify-center">
        <button
          type="button"
          onClick={resetTimer}
          className="p-2.5 rounded-xl bg-purple-950/60 border border-purple-800/40 text-purple-300 hover:text-white hover:bg-purple-900/60 transition-all active:scale-95"
          title="Réinitialiser"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={toggleTimer}
          className={`flex-1 max-w-[140px] py-2.5 px-4 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md ${
            isRunning
              ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-900/30'
              : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.5)]'
          }`}
        >
          {isRunning ? (
            <>
              <Pause className="w-4 h-4" /> PAUSE
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" /> DÉMARRER
            </>
          )}
        </button>

        <button
          type="button"
          onClick={() => addSeconds(30)}
          className="py-2.5 px-3 rounded-xl bg-purple-950/60 border border-purple-800/40 text-purple-300 hover:text-white hover:bg-purple-900/60 transition-all active:scale-95 text-xs font-mono font-bold flex items-center gap-1"
          title="Ajouter 30 secondes"
        >
          <Plus className="w-3.5 h-3.5" /> 30s
        </button>
      </div>
    </div>
  );
};
