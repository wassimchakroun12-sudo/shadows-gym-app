import React from 'react';
import { MuscleId } from '../types';
import { Info, RotateCw, ChevronLeft, ChevronRight } from 'lucide-react';

interface AnatomyFigureProps {
  view: 'front' | 'back';
  onViewChange: (view: 'front' | 'back') => void;
  selectedMuscles: MuscleId[];
  onToggleMuscle: (id: MuscleId) => void;
  hoveredMuscle: MuscleId | null;
  setHoveredMuscle: (id: MuscleId | null) => void;
}

export const AnatomyFigure: React.FC<AnatomyFigureProps> = ({
  view,
  onViewChange,
  selectedMuscles,
  onToggleMuscle,
  hoveredMuscle,
  setHoveredMuscle,
}) => {
  const isSelected = (id: MuscleId) => selectedMuscles.includes(id);
  const isHovered = (id: MuscleId) => hoveredMuscle === id;

  const getMuscleFill = (id: MuscleId) => {
    if (isSelected(id)) {
      return 'url(#selectedGlowGradient)';
    }
    if (isHovered(id)) {
      return 'rgba(168, 85, 247, 0.4)';
    }
    return 'rgba(59, 30, 95, 0.25)';
  };

  const getMuscleStroke = (id: MuscleId) => {
    if (isSelected(id)) {
      return '#c084fc';
    }
    if (isHovered(id)) {
      return '#a855f7';
    }
    return 'rgba(139, 92, 246, 0.35)';
  };

  const getFilter = (id: MuscleId) => {
    if (isSelected(id)) {
      return 'url(#neonPurpleGlow)';
    }
    if (isHovered(id)) {
      return 'url(#subtleGlow)';
    }
    return undefined;
  };

  return (
    <div className="flex flex-col items-center justify-between h-full w-full bg-[#0a0715]/90 border border-purple-900/40 rounded-2xl p-4 sm:p-6 backdrop-blur-md relative overflow-hidden shadow-[0_0_30px_rgba(112,26,179,0.15)]">
      {/* Background Cyber Grid */}
      <div 
        className="absolute inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(147, 51, 234, 0.25) 0%, transparent 70%), linear-gradient(to right, rgba(147, 51, 234, 0.1) 1px, transparent 1px), linear-gradient(to bottom, rgba(147, 51, 234, 0.1) 1px, transparent 1px)',
          backgroundSize: '100% 100%, 24px 24px, 24px 24px'
        }}
      />

      {/* Top View Selector Tabs */}
      <div className="w-full flex items-center justify-center gap-2 mb-3 z-10">
        <div className="flex p-1 bg-[#120d26] border border-purple-800/40 rounded-xl w-full max-w-xs shadow-inner">
          <button
            type="button"
            onClick={() => onViewChange('front')}
            className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all duration-200 flex items-center justify-center gap-2 ${
              view === 'front'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-[0_0_15px_rgba(168,85,247,0.6)]'
                : 'text-purple-300/70 hover:text-white hover:bg-purple-900/20'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-purple-300 shadow-[0_0_6px_#c084fc]" />
            DEVANT
          </button>
          <button
            type="button"
            onClick={() => onViewChange('back')}
            className={`flex-1 py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-all duration-200 flex items-center justify-center gap-2 ${
              view === 'back'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-[0_0_15px_rgba(168,85,247,0.6)]'
                : 'text-purple-300/70 hover:text-white hover:bg-purple-900/20'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-indigo-300 shadow-[0_0_6px_#818cf8]" />
            DOS
          </button>
        </div>
      </div>

      {/* Anatomical Hologram Interactive Canvas Container */}
      <div className="relative flex-1 w-full max-w-sm flex items-center justify-center my-1 select-none">
        {/* Angle change side arrows */}
        <button
          type="button"
          onClick={() => onViewChange(view === 'front' ? 'back' : 'front')}
          className="absolute left-1 sm:left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-purple-950/60 border border-purple-700/50 text-purple-300 hover:text-white hover:bg-purple-900/80 transition-all z-20 shadow-[0_0_10px_rgba(147,51,234,0.3)] active:scale-95"
          aria-label="Changer de vue"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          type="button"
          onClick={() => onViewChange(view === 'front' ? 'back' : 'front')}
          className="absolute right-1 sm:right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-purple-950/60 border border-purple-700/50 text-purple-300 hover:text-white hover:bg-purple-900/80 transition-all z-20 shadow-[0_0_10px_rgba(147,51,234,0.3)] active:scale-95"
          aria-label="Changer de vue"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* High Precision Interactive SVG Hologram */}
        <svg
          viewBox="0 0 340 580"
          className="w-full max-h-[420px] drop-shadow-[0_0_25px_rgba(147,51,234,0.3)] transition-all duration-300"
          style={{ overflow: 'visible' }}
        >
          <defs>
            {/* Hologram Gradient Glow */}
            <radialGradient id="selectedGlowGradient" cx="50%" cy="50%" r="65%">
              <stop offset="0%" stopColor="#d8b4fe" stopOpacity="0.95" />
              <stop offset="50%" stopColor="#a855f7" stopOpacity="0.85" />
              <stop offset="100%" stopColor="#6b21a8" stopOpacity="0.95" />
            </radialGradient>

            <linearGradient id="bodyOutlineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#7e22ce" stopOpacity="0.8" />
              <stop offset="50%" stopColor="#a855f7" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#4c1d95" stopOpacity="0.8" />
            </linearGradient>

            {/* Neon Glow Filters */}
            <filter id="neonPurpleGlow" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="3.5" result="blur1" />
              <feGaussianBlur stdDeviation="8" result="blur2" />
              <feMerge>
                <feMergeNode in="blur2" />
                <feMergeNode in="blur1" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>

            <filter id="subtleGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="2.5" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Underlay Ambient Aura */}
          <ellipse cx="170" cy="290" rx="95" ry="240" fill="rgba(147, 51, 234, 0.08)" />

          {/* Body Base Silhouette (Head, Neck, Torso wireframe) */}
          <g opacity="0.6">
            {/* Head */}
            <path
              d="M170,30 C154,30 148,46 148,64 C148,82 155,100 170,105 C185,100 192,82 192,64 C192,46 186,30 170,30 Z"
              fill="rgba(30, 20, 50, 0.7)"
              stroke="#6b21a8"
              strokeWidth="1.5"
            />
            {/* Neck */}
            <path
              d="M158,100 L154,120 L186,120 L182,100 Z"
              fill="rgba(40, 25, 65, 0.5)"
              stroke="#7c3aed"
              strokeWidth="1"
            />
            {/* Hands & Feet anchor dots */}
            <ellipse cx="62" cy="328" rx="7" ry="12" fill="#3b0764" stroke="#a855f7" strokeWidth="1" />
            <ellipse cx="278" cy="328" rx="7" ry="12" fill="#3b0764" stroke="#a855f7" strokeWidth="1" />
            <ellipse cx="140" cy="546" rx="9" ry="14" fill="#3b0764" stroke="#a855f7" strokeWidth="1" />
            <ellipse cx="200" cy="546" rx="9" ry="14" fill="#3b0764" stroke="#a855f7" strokeWidth="1" />
          </g>

          {view === 'front' ? (
            /* =================== FRONT VIEW =================== */
            <g id="front-muscles">
              {/* SHOULDERS (Deltoids Left & Right) */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('shoulders')}
                onMouseEnter={() => setHoveredMuscle('shoulders')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Left Deltoid */}
                <path
                  d="M136,122 C120,124 105,134 102,152 C98,168 106,182 114,188 C120,172 128,154 138,138 Z"
                  fill={getMuscleFill('shoulders')}
                  stroke={getMuscleStroke('shoulders')}
                  strokeWidth="2"
                  filter={getFilter('shoulders')}
                />
                {/* Right Deltoid */}
                <path
                  d="M204,122 C220,124 235,134 238,152 C242,168 234,182 226,188 C220,172 212,154 202,138 Z"
                  fill={getMuscleFill('shoulders')}
                  stroke={getMuscleStroke('shoulders')}
                  strokeWidth="2"
                  filter={getFilter('shoulders')}
                />
              </g>

              {/* CHEST / POITRINE (Pectoraux) */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('chest')}
                onMouseEnter={() => setHoveredMuscle('chest')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Left Pec */}
                <path
                  d="M168,126 C150,125 138,136 136,150 C134,166 142,185 168,190 C169,168 169,146 168,126 Z"
                  fill={getMuscleFill('chest')}
                  stroke={getMuscleStroke('chest')}
                  strokeWidth="2"
                  filter={getFilter('chest')}
                />
                {/* Right Pec */}
                <path
                  d="M172,126 C190,125 202,136 204,150 C206,166 198,185 172,190 C171,168 171,146 172,126 Z"
                  fill={getMuscleFill('chest')}
                  stroke={getMuscleStroke('chest')}
                  strokeWidth="2"
                  filter={getFilter('chest')}
                />
              </g>

              {/* ARMS / BRAS (Biceps Front) */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('arms')}
                onMouseEnter={() => setHoveredMuscle('arms')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Left Bicep */}
                <path
                  d="M112,188 C102,194 92,208 92,228 C92,242 98,252 108,254 C116,244 122,220 120,195 Z"
                  fill={getMuscleFill('arms')}
                  stroke={getMuscleStroke('arms')}
                  strokeWidth="2"
                  filter={getFilter('arms')}
                />
                {/* Right Bicep */}
                <path
                  d="M228,188 C238,194 248,208 248,228 C248,242 242,252 232,254 C224,244 218,220 220,195 Z"
                  fill={getMuscleFill('arms')}
                  stroke={getMuscleStroke('arms')}
                  strokeWidth="2"
                  filter={getFilter('arms')}
                />
              </g>

              {/* FOREARMS / AVANT-BRAS */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('forearms')}
                onMouseEnter={() => setHoveredMuscle('forearms')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Left Forearm */}
                <path
                  d="M106,256 C94,264 78,284 72,308 C68,318 64,324 72,326 C82,322 96,298 108,274 Z"
                  fill={getMuscleFill('forearms')}
                  stroke={getMuscleStroke('forearms')}
                  strokeWidth="2"
                  filter={getFilter('forearms')}
                />
                {/* Right Forearm */}
                <path
                  d="M234,256 C246,264 262,284 268,308 C272,318 276,324 268,326 C258,322 244,298 232,274 Z"
                  fill={getMuscleFill('forearms')}
                  stroke={getMuscleStroke('forearms')}
                  strokeWidth="2"
                  filter={getFilter('forearms')}
                />
              </g>

              {/* ABS / ABDOMINAUX (6-pack & obliques) */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('abs')}
                onMouseEnter={() => setHoveredMuscle('abs')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Upper Left & Right */}
                <rect x="153" y="194" width="15" height="18" rx="3" fill={getMuscleFill('abs')} stroke={getMuscleStroke('abs')} strokeWidth="1.5" filter={getFilter('abs')} />
                <rect x="172" y="194" width="15" height="18" rx="3" fill={getMuscleFill('abs')} stroke={getMuscleStroke('abs')} strokeWidth="1.5" filter={getFilter('abs')} />
                {/* Mid Left & Right */}
                <rect x="153" y="215" width="15" height="18" rx="3" fill={getMuscleFill('abs')} stroke={getMuscleStroke('abs')} strokeWidth="1.5" filter={getFilter('abs')} />
                <rect x="172" y="215" width="15" height="18" rx="3" fill={getMuscleFill('abs')} stroke={getMuscleStroke('abs')} strokeWidth="1.5" filter={getFilter('abs')} />
                {/* Lower Left & Right */}
                <rect x="154" y="236" width="14" height="20" rx="3" fill={getMuscleFill('abs')} stroke={getMuscleStroke('abs')} strokeWidth="1.5" filter={getFilter('abs')} />
                <rect x="172" y="236" width="14" height="20" rx="3" fill={getMuscleFill('abs')} stroke={getMuscleStroke('abs')} strokeWidth="1.5" filter={getFilter('abs')} />
                {/* Obliques Left & Right */}
                <path d="M142,206 C138,222 138,242 144,258 C148,252 150,230 150,210 Z" fill={getMuscleFill('abs')} stroke={getMuscleStroke('abs')} strokeWidth="1.5" filter={getFilter('abs')} />
                <path d="M198,206 C202,222 202,242 196,258 C192,252 190,230 190,210 Z" fill={getMuscleFill('abs')} stroke={getMuscleStroke('abs')} strokeWidth="1.5" filter={getFilter('abs')} />
              </g>

              {/* QUADRICEPS / CUISSES (Front Quads) */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('quads')}
                onMouseEnter={() => setHoveredMuscle('quads')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Left Quad */}
                <path
                  d="M136,280 C124,310 120,360 128,400 C136,410 144,408 148,396 C156,365 158,320 152,282 Z"
                  fill={getMuscleFill('quads')}
                  stroke={getMuscleStroke('quads')}
                  strokeWidth="2"
                  filter={getFilter('quads')}
                />
                {/* Right Quad */}
                <path
                  d="M204,280 C216,310 220,360 212,400 C204,410 196,408 192,396 C184,365 182,320 188,282 Z"
                  fill={getMuscleFill('quads')}
                  stroke={getMuscleStroke('quads')}
                  strokeWidth="2"
                  filter={getFilter('quads')}
                />
              </g>

              {/* CALVES / MOLLETS (Front) */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('calves')}
                onMouseEnter={() => setHoveredMuscle('calves')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Left Shin/Calf */}
                <path
                  d="M128,425 C122,445 120,480 130,520 C134,524 142,520 144,510 C146,478 148,446 142,425 Z"
                  fill={getMuscleFill('calves')}
                  stroke={getMuscleStroke('calves')}
                  strokeWidth="2"
                  filter={getFilter('calves')}
                />
                {/* Right Shin/Calf */}
                <path
                  d="M212,425 C218,445 220,480 210,520 C206,524 198,520 196,510 C194,478 192,446 198,425 Z"
                  fill={getMuscleFill('calves')}
                  stroke={getMuscleStroke('calves')}
                  strokeWidth="2"
                  filter={getFilter('calves')}
                />
              </g>
            </g>
          ) : (
            /* =================== BACK VIEW =================== */
            <g id="back-muscles">
              {/* BACK / DOS (Trapezius & Lats) */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('back')}
                onMouseEnter={() => setHoveredMuscle('back')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Upper Trapezius */}
                <path
                  d="M170,110 L152,122 L144,142 L170,172 L196,142 L188,122 Z"
                  fill={getMuscleFill('back')}
                  stroke={getMuscleStroke('back')}
                  strokeWidth="2"
                  filter={getFilter('back')}
                />
                {/* Left Latissimus Dorsi */}
                <path
                  d="M142,148 C130,165 124,195 138,245 C150,240 160,225 166,180 Z"
                  fill={getMuscleFill('back')}
                  stroke={getMuscleStroke('back')}
                  strokeWidth="2"
                  filter={getFilter('back')}
                />
                {/* Right Latissimus Dorsi */}
                <path
                  d="M198,148 C210,165 216,195 202,245 C190,240 180,225 174,180 Z"
                  fill={getMuscleFill('back')}
                  stroke={getMuscleStroke('back')}
                  strokeWidth="2"
                  filter={getFilter('back')}
                />
              </g>

              {/* REAR SHOULDERS (Posterior Deltoids) */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('shoulders')}
                onMouseEnter={() => setHoveredMuscle('shoulders')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                <path
                  d="M136,122 C118,128 106,142 104,162 C114,166 126,154 138,142 Z"
                  fill={getMuscleFill('shoulders')}
                  stroke={getMuscleStroke('shoulders')}
                  strokeWidth="2"
                  filter={getFilter('shoulders')}
                />
                <path
                  d="M204,122 C222,128 234,142 236,162 C226,166 214,154 202,142 Z"
                  fill={getMuscleFill('shoulders')}
                  stroke={getMuscleStroke('shoulders')}
                  strokeWidth="2"
                  filter={getFilter('shoulders')}
                />
              </g>

              {/* TRICEPS / ARMS BACK */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('arms')}
                onMouseEnter={() => setHoveredMuscle('arms')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                <path
                  d="M104,166 C96,182 92,215 102,248 C110,246 114,228 116,192 Z"
                  fill={getMuscleFill('arms')}
                  stroke={getMuscleStroke('arms')}
                  strokeWidth="2"
                  filter={getFilter('arms')}
                />
                <path
                  d="M236,166 C244,182 248,215 238,248 C230,246 226,228 224,192 Z"
                  fill={getMuscleFill('arms')}
                  stroke={getMuscleStroke('arms')}
                  strokeWidth="2"
                  filter={getFilter('arms')}
                />
              </g>

              {/* FOREARMS BACK */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('forearms')}
                onMouseEnter={() => setHoveredMuscle('forearms')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                <path
                  d="M102,252 C90,266 76,290 70,314 C66,322 74,326 78,322 C88,304 98,284 108,266 Z"
                  fill={getMuscleFill('forearms')}
                  stroke={getMuscleStroke('forearms')}
                  strokeWidth="2"
                  filter={getFilter('forearms')}
                />
                <path
                  d="M238,252 C250,266 264,290 270,314 C274,322 266,326 262,322 C252,304 242,284 232,266 Z"
                  fill={getMuscleFill('forearms')}
                  stroke={getMuscleStroke('forearms')}
                  strokeWidth="2"
                  filter={getFilter('forearms')}
                />
              </g>

              {/* GLUTES / FESSIERS */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('glutes')}
                onMouseEnter={() => setHoveredMuscle('glutes')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Left Glute */}
                <path
                  d="M168,260 C150,260 134,275 134,302 C134,330 152,342 168,340 Z"
                  fill={getMuscleFill('glutes')}
                  stroke={getMuscleStroke('glutes')}
                  strokeWidth="2"
                  filter={getFilter('glutes')}
                />
                {/* Right Glute */}
                <path
                  d="M172,260 C190,260 206,275 206,302 C206,330 188,342 172,340 Z"
                  fill={getMuscleFill('glutes')}
                  stroke={getMuscleStroke('glutes')}
                  strokeWidth="2"
                  filter={getFilter('glutes')}
                />
              </g>

              {/* HAMSTRINGS / ISCHIO-JAMBIERS */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('hamstrings')}
                onMouseEnter={() => setHoveredMuscle('hamstrings')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Left Hamstring */}
                <path
                  d="M136,346 C130,365 132,398 138,416 C146,416 156,410 162,390 C166,366 166,346 162,344 Z"
                  fill={getMuscleFill('hamstrings')}
                  stroke={getMuscleStroke('hamstrings')}
                  strokeWidth="2"
                  filter={getFilter('hamstrings')}
                />
                {/* Right Hamstring */}
                <path
                  d="M204,346 C210,365 208,398 202,416 C194,416 184,410 178,390 C174,366 174,346 178,344 Z"
                  fill={getMuscleFill('hamstrings')}
                  stroke={getMuscleStroke('hamstrings')}
                  strokeWidth="2"
                  filter={getFilter('hamstrings')}
                />
              </g>

              {/* CALVES / MOLLETS BACK (Gastrocnemius) */}
              <g
                className="cursor-pointer transition-all duration-200"
                onClick={() => onToggleMuscle('calves')}
                onMouseEnter={() => setHoveredMuscle('calves')}
                onMouseLeave={() => setHoveredMuscle(null)}
              >
                {/* Left Calf */}
                <path
                  d="M136,425 C124,445 124,482 134,518 C140,518 146,508 148,485 C150,460 148,435 142,425 Z"
                  fill={getMuscleFill('calves')}
                  stroke={getMuscleStroke('calves')}
                  strokeWidth="2"
                  filter={getFilter('calves')}
                />
                {/* Right Calf */}
                <path
                  d="M204,425 C216,445 216,482 206,518 C200,518 194,508 192,485 C190,460 192,435 198,425 Z"
                  fill={getMuscleFill('calves')}
                  stroke={getMuscleStroke('calves')}
                  strokeWidth="2"
                  filter={getFilter('calves')}
                />
              </g>
            </g>
          )}

          {/* Anatomic Hologram Grid Line Accents */}
          <line x1="80" y1="130" x2="260" y2="130" stroke="rgba(168,85,247,0.15)" strokeDasharray="3 3" />
          <line x1="80" y1="260" x2="260" y2="260" stroke="rgba(168,85,247,0.15)" strokeDasharray="3 3" />
          <line x1="80" y1="420" x2="260" y2="420" stroke="rgba(168,85,247,0.15)" strokeDasharray="3 3" />
        </svg>
      </div>

      {/* Info Tip matching Image 2 */}
      <div className="flex items-center gap-2 text-xs text-purple-300/80 bg-purple-950/40 border border-purple-800/30 rounded-xl px-3 py-2 mt-2 w-full justify-center">
        <Info className="w-4 h-4 text-purple-400 shrink-0" />
        <span>Cliquez sur les zones pour sélectionner les muscles</span>
      </div>
    </div>
  );
};
