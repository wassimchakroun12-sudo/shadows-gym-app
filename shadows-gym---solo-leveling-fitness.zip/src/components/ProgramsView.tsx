import React from 'react';
import { MuscleId } from '../types';
import { sounds } from '../utils/hunterSystem';
import { Dumbbell, Shield, ArrowRight, Zap, Target, Flame } from 'lucide-react';

interface ProgramPreset {
  id: string;
  title: string;
  subtitle: string;
  rankRequired: string;
  duration: string;
  muscles: MuscleId[];
  muscleLabels: string[];
  description: string;
  intensity: 'Haute' | 'Monarque Extrême' | 'Standard';
}

const PRESET_PROGRAMS: ProgramPreset[] = [
  {
    id: 'push-day',
    title: 'Jour PUSH : Force & Poussée',
    subtitle: 'Pectoraux · Épaules · Triceps',
    rankRequired: 'Rang E+',
    duration: '50 min',
    muscles: ['chest', 'shoulders', 'arms'],
    muscleLabels: ['Poitrine', 'Épaules', 'Bras'],
    description: 'Développé couché lourd, développé militaire et dips pour forger un haut du corps impénétrable.',
    intensity: 'Haute',
  },
  {
    id: 'pull-day',
    title: 'Jour PULL : Largeur du Monarque',
    subtitle: 'Dos · Biceps · Avant-bras',
    rankRequired: 'Rang D+',
    duration: '55 min',
    muscles: ['back', 'arms', 'forearms'],
    muscleLabels: ['Dos', 'Bras', 'Avant-bras'],
    description: 'Tractions en pronation, rowing barre et curls marteaux pour un dos en V massif.',
    intensity: 'Haute',
  },
  {
    id: 'legs-core',
    title: 'Jour LEGS : Les Racines du Titan',
    subtitle: 'Quadriceps · Fessiers · Ischios · Abdos',
    rankRequired: 'Rang C+',
    duration: '60 min',
    muscles: ['quads', 'glutes', 'hamstrings', 'calves', 'abs'],
    muscleLabels: ['Quadriceps', 'Fessiers', 'Ischios', 'Mollets', 'Abdos'],
    description: 'Squat profond, soulevé de terre roumain et relevés de jambes pour une base inébranlable.',
    intensity: 'Monarque Extrême',
  },
  {
    id: 'full-monarch',
    title: 'Full Body : Éveil des Ombres',
    subtitle: 'Tous les groupes majeurs',
    rankRequired: 'Rang B+',
    duration: '75 min',
    muscles: ['chest', 'back', 'shoulders', 'quads', 'abs'],
    muscleLabels: ['Poitrine', 'Dos', 'Épaules', 'Quadriceps', 'Abdos'],
    description: 'La routine complète des Chasseurs d’élite : volume élevé et intensité maximale.',
    intensity: 'Monarque Extrême',
  },
];

interface ProgramsViewProps {
  onSelectProgramMuscles: (muscles: MuscleId[]) => void;
}

export const ProgramsView: React.FC<ProgramsViewProps> = ({ onSelectProgramMuscles }) => {
  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-8 space-y-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-purple-900/40">
        <div>
          <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            PROGRAMMES D'ENTRAÎNEMENT CERTIFIÉS
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight mt-1">
            ROUTINES DE CHASSEURS DE SHADOWS GYM
          </h1>
          <p className="text-xs sm:text-sm text-purple-300/70 mt-1 max-w-xl">
            Choisissez un programme prédéfini ou créez votre propre split sur-mesure via la sélection musculaire interactive.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {PRESET_PROGRAMS.map((prog) => (
          <div
            key={prog.id}
            className="bg-[#0c081e]/90 border border-purple-800/40 hover:border-purple-500 rounded-2xl p-6 backdrop-blur-md transition-all hover:shadow-[0_0_25px_rgba(168,85,247,0.3)] flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 border border-purple-700/60 text-purple-300 font-bold uppercase">
                  {prog.rankRequired}
                </span>
                <span className="text-xs font-mono text-cyan-400 font-bold">
                  {prog.duration} · {prog.intensity}
                </span>
              </div>

              <h2 className="text-lg font-black text-white font-mono group-hover:text-purple-300 transition-colors">
                {prog.title}
              </h2>
              <div className="text-xs text-purple-300/80 font-mono mt-0.5">
                {prog.subtitle}
              </div>

              <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                {prog.description}
              </p>

              <div className="flex flex-wrap gap-1.5 mt-4">
                {prog.muscleLabels.map((m) => (
                  <span
                    key={m}
                    className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-900/50 border border-purple-700/40 text-purple-200"
                  >
                    {m}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-purple-900/30 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  onSelectProgramMuscles(prog.muscles);
                }}
                className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-mono font-bold text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(168,85,247,0.5)] flex items-center gap-1.5 transition-all active:scale-95"
              >
                <span>Lancer ce programme</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
