import React, { useState } from 'react';
import { HunterProfile, HunterRank } from '../types';
import { RANKS_CONFIG, getXpProgressForCurrentRank, saveHunterProfile, sounds } from '../utils/hunterSystem';
import { Shield, Zap, Flame, Award, Dumbbell, Calendar, User, Edit3, Check, RotateCcw, Mail, Download } from 'lucide-react';

interface HunterProfileViewProps {
  profile: HunterProfile;
  onUpdateProfile: (updated: HunterProfile) => void;
  onStartWorkout: () => void;
  onOpenAuthModal?: () => void;
  onOpenInstallModal?: () => void;
}

export const HunterProfileView: React.FC<HunterProfileViewProps> = ({
  profile,
  onUpdateProfile,
  onStartWorkout,
  onOpenAuthModal,
  onOpenInstallModal,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(profile.name);
  const [editAge, setEditAge] = useState(profile.age);
  const [editWeight, setEditWeight] = useState(profile.weightKg);
  const [editHeight, setEditHeight] = useState(profile.heightCm);

  const currentRankInfo = RANKS_CONFIG[profile.rank];
  const progress = getXpProgressForCurrentRank(profile.xp, profile.rank);

  const bmi = profile.heightCm > 0
    ? (profile.weightKg / Math.pow(profile.heightCm / 100, 2)).toFixed(1)
    : '22.0';

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    sounds.playClick();
    const updated: HunterProfile = {
      ...profile,
      name: editName.trim() || profile.name,
      age: Number(editAge) || profile.age,
      weightKg: Number(editWeight) || profile.weightKg,
      heightCm: Number(editHeight) || profile.heightCm,
    };
    onUpdateProfile(updated);
    saveHunterProfile(updated);
    setIsEditing(false);
  };

  const handleUpdateQuest = (field: 'pushups' | 'squats' | 'situps' | 'runKm', amount: number) => {
    sounds.playClick();
    const currentVal = profile.dailyQuest[field];
    const targetVal = profile.dailyQuest[`${field}Target` as keyof typeof profile.dailyQuest] as number;
    const newVal = Math.min(targetVal, Math.max(0, currentVal + amount));
    
    const updatedQuest = {
      ...profile.dailyQuest,
      [field]: newVal,
    };

    // check if all targets met
    const allDone = 
      updatedQuest.pushups >= updatedQuest.pushupsTarget &&
      updatedQuest.squats >= updatedQuest.squatsTarget &&
      updatedQuest.situps >= updatedQuest.situpsTarget &&
      updatedQuest.runKm >= updatedQuest.runKmTarget;

    updatedQuest.completed = allDone;

    const updatedProfile = {
      ...profile,
      dailyQuest: updatedQuest,
    };

    onUpdateProfile(updatedProfile);
    saveHunterProfile(updatedProfile);
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-6 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-purple-900/40">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-purple-400 uppercase tracking-widest">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            SYSTÈME DE CHASSEUR // STATUT ACTIF
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight mt-1">
            CARTE DE CHASSEUR OFFICIELLE
          </h1>
        </div>

        <button
          type="button"
          onClick={onStartWorkout}
          className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wider font-mono shadow-[0_0_20px_rgba(168,85,247,0.5)] flex items-center gap-2 transition-all active:scale-95"
        >
          <Dumbbell className="w-4 h-4" />
          LANCER UN ENTRAÎNEMENT
        </button>
      </div>

      {/* Main Hunter ID Card */}
      <div 
        className="bg-[#0c081e]/90 border border-purple-800/50 rounded-2xl p-6 relative overflow-hidden backdrop-blur-md shadow-[0_0_35px_rgba(147,51,234,0.2)]"
        style={{
          boxShadow: `0 0 30px ${currentRankInfo.glowColor}, inset 0 0 20px rgba(147, 51, 234, 0.1)`,
        }}
      >
        {/* Watermark Crest Background */}
        <div className="absolute right-4 top-4 text-purple-900/15 pointer-events-none text-9xl font-black font-mono select-none">
          {profile.rank}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 relative z-10 items-center">
          {/* Avatar & Rank Lockup */}
          <div className="md:col-span-4 flex flex-col items-center text-center">
            <div className="relative w-32 h-32 sm:w-36 sm:h-36 rounded-2xl p-1 bg-gradient-to-b from-purple-500 via-indigo-500 to-purple-900 shadow-[0_0_25px_rgba(168,85,247,0.5)] mb-3">
              <img
                src="/src/assets/images/hunter_monarch_avatar_1791831890613.jpg"
                alt="Avatar Chasseur"
                className="w-full h-full object-cover rounded-xl"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-2 -right-2 px-3 py-1 rounded-lg bg-black border-2 border-purple-400 text-white font-mono font-black text-sm shadow-md">
                RANG {profile.rank}
              </div>
            </div>

            <h2 className="text-xl font-black text-white font-mono tracking-tight">
              {profile.name}
            </h2>
            <div className="text-xs font-mono text-purple-300 mt-0.5">
              {currentRankInfo.title}
            </div>
            <div className="text-[11px] text-purple-400/80 mt-1 max-w-xs">
              {currentRankInfo.auraDescription}
            </div>
          </div>

          {/* Core Info & XP Bar */}
          <div className="md:col-span-8 space-y-4">
            {/* Level & XP Progression */}
            <div className="bg-[#120d2a] border border-purple-800/40 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-lg font-black text-white font-mono">
                    NIVEAU {profile.level}
                  </span>
                  <span className="text-xs font-mono text-cyan-400 px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40">
                    {profile.xp.toLocaleString()} EXP TOTAL
                  </span>
                </div>
                <div className="text-xs font-mono text-purple-300">
                  {progress.nextRank ? `PROCHAIN : RANG ${progress.nextRank}` : 'RANG MONARQUE MAXIMAL'}
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-3 bg-purple-950/80 rounded-full overflow-hidden p-0.5 border border-purple-800/50">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 rounded-full transition-all duration-500 shadow-[0_0_10px_#a855f7]"
                  style={{ width: `${progress.percentage}%` }}
                />
              </div>

              <div className="flex justify-between items-center text-[11px] font-mono text-purple-300/80 mt-1.5">
                <span>{progress.currentInTier.toLocaleString()} / {progress.tierTotal.toLocaleString()} EXP palier</span>
                <span className="font-bold text-white">{progress.percentage}%</span>
              </div>
            </div>

            {/* Email Account Sync Bar */}
            <div className="bg-[#140e2b] border border-purple-800/40 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 shadow-inner">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-purple-900/70 border border-purple-700/60 flex items-center justify-center text-purple-300 shrink-0">
                  <Mail className="w-4 h-4 text-purple-400" />
                </div>
                <div className="min-w-0">
                  <div className="text-[10px] font-mono text-purple-400 uppercase tracking-wider flex items-center gap-1.5">
                    Compte lié par E-mail
                    <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_6px_#34d399]" />
                  </div>
                  <div className="text-xs font-mono font-bold text-white truncate">
                    {profile.email || 'Non lié (session locale)'}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {onOpenInstallModal && (
                  <button
                    type="button"
                    onClick={() => {
                      sounds.playClick();
                      onOpenInstallModal();
                    }}
                    className="text-xs font-mono py-1 px-2.5 rounded-lg bg-gradient-to-r from-purple-800 to-indigo-800 hover:from-purple-700 hover:to-indigo-700 border border-purple-500/60 text-white font-bold transition-all flex items-center gap-1.5 shrink-0 shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5 animate-bounce" />
                    Installer l'App
                  </button>
                )}
                {onOpenAuthModal && (
                  <button
                    type="button"
                    onClick={() => {
                      sounds.playClick();
                      onOpenAuthModal();
                    }}
                    className="text-xs font-mono py-1 px-3 rounded-lg bg-purple-950/80 hover:bg-purple-900/80 border border-purple-700/60 text-purple-300 hover:text-white transition-all flex items-center gap-1.5 shrink-0"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    Changer de compte
                  </button>
                )}
              </div>
            </div>

            {/* Physical Attributes Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div className="bg-[#140e2b] border border-purple-800/30 rounded-xl p-3 text-center">
                <div className="text-[11px] font-mono text-purple-300/70">ÂGE</div>
                <div className="text-base font-bold text-white font-mono">{profile.age} ans</div>
              </div>
              <div className="bg-[#140e2b] border border-purple-800/30 rounded-xl p-3 text-center">
                <div className="text-[11px] font-mono text-purple-300/70">POIDS</div>
                <div className="text-base font-bold text-white font-mono">{profile.weightKg} kg</div>
              </div>
              <div className="bg-[#140e2b] border border-purple-800/30 rounded-xl p-3 text-center">
                <div className="text-[11px] font-mono text-purple-300/70">TAILLE</div>
                <div className="text-base font-bold text-white font-mono">{profile.heightCm} cm</div>
              </div>
              <div className="bg-[#140e2b] border border-purple-800/30 rounded-xl p-3 text-center">
                <div className="text-[11px] font-mono text-purple-300/70">IMC</div>
                <div className="text-base font-bold text-cyan-300 font-mono">{bmi}</div>
              </div>
            </div>

            {/* Edit Profile Trigger */}
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setIsEditing(!isEditing)}
                className="text-xs text-purple-300 hover:text-white flex items-center gap-1 font-mono transition-colors"
              >
                <Edit3 className="w-3.5 h-3.5" />
                {isEditing ? 'Fermer la modification' : 'Modifier mes informations physiques'}
              </button>
            </div>
          </div>
        </div>

        {/* Edit Form Drawer */}
        {isEditing && (
          <form onSubmit={handleSaveEdit} className="mt-6 pt-6 border-t border-purple-800/40 grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-[11px] font-mono text-purple-300 block mb-1">Nom de Chasseur</label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full bg-[#120d28] border border-purple-700/60 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-purple-400"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-purple-300 block mb-1">Âge</label>
              <input
                type="number"
                value={editAge}
                onChange={(e) => setEditAge(Number(e.target.value))}
                className="w-full bg-[#120d28] border border-purple-700/60 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-purple-400"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-purple-300 block mb-1">Poids (kg)</label>
              <input
                type="number"
                value={editWeight}
                onChange={(e) => setEditWeight(Number(e.target.value))}
                className="w-full bg-[#120d28] border border-purple-700/60 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-purple-400"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-purple-300 block mb-1">Taille (cm)</label>
              <input
                type="number"
                value={editHeight}
                onChange={(e) => setEditHeight(Number(e.target.value))}
                className="w-full bg-[#120d28] border border-purple-700/60 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-purple-400"
              />
            </div>
            <div className="sm:col-span-4 flex justify-end gap-2 mt-2">
              <button
                type="submit"
                className="py-2 px-4 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-mono text-xs font-bold flex items-center gap-1.5 transition-all"
              >
                <Check className="w-4 h-4" /> Sauvegarder
              </button>
            </div>
          </form>
        )}
      </div>

      {/* RPG Stats & Solo Leveling Daily Quest */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Hunter RPG Attributes */}
        <div className="md:col-span-5 bg-[#0c081e]/90 border border-purple-800/40 rounded-2xl p-5 backdrop-blur-md">
          <div className="flex items-center gap-2 mb-4">
            <Flame className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              ATTRIBUTS DU MONARQUE
            </h3>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-purple-300">FORCE (STRENGTH)</span>
                <span className="text-white font-bold">{profile.stats.strength} pts</span>
              </div>
              <div className="w-full h-2 bg-purple-950/80 rounded-full overflow-hidden">
                <div
                  className="h-full bg-red-500 rounded-full"
                  style={{ width: `${Math.min(100, profile.stats.strength * 2)}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-purple-300">AGILITÉ (SPEED)</span>
                <span className="text-white font-bold">{profile.stats.agility} pts</span>
              </div>
              <div className="w-full h-2 bg-purple-950/80 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{ width: `${Math.min(100, profile.stats.agility * 2)}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-purple-300">ENDURANCE (VITALITY)</span>
                <span className="text-white font-bold">{profile.stats.endurance} pts</span>
              </div>
              <div className="w-full h-2 bg-purple-950/80 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full"
                  style={{ width: `${Math.min(100, profile.stats.endurance * 2)}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-purple-300">PUISSANCE D'OMBRE (MANA)</span>
                <span className="text-cyan-400 font-bold">{profile.stats.shadowPower} pts</span>
              </div>
              <div className="w-full h-2 bg-purple-950/80 rounded-full overflow-hidden">
                <div
                  className="h-full bg-purple-500 shadow-[0_0_8px_#c084fc] rounded-full"
                  style={{ width: `${Math.min(100, profile.stats.shadowPower * 2)}%` }}
                />
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-purple-900/30 text-[11px] text-purple-400/80 font-mono">
            Chaque séance validée confère des augmentations permanentes de statistiques.
          </div>
        </div>

        {/* Daily Solo Leveling Quest */}
        <div className="md:col-span-7 bg-[#0c081e]/90 border border-purple-800/40 rounded-2xl p-5 backdrop-blur-md">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                QUÊTE QUOTIDIENNE DU SYSTÈME
              </h3>
            </div>
            {profile.dailyQuest.completed && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-500 text-emerald-400 font-bold">
                COMPLÉTÉE !
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Pushups */}
            <div className="bg-[#130d29] border border-purple-800/30 rounded-xl p-3">
              <div className="flex justify-between items-center text-xs font-mono text-purple-300 mb-1">
                <span>Pompes</span>
                <span className="text-white font-bold">{profile.dailyQuest.pushups} / {profile.dailyQuest.pushupsTarget}</span>
              </div>
              <div className="w-full h-2 bg-purple-950/80 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-purple-500 rounded-full"
                  style={{ width: `${Math.min(100, (profile.dailyQuest.pushups / profile.dailyQuest.pushupsTarget) * 100)}%` }}
                />
              </div>
              <div className="flex gap-1 justify-end">
                <button
                  type="button"
                  onClick={() => handleUpdateQuest('pushups', 10)}
                  className="text-[10px] px-2 py-0.5 rounded bg-purple-900/60 hover:bg-purple-800 text-purple-200 font-mono"
                >
                  +10
                </button>
              </div>
            </div>

            {/* Squats */}
            <div className="bg-[#130d29] border border-purple-800/30 rounded-xl p-3">
              <div className="flex justify-between items-center text-xs font-mono text-purple-300 mb-1">
                <span>Squats</span>
                <span className="text-white font-bold">{profile.dailyQuest.squats} / {profile.dailyQuest.squatsTarget}</span>
              </div>
              <div className="w-full h-2 bg-purple-950/80 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-purple-500 rounded-full"
                  style={{ width: `${Math.min(100, (profile.dailyQuest.squats / profile.dailyQuest.squatsTarget) * 100)}%` }}
                />
              </div>
              <div className="flex gap-1 justify-end">
                <button
                  type="button"
                  onClick={() => handleUpdateQuest('squats', 10)}
                  className="text-[10px] px-2 py-0.5 rounded bg-purple-900/60 hover:bg-purple-800 text-purple-200 font-mono"
                >
                  +10
                </button>
              </div>
            </div>

            {/* Situps */}
            <div className="bg-[#130d29] border border-purple-800/30 rounded-xl p-3">
              <div className="flex justify-between items-center text-xs font-mono text-purple-300 mb-1">
                <span>Abdominaux</span>
                <span className="text-white font-bold">{profile.dailyQuest.situps} / {profile.dailyQuest.situpsTarget}</span>
              </div>
              <div className="w-full h-2 bg-purple-950/80 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-purple-500 rounded-full"
                  style={{ width: `${Math.min(100, (profile.dailyQuest.situps / profile.dailyQuest.situpsTarget) * 100)}%` }}
                />
              </div>
              <div className="flex gap-1 justify-end">
                <button
                  type="button"
                  onClick={() => handleUpdateQuest('situps', 10)}
                  className="text-[10px] px-2 py-0.5 rounded bg-purple-900/60 hover:bg-purple-800 text-purple-200 font-mono"
                >
                  +10
                </button>
              </div>
            </div>

            {/* Run */}
            <div className="bg-[#130d29] border border-purple-800/30 rounded-xl p-3">
              <div className="flex justify-between items-center text-xs font-mono text-purple-300 mb-1">
                <span>Course à pied</span>
                <span className="text-white font-bold">{profile.dailyQuest.runKm} / {profile.dailyQuest.runKmTarget} km</span>
              </div>
              <div className="w-full h-2 bg-purple-950/80 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-cyan-500 rounded-full"
                  style={{ width: `${Math.min(100, (profile.dailyQuest.runKm / profile.dailyQuest.runKmTarget) * 100)}%` }}
                />
              </div>
              <div className="flex gap-1 justify-end">
                <button
                  type="button"
                  onClick={() => handleUpdateQuest('runKm', 1)}
                  className="text-[10px] px-2 py-0.5 rounded bg-cyan-900/60 hover:bg-cyan-800 text-cyan-200 font-mono"
                >
                  +1 km
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Workout History Log */}
      <div className="bg-[#0c081e]/90 border border-purple-800/40 rounded-2xl p-5 backdrop-blur-md">
        <div className="flex items-center gap-2 mb-4">
          <Calendar className="w-4 h-4 text-purple-400" />
          <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
            HISTORIQUE DES ENTRAÎNEMENTS ENREGISTRÉS
          </h3>
        </div>

        {profile.workoutHistory.length === 0 ? (
          <div className="text-center py-8 text-purple-300/60 font-mono text-sm border border-dashed border-purple-900/40 rounded-xl">
            Aucun entraînement sauvegardé pour le moment. Lancez votre première quête !
          </div>
        ) : (
          <div className="space-y-3">
            {profile.workoutHistory.map((item) => (
              <div
                key={item.id}
                className="bg-[#130d29] border border-purple-800/30 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-purple-400">{item.date}</span>
                    <span className="text-xs text-purple-300/60">·</span>
                    <span className="text-xs font-mono text-purple-200">{item.durationMinutes} min</span>
                  </div>
                  <div className="text-sm font-bold text-white mt-1">
                    Muscles ciblés : {item.musclesTrained.join(', ')}
                  </div>
                  <div className="text-xs text-purple-300/80 mt-0.5">
                    {item.exercises.length} exercices complétés
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-xs font-mono text-cyan-400 font-bold">+{item.xpEarned} EXP</div>
                    <div className="text-[10px] font-mono text-purple-300">Rang {item.rankAfter}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
