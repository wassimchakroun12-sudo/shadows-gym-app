import React from 'react';
import { HunterProfile } from '../types';
import { RANKS_CONFIG, RANK_ORDER, getXpProgressForCurrentRank, sounds } from '../utils/hunterSystem';
import { Translations } from '../i18n/translations';
import {
  ArrowRight,
  Dumbbell,
  Activity,
  Brain,
  Users,
  Trophy,
  Zap,
  Flame,
  Shield,
  ChevronRight,
  Sparkles,
  Download,
} from 'lucide-react';

interface HomeViewProps {
  profile: HunterProfile;
  t: Translations;
  onStartTraining: () => void;
  onViewPrograms: () => void;
  onViewProfile: () => void;
  onOpenInstallModal?: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  profile,
  t,
  onStartTraining,
  onViewPrograms,
  onViewProfile,
  onOpenInstallModal,
}) => {
  const currentRankInfo = RANKS_CONFIG[profile.rank];
  const progress = getXpProgressForCurrentRank(profile.xp, profile.rank);

  return (
    <div className="w-full flex flex-col space-y-12">
      {/* ================= HERO SECTION MATCHING IMAGE 1 ================= */}
      <section className="relative w-full min-h-[620px] sm:min-h-[700px] flex items-center justify-center overflow-hidden border-b border-purple-950/60">
        {/* Background Artwork */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/shadows_hero_art_1791831880938.jpg"
            alt="Shadows Gym Solo Leveling Hunter Artwork"
            className="w-full h-full object-cover object-center scale-105 transform motion-safe:animate-pulse"
            style={{ animationDuration: '8s' }}
            referrerPolicy="no-referrer"
          />
          {/* Multi-layer Gradient Scrim for contrast & anime aura */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#07050d] via-[#07050d]/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#07050d] via-transparent to-[#07050d]/70" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_40%,rgba(147,51,234,0.3)_0%,transparent_60%)]" />
        </div>

        {/* Hero Content Container */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-16 w-full flex flex-col justify-between h-full min-h-[580px] sm:min-h-[660px]">
          {/* Top Tagline & Main Titles */}
          <div className="max-w-2xl space-y-4 pt-4 sm:pt-8">
            {/* Emblem without square border */}
            <div className="flex items-center gap-3 mb-2">
              <img
                src="/src/assets/images/shadows_isolated_logo_1791833127584.jpg"
                alt="Shadows Gym Emblem"
                className="w-16 h-16 sm:w-20 sm:h-20 object-contain mix-blend-screen shrink-0 drop-shadow-[0_0_15px_rgba(168,85,247,0.9)] hover:scale-105 transition-transform"
                referrerPolicy="no-referrer"
              />
              <div className="inline-flex items-center gap-2 text-xs sm:text-sm font-mono font-bold tracking-widest text-purple-400 uppercase">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                {t.home.heroTag}
              </div>
            </div>

            {/* Huge Brush-Style Typography matching Image 1 */}
            <h1 className="text-5xl sm:text-7xl lg:text-8xl font-black italic tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-purple-200 via-purple-400 to-indigo-300 drop-shadow-[0_0_25px_rgba(168,85,247,0.8)] font-sans uppercase">
              SHADOWS GYM
            </h1>

            {/* Discipline Effort Results */}
            <div className="text-xs sm:text-sm font-mono tracking-widest text-purple-300 uppercase font-semibold">
              {t.home.heroSubtitle}
            </div>

            <p className="text-sm sm:text-base text-slate-300 max-w-xl font-normal leading-relaxed">
              {t.home.heroDesc}
            </p>

            {/* Action Buttons matching Image 1 */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  onStartTraining();
                }}
                className="py-3.5 px-7 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-mono font-black text-sm tracking-wider uppercase shadow-[0_0_25px_rgba(168,85,247,0.7)] flex items-center gap-2 transition-all active:scale-95 group"
              >
                <span>{t.home.btnStart}</span>
                <ArrowRight className="w-4 h-4 text-purple-200 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  onViewPrograms();
                }}
                className="py-3.5 px-6 rounded-xl bg-purple-950/60 hover:bg-purple-900/60 border border-purple-600/60 text-purple-200 hover:text-white font-mono font-bold text-sm tracking-wider uppercase transition-all backdrop-blur-sm"
              >
                {t.home.btnPrograms}
              </button>

              {onOpenInstallModal && (
                <button
                  type="button"
                  onClick={() => {
                    sounds.playClick();
                    onOpenInstallModal();
                  }}
                  className="py-3.5 px-5 rounded-xl bg-[#140d30]/90 hover:bg-purple-900/70 border border-purple-500/60 text-purple-200 hover:text-white font-mono font-bold text-sm tracking-wider uppercase transition-all backdrop-blur-sm flex items-center gap-2 shadow-[0_0_15px_rgba(168,85,247,0.3)] active:scale-95"
                >
                  <Download className="w-4 h-4 text-purple-400 animate-bounce" />
                  <span>{t.pwa.btnInstall}</span>
                </button>
              )}
            </div>
          </div>

          {/* NO PAIN NO GAIN Calligraphy on Right matching Image 1 */}
          <div className="hidden lg:block absolute right-8 bottom-28 text-right select-none pointer-events-none">
            <span className="text-4xl xl:text-5xl font-black italic tracking-widest text-purple-400/70 drop-shadow-[0_0_15px_rgba(168,85,247,0.6)] font-sans whitespace-pre-line">
              {t.home.noPain}
            </span>
          </div>

          {/* 4 Feature Pillars Bar matching Image 1 bottom strip */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 pt-10">
            {/* Musculation */}
            <div className="bg-[#0f0a24]/80 border border-purple-800/40 rounded-xl p-3 sm:p-4 backdrop-blur-md flex items-center gap-3 hover:border-purple-500 transition-all">
              <div className="p-2 sm:p-2.5 rounded-lg bg-purple-950 text-purple-400 border border-purple-700/50">
                <Dumbbell className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs sm:text-sm font-bold text-white font-mono uppercase">
                  {t.home.pillarMuscuTitle}
                </div>
                <div className="text-[11px] text-purple-300/70">
                  {t.home.pillarMuscuDesc}
                </div>
              </div>
            </div>

            {/* Cardio */}
            <div className="bg-[#0f0a24]/80 border border-purple-800/40 rounded-xl p-3 sm:p-4 backdrop-blur-md flex items-center gap-3 hover:border-purple-500 transition-all">
              <div className="p-2 sm:p-2.5 rounded-lg bg-purple-950 text-purple-400 border border-purple-700/50">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs sm:text-sm font-bold text-white font-mono uppercase">
                  {t.home.pillarCardioTitle}
                </div>
                <div className="text-[11px] text-purple-300/70">
                  {t.home.pillarCardioDesc}
                </div>
              </div>
            </div>

            {/* Coaching */}
            <div className="bg-[#0f0a24]/80 border border-purple-800/40 rounded-xl p-3 sm:p-4 backdrop-blur-md flex items-center gap-3 hover:border-purple-500 transition-all">
              <div className="p-2 sm:p-2.5 rounded-lg bg-purple-950 text-purple-400 border border-purple-700/50">
                <Brain className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs sm:text-sm font-bold text-white font-mono uppercase">
                  {t.home.pillarCoachingTitle}
                </div>
                <div className="text-[11px] text-purple-300/70">
                  {t.home.pillarCoachingDesc}
                </div>
              </div>
            </div>

            {/* Communauté */}
            <div className="bg-[#0f0a24]/80 border border-purple-800/40 rounded-xl p-3 sm:p-4 backdrop-blur-md flex items-center gap-3 hover:border-purple-500 transition-all">
              <div className="p-2 sm:p-2.5 rounded-lg bg-purple-950 text-purple-400 border border-purple-700/50">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs sm:text-sm font-bold text-white font-mono uppercase">
                  {t.home.pillarCommunityTitle}
                </div>
                <div className="text-[11px] text-purple-300/70">
                  {t.home.pillarCommunityDesc}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================= USER HUNTER STATUS HUD WIDGET ON HOME (Requested) ================= */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 w-full">
        <div 
          className="bg-gradient-to-br from-[#0e0924] via-[#090618] to-[#0e0924] border-2 border-purple-600/60 rounded-3xl p-6 sm:p-8 relative overflow-hidden backdrop-blur-md shadow-[0_0_40px_rgba(147,51,234,0.25)]"
          style={{
            boxShadow: `0 0 35px ${currentRankInfo.glowColor}, inset 0 0 25px rgba(147, 51, 234, 0.1)`,
          }}
        >
          {/* Cyber scan lines */}
          <div 
            className="absolute inset-0 opacity-10 pointer-events-none"
            style={{
              backgroundImage: 'linear-gradient(to right, rgba(168, 85, 247, 0.2) 1px, transparent 1px), linear-gradient(to bottom, rgba(168, 85, 247, 0.2) 1px, transparent 1px)',
              backgroundSize: '20px 20px',
            }}
          />

          <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-6">
            {/* Left: Avatar + Identity */}
            <div className="flex items-center gap-5 w-full lg:w-auto">
              <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl p-1 bg-gradient-to-tr from-purple-500 to-indigo-500 shadow-[0_0_20px_rgba(168,85,247,0.5)] shrink-0">
                <img
                  src="/src/assets/images/hunter_monarch_avatar_1791831890613.jpg"
                  alt="Avatar"
                  className="w-full h-full object-cover rounded-xl"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute -bottom-1 -right-1 px-2 py-0.5 rounded bg-black border border-purple-400 text-white font-mono font-black text-xs">
                  {profile.rank}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950/80 border border-purple-600 text-purple-300 uppercase">
                    {t.home.hudSystemTitle}
                  </span>
                  <span className="text-[10px] font-mono text-cyan-400">
                    {t.home.hudStreak} : {profile.streakDays} J
                  </span>
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-white font-mono mt-1">
                  {profile.name.toUpperCase()}
                </h3>
                <div className="text-xs font-mono text-purple-300">
                  {currentRankInfo.title} · {t.nav.level} {profile.level}
                </div>
              </div>
            </div>

            {/* Center: XP Bar & Level Stats */}
            <div className="w-full lg:max-w-md space-y-2">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-purple-300">
                  {t.home.hudRankProgress} : RANG {profile.rank} → {progress.nextRank ? `RANG ${progress.nextRank}` : 'MAX'}
                </span>
                <span className="text-white font-bold">{progress.percentage}%</span>
              </div>

              <div className="w-full h-3.5 bg-purple-950/80 rounded-full overflow-hidden p-0.5 border border-purple-800/60">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 rounded-full transition-all duration-500 shadow-[0_0_10px_#a855f7]"
                  style={{ width: `${progress.percentage}%` }}
                />
              </div>

              <div className="flex justify-between items-center text-[11px] font-mono text-purple-300/80">
                <span>{profile.xp.toLocaleString()} {t.home.hudTotalXp}</span>
                <span className="text-cyan-400">
                  {progress.nextRank ? `${progress.tierTotal - progress.currentInTier} ${t.home.hudXpNeeded}` : 'Monarque Absolu'}
                </span>
              </div>
            </div>

            {/* Right: Quick Action Buttons */}
            <div className="flex items-center gap-3 w-full lg:w-auto justify-end">
              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  onViewProfile();
                }}
                className="py-3 px-4 rounded-xl bg-purple-950/70 border border-purple-700/60 hover:bg-purple-900/60 text-purple-200 text-xs font-mono font-bold uppercase transition-all"
              >
                {t.home.hudViewProfile}
              </button>

              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  onStartTraining();
                }}
                className="py-3 px-5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-mono font-bold text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(168,85,247,0.5)] flex items-center gap-1.5 transition-all active:scale-95"
              >
                <Dumbbell className="w-4 h-4" />
                {t.home.hudTrainNow}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ================= SOLO LEVELING RANKS LADDER SECTION ================= */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 w-full space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 border-b border-purple-900/40 pb-4">
          <div>
            <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-purple-400" />
              {t.home.ladderTag}
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight mt-1">
              {t.home.ladderTitle}
            </h2>
          </div>
          <p className="text-xs text-purple-300/70 max-w-sm">
            {t.home.ladderDesc}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {RANK_ORDER.map((rankKey) => {
            const rInfo = RANKS_CONFIG[rankKey];
            const isUserRank = profile.rank === rankKey;

            return (
              <div
                key={rankKey}
                className={`rounded-2xl p-4 border transition-all relative overflow-hidden backdrop-blur-md ${
                  isUserRank
                    ? 'bg-purple-950/70 border-purple-400 shadow-[0_0_20px_rgba(168,85,247,0.4)]'
                    : 'bg-[#0c081e]/80 border-purple-900/40 hover:border-purple-700/60'
                }`}
              >
                {isUserRank && (
                  <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-purple-500 text-white font-mono text-[9px] font-black uppercase">
                    {t.home.currentRankBadge}
                  </div>
                )}

                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700 flex items-center justify-center font-black text-lg font-mono text-white">
                    {rankKey}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white font-mono">{rInfo.title}</div>
                    <div className="text-[10px] font-mono text-purple-300/80">
                      {rInfo.minXp.toLocaleString()} - {rInfo.maxXp.toLocaleString()} EXP
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-purple-300/70 mt-2 leading-relaxed">
                  {rInfo.auraDescription}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* ================= FOOTER ================= */}
      <footer className="w-full bg-[#05030a] border-t border-purple-950/60 py-8 px-4 text-center text-xs text-purple-400/60 font-mono">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">SHADOWS GYM</span>
            <span>· Solo Leveling Fitness</span>
          </div>
          <div>
            Discipline · Effort · Résultats
          </div>
        </div>
      </footer>
    </div>
  );
};
