import React, { useState } from 'react';
import { Language, Translations } from '../i18n/translations';
import { HunterProfile } from '../types';
import { sounds, INITIAL_HUNTER_PROFILE, saveHunterProfile } from '../utils/hunterSystem';
import {
  Moon,
  Sun,
  Globe,
  Volume2,
  VolumeX,
  RotateCcw,
  Shield,
  Check,
  AlertTriangle,
  Mail,
  Download,
  Smartphone,
} from 'lucide-react';

interface SettingsViewProps {
  theme: 'dark' | 'light';
  onThemeChange: (theme: 'dark' | 'light') => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  t: Translations;
  profile: HunterProfile;
  onResetProfile: () => void;
  onOpenAuthModal?: () => void;
  onOpenInstallModal?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  theme,
  onThemeChange,
  language,
  onLanguageChange,
  t,
  profile,
  onResetProfile,
  onOpenAuthModal,
  onOpenInstallModal,
}) => {
  const [isMuted, setIsMuted] = useState(sounds.getMuted());
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [resetMessage, setResetMessage] = useState<string | null>(null);

  const handleToggleTheme = (newTheme: 'dark' | 'light') => {
    sounds.playClick();
    onThemeChange(newTheme);
  };

  const handleSelectLang = (lang: Language) => {
    sounds.playClick();
    onLanguageChange(lang);
  };

  const handleToggleSound = () => {
    const next = sounds.toggleMute();
    setIsMuted(next);
  };

  const handleConfirmReset = () => {
    sounds.playClick();
    onResetProfile();
    setShowConfirmReset(false);
    setResetMessage(t.settings.resetSuccess);
    setTimeout(() => setResetMessage(null), 3000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8 space-y-6 animate-in fade-in duration-300">
      {/* Settings Header */}
      <div className="pb-4 border-b border-purple-900/40">
        <div className="text-xs font-mono text-purple-400 uppercase tracking-widest flex items-center gap-1.5">
          <Shield className="w-4 h-4 text-cyan-400" />
          {t.settings.title}
        </div>
        <h1 className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-white dark:text-white mt-1">
          {t.settings.title}
        </h1>
        <p className="text-xs sm:text-sm text-purple-300/80 mt-1">
          {t.settings.subtitle}
        </p>
      </div>

      {resetMessage && (
        <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-500 text-emerald-300 text-sm font-mono flex items-center gap-2">
          <Check className="w-4 h-4" />
          {resetMessage}
        </div>
      )}

      {/* 0. Account & Email Sync */}
      <div className="bg-[#0c081e]/90 border border-purple-800/40 rounded-2xl p-6 backdrop-blur-md shadow-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white font-mono flex items-center gap-2">
              <Mail className="w-5 h-5 text-purple-400" />
              Compte & Liaison E-mail
            </h2>
            <p className="text-xs text-purple-300/70 mt-1">
              Votre progression, XP et rang sont sauvegardés et synchronisés avec votre adresse e-mail.
            </p>
          </div>

          {onOpenAuthModal && (
            <button
              type="button"
              onClick={() => {
                sounds.playClick();
                onOpenAuthModal();
              }}
              className="py-2 px-4 rounded-xl bg-purple-900/60 hover:bg-purple-800/60 border border-purple-600/60 text-white font-mono text-xs font-bold transition-all shadow-sm flex items-center gap-2 self-start sm:self-auto"
            >
              <Mail className="w-3.5 h-3.5 text-purple-400" />
              Gérer / Changer de compte
            </button>
          )}
        </div>

        <div className="p-3.5 rounded-xl bg-[#130d2d] border border-purple-800/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
            <span className="text-xs font-mono text-purple-300">
              E-mail actif : <strong className="text-white">{profile.email || 'Mode invité'}</strong>
            </span>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-2 py-0.5 rounded">
            SYNCHRONISÉ
          </span>
        </div>
      </div>

      {/* PWA & Store Installation Section */}
      <div className="bg-[#0c081e]/90 border border-purple-800/40 rounded-2xl p-6 backdrop-blur-md shadow-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white font-mono flex items-center gap-2">
              <Download className="w-5 h-5 text-purple-400" />
              Application & Téléchargement (Google & Play Store)
            </h2>
            <p className="text-xs text-purple-300/70 mt-1">
              Installez l'application directement depuis Google Chrome ou consultez la compatibilité Google Play Store (TWA / WebAPK).
            </p>
          </div>

          {onOpenInstallModal && (
            <button
              type="button"
              onClick={() => {
                sounds.playClick();
                onOpenInstallModal();
              }}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 border border-purple-400/60 text-white font-mono text-xs font-bold transition-all shadow-[0_0_15px_rgba(168,85,247,0.4)] flex items-center gap-2 self-start sm:self-auto active:scale-95"
            >
              <Smartphone className="w-4 h-4 text-purple-200" />
              Ouvrir le guide d'installation
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="p-3 rounded-xl bg-[#130d2d] border border-purple-900/40">
            <span className="text-[11px] font-mono font-bold text-green-400 block mb-1">✓ GOOGLE CHROME</span>
            <span className="text-xs text-gray-300">Installation 1-clic directe sans store avec icône native.</span>
          </div>
          <div className="p-3 rounded-xl bg-[#130d2d] border border-purple-900/40">
            <span className="text-[11px] font-mono font-bold text-blue-400 block mb-1">✓ PLAY STORE READY</span>
            <span className="text-xs text-gray-300">Manifeste PWA conforme Trusted Web Activity (TWA).</span>
          </div>
          <div className="p-3 rounded-xl bg-[#130d2d] border border-purple-900/40">
            <span className="text-[11px] font-mono font-bold text-purple-400 block mb-1">✓ 100% HORS-LIGNE</span>
            <span className="text-xs text-gray-300">Entraînez-vous partout sans réseau ni coupure.</span>
          </div>
        </div>
      </div>

      {/* 1. Theme Setting (Dark Mode vs Light Mode) */}
      <div className="bg-[#0c081e]/90 dark:bg-[#0c081e]/90 light:bg-white border border-purple-800/40 rounded-2xl p-6 backdrop-blur-md shadow-lg space-y-4">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white font-mono flex items-center gap-2">
            {theme === 'dark' ? <Moon className="w-5 h-5 text-purple-400" /> : <Sun className="w-5 h-5 text-amber-400" />}
            {t.settings.themeTitle}
          </h2>
          <p className="text-xs text-purple-300/70 mt-1">
            {t.settings.themeDesc}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {/* Dark Mode */}
          <button
            type="button"
            onClick={() => handleToggleTheme('dark')}
            className={`p-4 rounded-xl border flex items-center justify-between transition-all ${
              theme === 'dark'
                ? 'bg-purple-950/80 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.4)] text-white'
                : 'bg-[#120d28]/40 border-purple-900/30 text-purple-300/70 hover:text-white hover:border-purple-700'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-black border border-purple-600 flex items-center justify-center text-purple-300">
                <Moon className="w-4 h-4" />
              </div>
              <div className="text-left">
                <div className="text-sm font-bold font-mono">{t.settings.dark}</div>
                <div className="text-[11px] text-purple-400/80 font-mono">Solo Leveling Cyberpunk</div>
              </div>
            </div>
            {theme === 'dark' && <Check className="w-5 h-5 text-cyan-400 stroke-[3]" />}
          </button>

          {/* Light Mode */}
          <button
            type="button"
            onClick={() => handleToggleTheme('light')}
            className={`p-4 rounded-xl border flex items-center justify-between transition-all ${
              theme === 'light'
                ? 'bg-purple-950/80 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.4)] text-white'
                : 'bg-[#120d28]/40 border-purple-900/30 text-purple-300/70 hover:text-white hover:border-purple-700'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-slate-800 border border-amber-400 flex items-center justify-center text-amber-300">
                <Sun className="w-4 h-4" />
              </div>
              <div className="text-left">
                <div className="text-sm font-bold font-mono">{t.settings.light}</div>
                <div className="text-[11px] text-purple-400/80 font-mono">Clair & Lumineux</div>
              </div>
            </div>
            {theme === 'light' && <Check className="w-5 h-5 text-cyan-400 stroke-[3]" />}
          </button>
        </div>
      </div>

      {/* 2. Language Setting (English, French, Arabic) */}
      <div className="bg-[#0c081e]/90 border border-purple-800/40 rounded-2xl p-6 backdrop-blur-md shadow-lg space-y-4">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white font-mono flex items-center gap-2">
            <Globe className="w-5 h-5 text-cyan-400" />
            {t.settings.langTitle}
          </h2>
          <p className="text-xs text-purple-300/70 mt-1">
            {t.settings.langDesc}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          {/* French */}
          <button
            type="button"
            onClick={() => handleSelectLang('fr')}
            className={`p-4 rounded-xl border flex items-center justify-between transition-all ${
              language === 'fr'
                ? 'bg-purple-950/80 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.4)] text-white'
                : 'bg-[#120d28]/40 border-purple-900/30 text-purple-300/70 hover:text-white hover:border-purple-700'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">🇫🇷</span>
              <div className="text-left">
                <div className="text-sm font-bold font-mono">Français</div>
                <div className="text-[10px] text-purple-400/80 font-mono">French</div>
              </div>
            </div>
            {language === 'fr' && <Check className="w-4 h-4 text-cyan-400 stroke-[3]" />}
          </button>

          {/* English */}
          <button
            type="button"
            onClick={() => handleSelectLang('en')}
            className={`p-4 rounded-xl border flex items-center justify-between transition-all ${
              language === 'en'
                ? 'bg-purple-950/80 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.4)] text-white'
                : 'bg-[#120d28]/40 border-purple-900/30 text-purple-300/70 hover:text-white hover:border-purple-700'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">🇬🇧</span>
              <div className="text-left">
                <div className="text-sm font-bold font-mono">English</div>
                <div className="text-[10px] text-purple-400/80 font-mono">International</div>
              </div>
            </div>
            {language === 'en' && <Check className="w-4 h-4 text-cyan-400 stroke-[3]" />}
          </button>

          {/* Arabic */}
          <button
            type="button"
            onClick={() => handleSelectLang('ar')}
            className={`p-4 rounded-xl border flex items-center justify-between transition-all ${
              language === 'ar'
                ? 'bg-purple-950/80 border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.4)] text-white'
                : 'bg-[#120d28]/40 border-purple-900/30 text-purple-300/70 hover:text-white hover:border-purple-700'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">🇹🇳</span>
              <div className="text-left">
                <div className="text-sm font-bold font-mono">العربية</div>
                <div className="text-[10px] text-purple-400/80 font-mono">Arabic (RTL)</div>
              </div>
            </div>
            {language === 'ar' && <Check className="w-4 h-4 text-cyan-400 stroke-[3]" />}
          </button>
        </div>
      </div>

      {/* 3. Audio Sound SFX Setting */}
      <div className="bg-[#0c081e]/90 border border-purple-800/40 rounded-2xl p-6 backdrop-blur-md shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white font-mono flex items-center gap-2">
              {isMuted ? <VolumeX className="w-5 h-5 text-purple-400" /> : <Volume2 className="w-5 h-5 text-cyan-400" />}
              {t.settings.soundTitle}
            </h2>
            <p className="text-xs text-purple-300/70 mt-1">
              {t.settings.soundDesc}
            </p>
          </div>

          <button
            type="button"
            onClick={handleToggleSound}
            className={`py-2 px-4 rounded-xl font-mono text-xs font-bold transition-all ${
              !isMuted
                ? 'bg-emerald-600 text-white shadow-[0_0_12px_rgba(16,185,129,0.4)]'
                : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            {!isMuted ? t.settings.soundEnabled : t.settings.soundDisabled}
          </button>
        </div>
      </div>

      {/* 4. Reset Data Option */}
      <div className="bg-[#0c081e]/90 border border-red-900/40 rounded-2xl p-6 backdrop-blur-md shadow-lg space-y-4">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white font-mono flex items-center gap-2">
            <RotateCcw className="w-5 h-5 text-red-400" />
            {t.settings.resetTitle}
          </h2>
          <p className="text-xs text-purple-300/70 mt-1">
            {t.settings.resetDesc}
          </p>
        </div>

        {!showConfirmReset ? (
          <button
            type="button"
            onClick={() => setShowConfirmReset(true)}
            className="py-2.5 px-4 rounded-xl bg-red-950/60 border border-red-700/60 hover:bg-red-900/60 text-red-300 hover:text-white font-mono text-xs font-bold transition-all"
          >
            {t.settings.btnReset}
          </button>
        ) : (
          <div className="p-4 rounded-xl bg-red-950/90 border border-red-500 space-y-3">
            <div className="flex items-center gap-2 text-xs font-mono text-red-300">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
              {t.settings.confirmReset}
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleConfirmReset}
                className="py-2 px-4 rounded-lg bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold"
              >
                Confirmer la réinitialisation
              </button>
              <button
                type="button"
                onClick={() => setShowConfirmReset(false)}
                className="py-2 px-4 rounded-lg bg-zinc-800 text-zinc-300 font-mono text-xs"
              >
                Annuler
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
