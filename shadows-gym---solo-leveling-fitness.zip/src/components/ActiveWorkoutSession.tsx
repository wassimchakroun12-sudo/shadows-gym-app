import React, { useState, useEffect } from 'react';
import { MuscleId, ExerciseDefinition, WorkoutExerciseLog, WorkoutHistoryEntry, HunterRank, HunterProfile } from '../types';
import { getExercisesForMuscles } from '../data/exercises';
import { ExerciseAnimation } from './ExerciseAnimation';
import { sounds, calculateLevelFromXp, calculateRankFromXp, saveHunterProfile } from '../utils/hunterSystem';
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Clock,
  Dumbbell,
  Flame,
  Info,
  Save,
  Trophy,
  Zap,
} from 'lucide-react';

interface ActiveWorkoutSessionProps {
  selectedMuscles: MuscleId[];
  profile: HunterProfile;
  onFinishWorkout: (workoutSummary: {
    historyEntry: WorkoutHistoryEntry;
    xpEarned: number;
    levelBefore: number;
    levelAfter: number;
    rankBefore: HunterRank;
    rankAfter: HunterRank;
  }) => void;
  onBackToExercises: () => void;
}

export const ActiveWorkoutSession: React.FC<ActiveWorkoutSessionProps> = ({
  selectedMuscles,
  profile,
  onFinishWorkout,
  onBackToExercises,
}) => {
  const exercises = getExercisesForMuscles(selectedMuscles);
  const [activeExerciseIndex, setActiveExerciseIndex] = useState(0);

  // Exercise set tracking state: exerciseId -> sets
  const [exerciseLogs, setExerciseLogs] = useState<
    Record<
      string,
      {
        setNum: number;
        weightKg: number;
        reps: number;
        completed: boolean;
      }[]
    >
  >(() => {
    const initial: Record<string, { setNum: number; weightKg: number; reps: number; completed: boolean }[]> = {};
    exercises.forEach((ex) => {
      initial[ex.id] = Array.from({ length: ex.defaultSets }, (_, i) => ({
        setNum: i + 1,
        weightKg: 50,
        reps: 10,
        completed: false,
      }));
    });
    return initial;
  });

  // Elapsed workout time
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const currentExercise = exercises[activeExerciseIndex] || exercises[0];
  const currentSets = exerciseLogs[currentExercise.id] || [];

  const handleToggleSet = (setIndex: number) => {
    sounds.playClick();
    const updatedSets = [...currentSets];
    updatedSets[setIndex] = {
      ...updatedSets[setIndex],
      completed: !updatedSets[setIndex].completed,
    };

    setExerciseLogs({
      ...exerciseLogs,
      [currentExercise.id]: updatedSets,
    });
  };

  const handleUpdateSetValue = (setIndex: number, field: 'weightKg' | 'reps', value: number) => {
    const updatedSets = [...currentSets];
    updatedSets[setIndex] = {
      ...updatedSets[setIndex],
      [field]: Math.max(0, value),
    };

    setExerciseLogs({
      ...exerciseLogs,
      [currentExercise.id]: updatedSets,
    });
  };

  // Count total completed sets across all exercises
  const totalSetsCount = Object.values(exerciseLogs).reduce((acc, sets) => acc + sets.length, 0);
  const completedSetsCount = Object.values(exerciseLogs).reduce(
    (acc, sets) => acc + sets.filter((s) => s.completed).length,
    0
  );

  // Calculate projected XP
  const baseSessionXp = 150;
  const xpPerSet = 25;
  const xpPerExercise = 50;
  const completedExercisesCount = Object.values(exerciseLogs).filter(
    (sets) => sets.filter((s) => s.completed).length >= Math.ceil(sets.length / 2)
  ).length;

  const calculatedXp =
    baseSessionXp +
    completedSetsCount * xpPerSet +
    completedExercisesCount * xpPerExercise +
    selectedMuscles.length * 15;

  const handleSaveAndComplete = () => {
    sounds.playLevelUp();

    const durationMin = Math.max(1, Math.round(elapsedSeconds / 60));
    const levelBefore = profile.level;
    const rankBefore = profile.rank;
    const newTotalXp = profile.xp + calculatedXp;
    const levelAfter = calculateLevelFromXp(newTotalXp);
    const rankAfter = calculateRankFromXp(newTotalXp);

    const historyEntry: WorkoutHistoryEntry = {
      id: `workout_${Date.now()}`,
      date: new Date().toLocaleDateString('fr-FR', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }),
      durationMinutes: durationMin,
      musclesTrained: selectedMuscles.map((m) => m.toUpperCase()),
      exercises: exercises.map((ex) => ({
        exerciseId: ex.id,
        exerciseName: ex.name,
        targetMuscles: ex.targetMusclesLabels,
        sets: exerciseLogs[ex.id] || [],
      })),
      xpEarned: calculatedXp,
      levelBefore,
      levelAfter,
      rankAfter,
    };

    onFinishWorkout({
      historyEntry,
      xpEarned: calculatedXp,
      levelBefore,
      levelAfter,
      rankBefore,
      rankAfter,
    });
  };

  const formatElapsedTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-6 space-y-6">
      {/* 4-Step Stepper Navigation */}
      <div className="w-full">
        <div className="grid grid-cols-4 gap-2 bg-[#0d0920] p-2 rounded-2xl border border-purple-900/50 shadow-inner">
          <button
            type="button"
            onClick={onBackToExercises}
            className="flex items-center gap-2 p-2 rounded-xl text-purple-300/80 hover:bg-purple-950/40 text-left transition-colors"
          >
            <span className="w-5 h-5 rounded-full bg-purple-900 text-purple-300 flex items-center justify-center text-xs font-mono">
              ✓
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] text-purple-400 font-mono">1/4</div>
              <div className="text-xs font-bold text-slate-300 leading-tight">Informations</div>
            </div>
          </button>

          <button
            type="button"
            onClick={onBackToExercises}
            className="flex items-center gap-2 p-2 rounded-xl text-purple-300/80 hover:bg-purple-950/40 text-left transition-colors"
          >
            <span className="w-5 h-5 rounded-full bg-purple-900 text-purple-300 flex items-center justify-center text-xs font-mono">
              ✓
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] text-purple-400 font-mono">2/4</div>
              <div className="text-xs font-bold text-slate-300 leading-tight">Muscles</div>
            </div>
          </button>

          <button
            type="button"
            onClick={onBackToExercises}
            className="flex items-center gap-2 p-2 rounded-xl text-purple-300/80 hover:bg-purple-950/40 text-left transition-colors"
          >
            <span className="w-5 h-5 rounded-full bg-purple-900 text-purple-300 flex items-center justify-center text-xs font-mono">
              ✓
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] text-purple-400 font-mono">3/4</div>
              <div className="text-xs font-bold text-slate-300 leading-tight">Exercices</div>
            </div>
          </button>

          <div className="flex items-center gap-2 p-2 rounded-xl bg-purple-600/30 border border-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.4)]">
            <span className="w-5 h-5 rounded-full bg-purple-500 text-white flex items-center justify-center text-xs font-mono font-bold">
              4
            </span>
            <div className="hidden sm:block">
              <div className="text-[10px] text-purple-300 font-mono">4/4</div>
              <div className="text-xs font-bold text-white leading-tight">Séance Active</div>
            </div>
          </div>
        </div>
      </div>

      {/* Top Live Stats HUD */}
      <div className="bg-[#0b071c]/90 border border-purple-900/50 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 backdrop-blur-md shadow-[0_0_20px_rgba(112,26,179,0.15)]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/60 flex items-center justify-center text-purple-400">
            <Clock className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="text-[11px] font-mono text-purple-300/70 uppercase">DURÉE SÉANCE</div>
            <div className="text-lg font-black text-white font-mono">{formatElapsedTime(elapsedSeconds)}</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/60 flex items-center justify-center text-purple-400">
            <Dumbbell className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <div className="text-[11px] font-mono text-purple-300/70 uppercase">SÉRIES VALIDÉES</div>
            <div className="text-lg font-black text-white font-mono">
              {completedSetsCount} / {totalSetsCount}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/60 flex items-center justify-center text-purple-400">
            <Zap className="w-5 h-5 text-yellow-400" />
          </div>
          <div>
            <div className="text-[11px] font-mono text-purple-300/70 uppercase">EXP ESTIMÉ</div>
            <div className="text-lg font-black text-cyan-300 font-mono drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]">
              +{calculatedXp} XP
            </div>
          </div>
        </div>

        {/* Exercises Selector Strip */}
        <div className="w-full flex items-center gap-2 overflow-x-auto pb-1 pt-2 border-t border-purple-900/30">
          {exercises.map((ex, idx) => {
            const isCurrent = idx === activeExerciseIndex;
            const exSets = exerciseLogs[ex.id] || [];
            const doneCount = exSets.filter((s) => s.completed).length;
            const isExDone = doneCount === exSets.length;

            return (
              <button
                key={ex.id}
                type="button"
                onClick={() => {
                  sounds.playClick();
                  setActiveExerciseIndex(idx);
                }}
                className={`py-1.5 px-3 rounded-xl border text-xs font-mono font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  isCurrent
                    ? 'bg-purple-600 border-purple-400 text-white shadow-[0_0_12px_rgba(168,85,247,0.5)]'
                    : isExDone
                    ? 'bg-emerald-950/60 border-emerald-600/60 text-emerald-300'
                    : 'bg-[#120d28]/60 border-purple-900/40 text-purple-300/70 hover:text-white'
                }`}
              >
                <span>{idx + 1}. {ex.name}</span>
                <span className="text-[10px] opacity-75">({doneCount}/{exSets.length})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Dual Grid: Exercise Details & Animation on Left, Sets & Rest Timer on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Animation & Form Guide */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-[#0b071c]/90 border border-purple-900/50 rounded-2xl p-5 backdrop-blur-md shadow-[0_0_25px_rgba(112,26,179,0.15)]">
            <div className="flex items-center justify-between mb-3">
              <div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 border border-purple-700 text-purple-300 uppercase">
                  EXERCICE {activeExerciseIndex + 1} SUR {exercises.length}
                </span>
                <h2 className="text-xl font-black text-white font-mono tracking-tight mt-1">
                  {currentExercise.name}
                </h2>
                <div className="text-xs text-purple-300/80 mt-0.5">
                  Muscles ciblés : {currentExercise.targetMusclesLabels.join(' · ')}
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  disabled={activeExerciseIndex === 0}
                  onClick={() => {
                    sounds.playClick();
                    setActiveExerciseIndex((prev) => Math.max(0, prev - 1));
                  }}
                  className="p-2 rounded-xl bg-purple-950 border border-purple-800 text-purple-300 disabled:opacity-30 hover:text-white transition-all"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  disabled={activeExerciseIndex === exercises.length - 1}
                  onClick={() => {
                    sounds.playClick();
                    setActiveExerciseIndex((prev) => Math.min(exercises.length - 1, prev + 1));
                  }}
                  className="p-2 rounded-xl bg-purple-950 border border-purple-800 text-purple-300 disabled:opacity-30 hover:text-white transition-all"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Kinetic Animation loop */}
            <ExerciseAnimation exercise={currentExercise} />

            {/* Instructions */}
            <div className="mt-4 space-y-2">
              <div className="text-xs font-mono text-purple-300 uppercase font-bold flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-cyan-400" />
                CONSIGNES D'EXÉCUTION DU SYSTÈME :
              </div>
              <ul className="text-xs text-purple-200/80 space-y-1 list-disc pl-4 font-sans">
                {currentExercise.executionSteps.map((step, idx) => (
                  <li key={idx}>{step}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Right Column: Sets Logger & Rest Timer */}
        <div className="lg:col-span-6 space-y-4">
          {/* Sets Tracker */}
          <div className="bg-[#0b071c]/90 border border-purple-900/50 rounded-2xl p-5 backdrop-blur-md shadow-[0_0_25px_rgba(112,26,179,0.15)]">
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-3">
              <span className="text-sm font-black text-white font-mono uppercase tracking-wider flex items-center gap-2">
                <Dumbbell className="w-4 h-4 text-purple-400" />
                JOURNAL DES SÉRIES
              </span>
              <span className="text-xs font-mono text-purple-300">
                Objectif : {currentExercise.defaultSets} séries × {currentExercise.defaultReps}
              </span>
            </div>

            {/* Set Rows */}
            <div className="space-y-2.5">
              {currentSets.map((set, setIdx) => (
                <div
                  key={set.setNum}
                  className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                    set.completed
                      ? 'bg-purple-950/70 border-purple-500 shadow-[0_0_12px_rgba(168,85,247,0.3)]'
                      : 'bg-[#120d28]/50 border-purple-900/40'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-lg bg-purple-900/80 border border-purple-700/60 text-purple-200 font-mono text-xs font-bold flex items-center justify-center">
                      S{set.setNum}
                    </span>

                    {/* Weight Input */}
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min={0}
                        max={500}
                        value={set.weightKg}
                        onChange={(e) => handleUpdateSetValue(setIdx, 'weightKg', Number(e.target.value))}
                        className="w-16 bg-[#1a1336] border border-purple-700/60 rounded-lg px-2 py-1 text-center font-mono text-xs text-white outline-none focus:border-purple-400"
                      />
                      <span className="text-xs font-mono text-purple-300/70">kg</span>
                    </div>

                    {/* Reps Input */}
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={set.reps}
                        onChange={(e) => handleUpdateSetValue(setIdx, 'reps', Number(e.target.value))}
                        className="w-14 bg-[#1a1336] border border-purple-700/60 rounded-lg px-2 py-1 text-center font-mono text-xs text-white outline-none focus:border-purple-400"
                      />
                      <span className="text-xs font-mono text-purple-300/70">reps</span>
                    </div>
                  </div>

                  {/* Validate Check Button */}
                  <button
                    type="button"
                    onClick={() => handleToggleSet(setIdx)}
                    className={`py-1.5 px-3 rounded-lg border font-mono text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 ${
                      set.completed
                        ? 'bg-purple-600 border-purple-400 text-white shadow-[0_0_10px_#a855f7]'
                        : 'border-purple-700/60 bg-purple-950/40 text-purple-300 hover:border-purple-500 hover:text-white'
                    }`}
                  >
                    <Check className={`w-3.5 h-3.5 stroke-[3] ${set.completed ? 'text-white' : 'text-purple-400'}`} />
                    {set.completed ? 'FAIT' : 'VALIDER'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Session Summary Card (Timer removed as requested) */}
          <div className="bg-[#0b071c]/90 border border-purple-900/50 rounded-2xl p-4 backdrop-blur-md flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-950 border border-purple-700/60 flex items-center justify-center text-cyan-400">
                <Flame className="w-5 h-5 text-pink-400" />
              </div>
              <div>
                <div className="text-xs font-mono font-bold text-white uppercase">
                  PROGRESSION DE L'EXERCICE
                </div>
                <div className="text-[11px] font-mono text-purple-300/80">
                  {currentSets.filter((s) => s.completed).length} sur {currentSets.length} séries validées
                </div>
              </div>
            </div>

            <div className="text-right font-mono">
              <div className="text-xs text-purple-400">TOTAL SÉANCE</div>
              <div className="text-sm font-black text-cyan-300">
                {completedSetsCount} / {totalSetsCount} séries
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Big Save Button at the Bottom as specifically requested by user */}
      <div className="w-full bg-[#0a0717]/90 border border-purple-900/60 rounded-2xl p-4 sm:p-6 backdrop-blur-md shadow-[0_0_35px_rgba(112,26,179,0.3)] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="text-sm font-bold text-white font-mono flex items-center gap-2">
            <Trophy className="w-4 h-4 text-cyan-400" />
            FIN DE SÉANCE & TRANSMISSION AU SYSTÈME
          </div>
          <div className="text-xs text-purple-300/80 mt-0.5">
            Enregistrez vos données dans votre profil pour gagner votre EXP et monter de rang !
          </div>
        </div>

        <button
          type="button"
          onClick={handleSaveAndComplete}
          className="w-full sm:w-auto py-4 px-8 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black font-mono text-sm uppercase tracking-wider shadow-[0_0_25px_rgba(168,85,247,0.7)] flex items-center justify-center gap-2 transition-all active:scale-98"
        >
          <Save className="w-5 h-5 text-purple-200" />
          ENREGISTRER LA SÉANCE & OBTENIR MON EXP
        </button>
      </div>
    </div>
  );
};
